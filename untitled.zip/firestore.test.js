const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const moduleSearchPaths = ["/usr/local/lib/node_modules/@firebase/rules-unit-testing"];
const firebase = require(require.resolve("firebase/compat/app", { paths: moduleSearchPaths }));
require(require.resolve("firebase/compat/firestore", { paths: moduleSearchPaths }));

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-e037186c-e77c-4dfe-8d92-249de20e1cf5";

const OWNER_EMAIL = "rharsad5@gmail.com";
const OWNER_UID = "owner_uid_1";
const STUDENT_A_UID = "student_a_uid";
const STUDENT_B_UID = "student_b_uid";
const TEACHER_A_UID = "teacher_a_uid";
const UNVERIFIED_OWNER_UID = "fake_owner_uid";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function serverTs() {
  return firebase.firestore.FieldValue.serverTimestamp();
}

function dbFor(context) {
  return context.firestore({ databaseId: DATABASE_ID });
}

function ownerContext() {
  return testEnv.authenticatedContext(OWNER_UID, {
    email: OWNER_EMAIL,
    email_verified: true,
  });
}

function fakeOwnerContext() {
  return testEnv.authenticatedContext(UNVERIFIED_OWNER_UID, {
    email: OWNER_EMAIL,
    email_verified: false,
  });
}

function studentAContext() {
  return testEnv.authenticatedContext(STUDENT_A_UID, {
    email: "studenta@gmail.com",
    email_verified: true,
  });
}

function studentBContext() {
  return testEnv.authenticatedContext(STUDENT_B_UID, {
    email: "studentb@gmail.com",
    email_verified: true,
  });
}

function teacherAContext() {
  return testEnv.authenticatedContext(TEACHER_A_UID, {
    email: "teachera@gmail.com",
    email_verified: true,
  });
}

function validStudentPayload(authUid, overrides = {}) {
  return {
    authUid,
    teacherUids: [],
    name: "Aarav Patel",
    parentName: "Maheshbhai Patel",
    mobileNumber: "9876543210",
    standard: "Std 10 (SSC)",
    rollNo: "101",
    passwordHash: "a".repeat(64),
    address: "Ahmedabad",
    joinDate: "10-11-2026",
    totalFees: 11999,
    paidFees: 0,
    medium: "Gujarati Medium",
    school: "Navrang School",
    dob: "01-01-2011",
    spinPlayed: false,
    spinDiscount: 0,
    specialDiscount: 0,
    discountReason: "",
    approvalStatus: "PENDING",
    isActive: true,
    createdAt: serverTs(),
    updatedAt: serverTs(),
    ...overrides,
  };
}

function validStudentCredentialPayload(studentId, authUid, overrides = {}) {
  return {
    studentId,
    authUid,
    passwordHash: "a".repeat(64),
    approvalStatus: "PENDING",
    isActive: true,
    createdAt: serverTs(),
    updatedAt: serverTs(),
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated callers are denied read/write across all key collections", async () => {
  const unauthDb = dbFor(testEnv.unauthenticatedContext());
  await assertFails(unauthDb.collection("admins").get());
  await assertFails(unauthDb.collection("students").get());
  await assertFails(unauthDb.collection("teachers").get());
  await assertFails(unauthDb.collection("admissions").get());
  await assertFails(unauthDb.collection("advance_bookings").get());
  await assertFails(unauthDb.collection("receipts").get());
  await assertFails(unauthDb.collection("attendance").get());
  await assertFails(unauthDb.collection("homework").get());
  await assertFails(unauthDb.collection("homework_submissions").get());
  await assertFails(unauthDb.collection("exam_results").get());
  await assertFails(unauthDb.collection("public_faculty").get());
  await assertFails(unauthDb.collection("public_toppers").get());
  await assertFails(unauthDb.collection("announcements").get());
  await assertFails(unauthDb.collection("offers").get());
  await assertFails(unauthDb.collection("timetable").get());
  await assertFails(unauthDb.collection("institute_settings").doc("public").get());
});

test("Email spoofing with email_verified=false is denied admin access", async () => {
  const spoofDb = dbFor(fakeOwnerContext());
  await assertFails(
    spoofDb.collection("admins").doc(UNVERIFIED_OWNER_UID).set({
      ownerUid: UNVERIFIED_OWNER_UID,
      ownerEmail: OWNER_EMAIL,
      adminId: "OWNER01",
      adminMobile: "8511273911",
      founderName: "Harshadsinh Rathod",
      passwordHash: "b".repeat(64),
      isSetupComplete: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertFails(spoofDb.collection("students").get());
});

test("Verified owner can set up admin and institute settings; non-owner denied", async () => {
  const ownerDb = dbFor(ownerContext());
  const studentDb = dbFor(studentAContext());

  await assertSucceeds(
    ownerDb.collection("admins").doc(OWNER_UID).set({
      ownerUid: OWNER_UID,
      ownerEmail: OWNER_EMAIL,
      adminId: "HDADMIN01",
      adminMobile: "8511273911",
      founderName: "Harshadsinh Rathod",
      passwordHash: "b".repeat(64),
      isSetupComplete: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Public admin delete denied even for owner
  await assertFails(ownerDb.collection("admins").doc(OWNER_UID).delete());

  // Non-owner cannot create admin or read admins
  await assertFails(studentDb.collection("admins").get());
  await assertFails(
    studentDb.collection("admins").doc(STUDENT_A_UID).set({
      ownerUid: STUDENT_A_UID,
      ownerEmail: "studenta@gmail.com",
      adminId: "FAKE",
      adminMobile: "9999999999",
      founderName: "Fake",
      passwordHash: "b".repeat(64),
      isSetupComplete: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  await assertSucceeds(
    ownerDb.collection("institute_settings").doc("public").set({
      businessName: "HD Tuition Classes",
      founderName: "Harshadsinh Rathod",
      contactPhone: "+91 85112 73911",
      whatsappNumber: "918511273911",
      upiId: "hdtuition@upi",
      upiPayeeName: "Harshadsinh Rathod",
      advanceBookingAmount: 99,
      address: "Gujarat",
      admissionOpen: true,
      tickerText: "Admissions Open",
      ownerUid: OWNER_UID,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(studentDb.collection("institute_settings").doc("public").get());
});

test("Student registration enforces PENDING status, zero paid fees, and cross-student isolation", async () => {
  const studentADb = dbFor(studentAContext());
  const studentBDb = dbFor(studentBContext());
  const ownerDb = dbFor(ownerContext());

  // Self-approving on registration must FAIL
  await assertFails(
    studentADb
      .collection("students")
      .doc("HD202601")
      .set(validStudentPayload(STUDENT_A_UID, { approvalStatus: "APPROVED" }))
  );

  // Registering with paidFees > 0 must FAIL
  await assertFails(
    studentADb
      .collection("students")
      .doc("HD202601")
      .set(validStudentPayload(STUDENT_A_UID, { paidFees: 5000 }))
  );

  // Valid PENDING registration succeeds
  await assertSucceeds(
    studentADb
      .collection("students")
      .doc("HD202601")
      .set(validStudentPayload(STUDENT_A_UID))
  );
  await assertSucceeds(
    studentADb
      .collection("student_credentials")
      .doc("HD202601")
      .set(validStudentCredentialPayload("HD202601", STUDENT_A_UID))
  );

  // Unfiltered list by Student B fails; filtered list for own uid succeeds
  await assertFails(studentBDb.collection("students").get());
  await assertFails(studentBDb.collection("students").doc("HD202601").get());
  await assertSucceeds(
    studentADb.collection("students").where("authUid", "==", STUDENT_A_UID).get()
  );

  // Owner can approve student A
  await assertSucceeds(
    ownerDb.collection("students").doc("HD202601").update({
      approvalStatus: "APPROVED",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    ownerDb.collection("student_credentials").doc("HD202601").update({
      approvalStatus: "APPROVED",
      updatedAt: serverTs(),
    })
  );

  // Approved student A can spin ONCE, then second spin fails
  await assertSucceeds(
    studentADb.collection("students").doc("HD202601").update({
      spinPlayed: true,
      spinDiscount: 29,
      discountReason: "Spin & Win ₹29 Off",
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    studentADb.collection("students").doc("HD202601").update({
      spinPlayed: true,
      spinDiscount: 49,
      discountReason: "Cheat",
      updatedAt: serverTs(),
    })
  );
  // Shadow update on paidFees or specialDiscount blocked
  await assertFails(
    studentADb.collection("students").doc("HD202601").update({
      specialDiscount: 5000,
      updatedAt: serverTs(),
    })
  );
});

test("Teacher registration, admin approval, scoped student list, attendance, homework, submissions, and marks", async () => {
  const teacherDb = dbFor(teacherAContext());
  const studentADb = dbFor(studentAContext());
  const ownerDb = dbFor(ownerContext());

  // Teacher registers as PENDING
  await assertSucceeds(
    teacherDb.collection("teachers").doc("TCH01").set({
      teacherId: "TCH01",
      authUid: TEACHER_A_UID,
      name: "Meera Joshi",
      role: "Science Teacher",
      qualification: "M.Sc",
      experience: "5 Years",
      subjects: "Science, Maths",
      assignedStandards: ["Std 10 (SSC)"],
      contact: "9898989898",
      passwordHash: "c".repeat(64),
      approvalStatus: "PENDING",
      isActive: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Unapproved teacher CANNOT post homework or attendance
  await assertFails(
    teacherDb.collection("homework").doc("HW1").set({
      standard: "Std 10 (SSC)",
      subject: "Science",
      title: "Chapter 1",
      description: "Solve Q1 to Q5",
      assignedDate: "10-11-2026",
      dueDate: "12-11-2026",
      teacherName: "Meera Joshi",
      teacherUid: TEACHER_A_UID,
      isPublished: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Owner approves teacher, adds teacher_directory and public_faculty, and binds teacherUid to student
  await assertSucceeds(
    ownerDb.collection("teachers").doc("TCH01").update({
      approvalStatus: "APPROVED",
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    ownerDb.collection("teacher_directory").doc(TEACHER_A_UID).set({
      teacherId: "TCH01",
      name: "Meera Joshi",
      approvalStatus: "APPROVED",
      isActive: true,
      assignedStandards: ["Std 10 (SSC)"],
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    ownerDb.collection("public_faculty").doc("TCH01").set({
      teacherId: "TCH01",
      name: "Meera Joshi",
      role: "Science Teacher",
      qualification: "M.Sc",
      experience: "5 Years",
      subjects: "Science, Maths",
      assignedStandards: ["Std 10 (SSC)"],
      isActive: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    ownerDb
      .collection("students")
      .doc("HD202601")
      .set(
        validStudentPayload(STUDENT_A_UID, {
          approvalStatus: "APPROVED",
          teacherUids: [TEACHER_A_UID],
        })
      )
  );

  // Teacher can list ONLY assigned students (whereArrayContains)
  await assertSucceeds(
    teacherDb
      .collection("students")
      .where("teacherUids", "array-contains", TEACHER_A_UID)
      .get()
  );
  await assertFails(teacherDb.collection("students").get());

  // Approved teacher can assign homework, mark attendance, upload marks
  await assertSucceeds(
    teacherDb.collection("homework").doc("HW1").set({
      standard: "Std 10 (SSC)",
      subject: "Science",
      title: "Chapter 1",
      description: "Solve Q1 to Q5",
      assignedDate: "10-11-2026",
      dueDate: "12-11-2026",
      teacherName: "Meera Joshi",
      teacherUid: TEACHER_A_UID,
      isPublished: true,
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    teacherDb.collection("attendance").doc("HD202601_10-11-2026").set({
      studentId: "HD202601",
      studentAuthUid: STUDENT_A_UID,
      teacherUid: TEACHER_A_UID,
      standard: "Std 10 (SSC)",
      date: "10-11-2026",
      status: "PRESENT",
      notes: "",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertSucceeds(
    teacherDb.collection("exam_results").doc("RES1").set({
      studentId: "HD202601",
      studentAuthUid: STUDENT_A_UID,
      teacherUid: TEACHER_A_UID,
      examName: "Unit Test 1",
      examDate: "10-11-2026",
      standard: "Std 10 (SSC)",
      scores: [{ subject: "Science", obtainedMarks: 45, maxMarks: 50 }],
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );

  // Student submits homework (create-only; update/delete denied for student)
  await assertSucceeds(
    studentADb.collection("homework_submissions").doc("SUB_HW1_HD202601").set({
      homeworkId: "HW1",
      studentId: "HD202601",
      studentAuthUid: STUDENT_A_UID,
      teacherUid: TEACHER_A_UID,
      studentName: "Aarav Patel",
      subject: "Science",
      submissionText: "Completed all questions in notebook",
      submittedAt: "10-11-2026",
      status: "Submitted",
      teacherFeedback: "",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    studentADb.collection("homework_submissions").doc("SUB_HW1_HD202601").update({
      submissionText: "Tampered text",
      updatedAt: serverTs(),
    })
  );

  // Teacher can grade submission (status + teacherFeedback only, cannot modify submissionText)
  await assertSucceeds(
    teacherDb.collection("homework_submissions").doc("SUB_HW1_HD202601").update({
      status: "Checked",
      teacherFeedback: "Well done!",
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    teacherDb.collection("homework_submissions").doc("SUB_HW1_HD202601").update({
      submissionText: "Tampered by teacher",
      status: "Checked",
      updatedAt: serverTs(),
    })
  );
});

test("Admissions, advance bookings, receipts, and public content obey least-privilege access", async () => {
  const studentADb = dbFor(studentAContext());
  const studentBDb = dbFor(studentBContext());
  const ownerDb = dbFor(ownerContext());

  await assertSucceeds(
    studentADb.collection("admissions").doc("ADM_1").set({
      authUid: STUDENT_A_UID,
      studentName: "Riya Shah",
      parentName: "Ketan Shah",
      mobileNumber: "9123456789",
      whatsappNumber: "9123456789",
      address: "Surat",
      dateOfBirth: "05-05-2012",
      standard: "Std 8",
      medium: "Gujarati Medium",
      previousSchool: "Bright School",
      submissionDate: "10-11-2026",
      status: "PENDING",
      notes: "",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertFails(studentBDb.collection("admissions").doc("ADM_1").get());
  await assertFails(studentBDb.collection("admissions").get());
  await assertSucceeds(
    studentADb.collection("admissions").where("authUid", "==", STUDENT_A_UID).get()
  );

  await assertSucceeds(
    studentADb.collection("advance_bookings").doc("BK_1").set({
      authUid: STUDENT_A_UID,
      studentName: "Riya Shah",
      standard: "Std 8",
      parentName: "Ketan Shah",
      mobileNumber: "9123456789",
      whatsappNumber: "9123456789",
      amount: 99,
      upiTransactionId: "UPI123456",
      paymentStatus: "PENDING_VERIFICATION",
      bookingDate: "10-11-2026",
      hasScreenshot: true,
      academicYear: "2027-28",
      notes: "",
      createdAt: serverTs(),
      updatedAt: serverTs(),
    })
  );
  await assertFails(studentBDb.collection("advance_bookings").doc("BK_1").get());
  await assertSucceeds(
    ownerDb.collection("advance_bookings").doc("BK_1").update({
      paymentStatus: "CONFIRMED",
      updatedAt: serverTs(),
    })
  );

  // Public content lists must filter active/published
  await assertSucceeds(
    studentADb.collection("public_toppers").where("isActive", "==", true).get()
  );
  await assertSucceeds(
    studentADb.collection("offers").where("isActive", "==", true).get()
  );
  await assertSucceeds(
    studentADb.collection("timetable").where("isActive", "==", true).get()
  );
  await assertSucceeds(
    studentADb.collection("announcements").where("isPublished", "==", true).get()
  );
  await assertFails(studentADb.collection("public_toppers").get());
  await assertFails(studentADb.collection("offers").get());
});

function validOfferPayload(overrides = {}) {
  const nowMs = Date.now();
  return {
    title: "Early Bird 10% Scholarship",
    subtitle: "Limited Seats",
    badge: "10% OFF",
    discountDescription: "10% discount on annual tuition fees",
    discountType: "PERCENTAGE",
    discountValue: 10,
    applicableStandards: ["Std 10", "Std 12"],
    targetAudience: "ALL",
    startDate: "01-11-2026",
    endDate: "31-12-2030",
    startDateEpochMs: nowMs - 86400000,
    endDateEpochMs: nowMs + 86400000 * 30,
    validTill: "31-12-2030",
    maxClaims: 2,
    claimedCount: 0,
    claimedStudentIds: [],
    bannerImageBase64: "",
    bannerImageUrl: "",
    bannerPresetKey: "PURPLE_GOLD",
    isActive: true,
    createdAt: serverTs(),
    updatedAt: serverTs(),
    ...overrides,
  };
}

test("Manage Offers: only owner can create/edit/delete offers; students can atomically claim eligible offers up to First-N cap", async () => {
  const ownerDb = dbFor(ownerContext());
  const studentADb = dbFor(studentAContext());
  const studentBDb = dbFor(studentBContext());

  // Non-owner cannot create offer
  await assertFails(studentADb.collection("offers").doc("OFF_1").set(validOfferPayload()));

  // Owner creates offer for Std 10 & Std 12 (10% OFF, First 1 student only)
  await assertSucceeds(
    ownerDb.collection("offers").doc("OFF_1").set(validOfferPayload({ maxClaims: 1 }))
  );

  // Student A (Std 10) & Student B (Std 10) created & approved
  await assertSucceeds(
    ownerDb
      .collection("students")
      .doc("HD_S1")
      .set(validStudentPayload(STUDENT_A_UID, { approvalStatus: "APPROVED", standard: "Std 10", totalFees: 11999 }))
  );
  await assertSucceeds(
    ownerDb
      .collection("students")
      .doc("HD_S2")
      .set(validStudentPayload(STUDENT_B_UID, { approvalStatus: "APPROVED", standard: "Std 10", totalFees: 11999 }))
  );

  // Student cannot edit offer metadata directly or claim without mutual student update
  await assertFails(
    studentADb.collection("offers").doc("OFF_1").update({
      discountValue: 90,
      updatedAt: serverTs(),
    })
  );
  await assertFails(
    studentADb.collection("offers").doc("OFF_1").update({
      claimedCount: 1,
      claimedStudentIds: ["HD_S1"],
      updatedAt: serverTs(),
    })
  );
  await assertFails(studentADb.collection("offers").doc("OFF_1").delete());

  // Tampered discount math (claiming ₹5000 when 10% of 11999 is 1199) must FAIL
  await assertFails(
    studentADb.runTransaction(async (txn) => {
      txn.update(studentADb.collection("offers").doc("OFF_1"), {
        claimedCount: 1,
        claimedStudentIds: ["HD_S1"],
        updatedAt: serverTs(),
      });
      txn.update(studentADb.collection("students").doc("HD_S1"), {
        appliedOfferId: "OFF_1",
        appliedOfferTitle: "Early Bird 10% Scholarship",
        offerDiscount: 5000,
        discountReason: "Tampered",
        updatedAt: serverTs(),
      });
    })
  );

  // Valid atomic claim by Student A + OFFER_HISTORY entry succeeds
  await assertSucceeds(
    studentADb.runTransaction(async (txn) => {
      txn.update(studentADb.collection("offers").doc("OFF_1"), {
        claimedCount: 1,
        claimedStudentIds: ["HD_S1"],
        updatedAt: serverTs(),
      });
      txn.update(studentADb.collection("students").doc("HD_S1"), {
        appliedOfferId: "OFF_1",
        appliedOfferTitle: "Early Bird 10% Scholarship",
        offerDiscount: 1199,
        discountReason: "Offer: Early Bird 10% Scholarship",
        updatedAt: serverTs(),
      });
      txn.set(studentADb.collection("offer_history").doc("HIST_1"), {
        offerId: "OFF_1",
        offerTitle: "Early Bird 10% Scholarship",
        action: "CLAIMED",
        summary: "Auto-applied ₹1199 discount for HD_S1",
        actorRole: "STUDENT",
        actorId: "HD_S1",
        studentId: "HD_S1",
        studentName: "Aarav Patel",
        studentAuthUid: STUDENT_A_UID,
        discountApplied: 1199,
        createdAt: serverTs(),
      });
    })
  );

  // Second claim by Student B fails because maxClaims == 1 is already reached
  await assertFails(
    studentBDb.runTransaction(async (txn) => {
      txn.update(studentBDb.collection("offers").doc("OFF_1"), {
        claimedCount: 2,
        claimedStudentIds: ["HD_S1", "HD_S2"],
        updatedAt: serverTs(),
      });
      txn.update(studentBDb.collection("students").doc("HD_S2"), {
        appliedOfferId: "OFF_1",
        appliedOfferTitle: "Early Bird 10% Scholarship",
        offerDiscount: 1199,
        discountReason: "Offer: Early Bird 10% Scholarship",
        updatedAt: serverTs(),
      });
    })
  );

  // Expired offer claim must FAIL
  const pastMs = Date.now() - 86400000 * 5;
  await assertSucceeds(
    ownerDb.collection("offers").doc("OFF_EXP").set(
      validOfferPayload({
        maxClaims: 5,
        startDateEpochMs: pastMs - 86400000,
        endDateEpochMs: pastMs,
      })
    )
  );
  await assertFails(
    studentBDb.runTransaction(async (txn) => {
      txn.update(studentBDb.collection("offers").doc("OFF_EXP"), {
        claimedCount: 1,
        claimedStudentIds: ["HD_S2"],
        updatedAt: serverTs(),
      });
      txn.update(studentBDb.collection("students").doc("HD_S2"), {
        appliedOfferId: "OFF_EXP",
        appliedOfferTitle: "Expired",
        offerDiscount: 1000,
        discountReason: "Expired",
        updatedAt: serverTs(),
      });
    })
  );

  // Wrong standard (Std 8 trying to claim Std 10/12 offer) must FAIL
  await assertSucceeds(
    ownerDb.collection("offers").doc("OFF_STD10").set(
      validOfferPayload({
        maxClaims: 5,
        applicableStandards: ["Std 10"],
        discountType: "FIXED",
        discountValue: 500,
      })
    )
  );
  await assertSucceeds(
    ownerDb
      .collection("students")
      .doc("HD_S8")
      .set(validStudentPayload(STUDENT_B_UID, { approvalStatus: "APPROVED", standard: "Std 8", totalFees: 9599 }))
  );
  await assertFails(
    studentBDb.runTransaction(async (txn) => {
      txn.update(studentBDb.collection("offers").doc("OFF_STD10"), {
        claimedCount: 1,
        claimedStudentIds: ["HD_S8"],
        updatedAt: serverTs(),
      });
      txn.update(studentBDb.collection("students").doc("HD_S8"), {
        appliedOfferId: "OFF_STD10",
        appliedOfferTitle: "Std 10 Offer",
        offerDiscount: 500,
        discountReason: "Wrong Std",
        updatedAt: serverTs(),
      });
    })
  );

  // Owner can read/delete offer_history; students cannot read or mutate offer_history
  await assertSucceeds(ownerDb.collection("offer_history").get());
  await assertFails(studentADb.collection("offer_history").get());
  await assertFails(ownerDb.collection("offer_history").doc("HIST_1").update({ discountApplied: 0 }));
});

