package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TuitionSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class ExampleRobolectricTest {

    @Test
    fun appContextAndResourceConfig_areInitializedCleanly() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("com.aistudio.hdtuition.rkqpvz", context.packageName)

        val settings = TuitionSettings()
        assertEquals("HD TUITION CLASSES", settings.businessName)
        assertEquals("Harshadsinh Rathod", settings.founderName)
        assertEquals(99, settings.advanceBookingAmount)
        assertTrue(settings.upiId.isNotBlank())
    }
}
