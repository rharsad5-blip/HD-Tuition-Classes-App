package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AnnouncementItem
import com.example.data.model.ApprovalStatusValues
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.ExamResult
import com.example.data.model.HomeworkItem
import com.example.data.model.HomeworkSubmission
import com.example.data.model.OfferAudience
import com.example.data.model.OfferDiscountType
import com.example.data.model.OfferHistoryAction
import com.example.data.model.SpecialOffer
import com.example.data.model.SubjectScore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HDTuitionRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun unauthenticatedAndNonOwner_blockedFromProtectedCollectionsAndAdminSetup() = runBlocking {
        clearEmulatorFirestore()
        auth.signOut()

        var unauthError: Throwable? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("students").get().await()
            }
        } catch (t: Throwable) {
            unauthError = t
        }
        val unauthFsEx = unauthError?.unwrapFirestoreException()
        assertNotNull("Expected PERMISSION_DENIED for unauthenticated read", unauthFsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, unauthFsEx!!.code)

        val strangerUid = signInTestUser("stranger@test.com")
        val strangerRepo = HDTuitionRepository(firestore, auth)
        val setupAttempt = withTimeout(DEFAULT_TIMEOUT_MS) {
            strangerRepo.completeOneTimeOwnerAdminSetup(
                ownerVerification = "8511273911",
                adminMobileOrId = "8511273911",
                pass = "hackerPass1"
            )
        }
        assertTrue("Non-owner admin setup must fail", setupAttempt.isFailure)

        var directAdminWriteError: Throwable? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("admins").document(strangerUid).set(
                    mapOf("ownerUid" to strangerUid, "isSetupComplete" to true)
                ).await()
            }
        } catch (t: Throwable) {
            directAdminWriteError = t
        }
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            directAdminWriteError?.unwrapFirestoreException()?.code
        )
        strangerRepo.stopListeners()
    }

    @Test
    fun verifiedOwner_completesOneTimeAdminSetup_locksSecondSetup_andChangesPassword() = runBlocking {
        clearEmulatorFirestore()
        signInVerifiedOwner()
        val ownerRepo = HDTuitionRepository(firestore, auth)

        val setupRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.completeOneTimeOwnerAdminSetup(
                ownerVerification = "8511273911",
                adminMobileOrId = "8511273911",
                pass = "OwnerPass#1",
                founderName = "Harshadsinh Rathod"
            )
        }
        assertTrue("Verified owner setup should succeed: ${setupRes.exceptionOrNull()}", setupRes.isSuccess)
        assertTrue(ownerRepo.isAdminSetupComplete.value)

        val secondAttempt = withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.completeOneTimeOwnerAdminSetup(
                ownerVerification = "8511273911",
                adminMobileOrId = "8511273911",
                pass = "AnotherPass#2"
            )
        }
        assertTrue("Second one-time admin setup must fail", secondAttempt.isFailure)

        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.authenticateAdmin("8511273911", "wrongPass")
        }.isFailure)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.authenticateAdmin("+91 85112 73911", "OwnerPass#1")
        }.isSuccess)

        val changeRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.changeAdminPassword("OwnerPass#1", "UpdatedPass#9")
        }
        assertTrue(changeRes.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.authenticateAdmin("8511273911", "UpdatedPass#9")
        }.isSuccess)

        ownerRepo.stopListeners()
    }

    @Test
    fun studentRegistration_requiresAdminApproval_enforcesSingleSpin_andCrossUserIsolation() = runBlocking {
        clearEmulatorFirestore()
        signInVerifiedOwner()
        val setupRepo = HDTuitionRepository(firestore, auth)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            setupRepo.completeOneTimeOwnerAdminSetup("8511273911", "8511273911", "OwnerPass#1")
        }.isSuccess)
        setupRepo.stopListeners()
        auth.signOut()

        // Student A registers -> PENDING
        val studentAUid = signInTestUser("student_a@test.com")
        val studentARepo = HDTuitionRepository(firestore, auth)
        val regRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.registerStudent(
                name = "Aarav Solanki",
                parentName = "Maheshbhai Solanki",
                mobileNumber = "9876500001",
                standard = "Std 10",
                password = "studPass1"
            )
        }
        assertTrue("Student registration failed: ${regRes.exceptionOrNull()}", regRes.isSuccess)
        val student = regRes.getOrThrow()
        assertEquals(ApprovalStatusValues.PENDING, student.approvalStatus)

        // Duplicate mobile blocked
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.registerStudent("Duplicate", "Parent", "9876500001", "Std 10", "studPass2")
        }.isFailure)

        // Cannot login while PENDING
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.authenticateStudent(student.id, "studPass1")
        }.isFailure)
        studentARepo.stopListeners()
        auth.signOut()

        // Owner approves Student A
        signInVerifiedOwner()
        val ownerRepo = HDTuitionRepository(firestore, auth)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.adminApproveStudent(student.id)
        }.isSuccess)
        ownerRepo.stopListeners()
        auth.signOut()

        // Student A logs in -> spins once -> second spin blocked -> pays & submits homework
        signInTestUser("student_a@test.com")
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.authenticateStudent(student.id, "studPass1")
        }.isSuccess)

        val spin1 = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.recordSpinWin(student.id, 29, "₹29 Spin Discount")
        }
        assertTrue("First spin should succeed: ${spin1.exceptionOrNull()}", spin1.isSuccess)
        val spin2 = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.recordSpinWin(student.id, 49, "₹49 Spin Discount")
        }
        assertTrue("Second spin must be rejected", spin2.isFailure)

        val payRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.recordOnlinePayment(student.id, 99, "UPI Intent", "UPI-REF-001", "SUCCESS")
        }
        assertTrue("Online payment failed: ${payRes.exceptionOrNull()}", payRes.isSuccess)
        val receiptId = payRes.getOrThrow().id

        val hwSubRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.submitHomework(
                HomeworkSubmission(
                    homeworkId = "HW_SAMPLE_1",
                    studentId = student.id,
                    studentName = student.name,
                    subject = "Maths",
                    submissionText = "Completed Exercise 4.1",
                    submittedAt = "13-Nov-2026"
                )
            )
        }
        assertTrue("Homework submission failed: ${hwSubRes.exceptionOrNull()}", hwSubRes.isSuccess)
        studentARepo.stopListeners()
        auth.signOut()

        // Cross-user isolation: Student B cannot read Student A's document or receipt
        val studentBUid = signInTestUser("student_b@test.com")
        assertTrue(studentBUid != studentAUid)
        var crossStudentErr: Throwable? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("students").document(student.id).get().await()
            }
        } catch (t: Throwable) {
            crossStudentErr = t
        }
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            crossStudentErr?.unwrapFirestoreException()?.code
        )

        var crossReceiptErr: Throwable? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("receipts").document(receiptId).get().await()
            }
        } catch (t: Throwable) {
            crossReceiptErr = t
        }
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            crossReceiptErr?.unwrapFirestoreException()?.code
        )
    }

    @Test
    fun teacherRegistration_requiresApproval_enforcesStandardScope_andAllowsAcademicWrites() = runBlocking {
        clearEmulatorFirestore()
        signInVerifiedOwner()
        val ownerRepo = HDTuitionRepository(firestore, auth)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.completeOneTimeOwnerAdminSetup("8511273911", "8511273911", "OwnerPass#1")
        }.isSuccess)

        val std10 = withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.adminCreateStudent("Dev Parmar", "Rameshbhai", "9876500010", "Std 10", "pass10")
        }.getOrThrow()
        val std8 = withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.adminCreateStudent("Neha Joshi", "Kamleshbhai", "9876500008", "Std 8", "pass08")
        }.getOrThrow()
        ownerRepo.stopListeners()
        auth.signOut()

        // Teacher registers -> PENDING
        signInTestUser("teacher@test.com")
        val teacherRepo = HDTuitionRepository(firestore, auth)
        val regTeacher = withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.registerTeacher(
                name = "Kiranbhai Jadeja",
                mobileNumber = "9876500099",
                subjects = "Maths, Science",
                qualification = "M.Sc, B.Ed",
                experience = "5 Years",
                password = "teachPass1",
                assignedStandards = listOf("Std 10")
            )
        }
        assertTrue("Teacher registration failed: ${regTeacher.exceptionOrNull()}", regTeacher.isSuccess)
        val teacher = regTeacher.getOrThrow()
        assertEquals(ApprovalStatusValues.PENDING, teacher.approvalStatus)

        assertTrue("Pending teacher must not log in", withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.authenticateTeacher(teacher.teacherId, "teachPass1")
        }.isFailure)
        teacherRepo.stopListeners()
        auth.signOut()

        // Owner approves teacher for Std 10 only
        signInVerifiedOwner()
        assertTrue("Approve teacher failed", withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.adminApproveTeacher(teacher.id, listOf("Std 10"))
        }.isSuccess)
        ownerRepo.stopListeners()
        auth.signOut()

        // Approved teacher logs in -> scoped listener sees Std 10 student only, denied Std 8 student
        signInTestUser("teacher@test.com")
        assertTrue("Approved teacher login failed", withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.authenticateTeacher(teacher.teacherId, "teachPass1")
        }.isSuccess)

        val scopedStudents = withTimeout(FLOW_TIMEOUT_MS) {
            teacherRepo.students.first { list -> list.any { it.id == std10.id } }
        }
        assertTrue(scopedStudents.any { it.id == std10.id })
        assertTrue("Teacher must not receive Std 8 student in scoped query", scopedStudents.none { it.id == std8.id })

        var crossScopeErr: Throwable? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("students").document(std8.id).get().await()
            }
        } catch (t: Throwable) {
            crossScopeErr = t
        }
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            crossScopeErr?.unwrapFirestoreException()?.code
        )

        // Teacher writes attendance, homework, exam result, and announcement
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.markBatchAttendance(
                listOf(
                    AttendanceRecord(
                        studentId = std10.id,
                        studentAuthUid = std10.authUid,
                        standard = "Std 10",
                        date = "13-Nov-2026",
                        status = AttendanceStatus.PRESENT
                    )
                )
            )
        }.isSuccess)

        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.addHomework(
                HomeworkItem(
                    standard = "Std 10",
                    subject = "Maths",
                    title = "Quadratic Equations",
                    description = "Solve Exercise 4.2",
                    assignedDate = "13-Nov-2026",
                    dueDate = "15-Nov-2026",
                    teacherName = teacher.name
                )
            )
        }.isSuccess)

        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.addExamResult(
                ExamResult(
                    studentId = std10.id,
                    studentAuthUid = std10.authUid,
                    examName = "Weekly Test 1",
                    examDate = "13-Nov-2026",
                    standard = "Std 10",
                    scores = listOf(SubjectScore("Maths", 46, 50))
                )
            )
        }.isSuccess)

        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            teacherRepo.addAnnouncement(
                AnnouncementItem(
                    title = "Extra Revision Class",
                    content = "Sunday 8 AM to 10 AM",
                    date = "13-Nov-2026",
                    targetStandard = "Std 10",
                    authorName = teacher.name
                )
            )
        }.isSuccess)

        teacherRepo.stopListeners()
    }

    @Test
    fun manageOffers_adminCrudHistoryAndStudentAutoDiscountVerification() = runBlocking {
        clearEmulatorFirestore()
        signInVerifiedOwner()
        val ownerRepo = HDTuitionRepository(firestore, auth)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.completeOneTimeOwnerAdminSetup("8511273911", "8511273911", "OwnerPass#1")
        }.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.authenticateAdmin("8511273911", "OwnerPass#1")
        }.isSuccess)

        val nowMs = System.currentTimeMillis()
        val createOfferRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.addOffer(
                SpecialOffer(
                    title = "SSC 10% Scholarship",
                    subtitle = "First 1 Only",
                    badge = "10% OFF",
                    discountDescription = "10% off on Std 10 annual fees",
                    discountType = OfferDiscountType.PERCENTAGE,
                    discountValue = 10,
                    applicableStandards = listOf("Std 10"),
                    targetAudience = OfferAudience.ALL,
                    startDate = "01-11-2026",
                    endDate = "31-12-2030",
                    startDateEpochMs = nowMs - 86_400_000L,
                    endDateEpochMs = nowMs + 86_400_000L * 30L,
                    validTill = "31-12-2030",
                    maxClaims = 1,
                    isActive = true
                )
            )
        }
        assertTrue("Owner addOffer failed: ${createOfferRes.exceptionOrNull()}", createOfferRes.isSuccess)
        val createdOffer = createOfferRes.getOrThrow()

        // Edit & toggle status, verify audit log entries
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.updateOffer(createdOffer.copy(subtitle = "First 1 Student Special"))
        }.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.toggleOfferStatus(createdOffer.id) // OFF
        }.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.toggleOfferStatus(createdOffer.id) // back ON
        }.isSuccess)

        val historyAfterAdminOps = withTimeout(FLOW_TIMEOUT_MS) {
            ownerRepo.offerHistory.first { list -> list.size >= 4 }
        }
        assertTrue(historyAfterAdminOps.any { it.action == OfferHistoryAction.CREATED && it.offerId == createdOffer.id })
        assertTrue(historyAfterAdminOps.any { it.action == OfferHistoryAction.EDITED && it.offerId == createdOffer.id })
        assertTrue(historyAfterAdminOps.any { it.action == OfferHistoryAction.DEACTIVATED && it.offerId == createdOffer.id })
        assertTrue(historyAfterAdminOps.any { it.action == OfferHistoryAction.ACTIVATED && it.offerId == createdOffer.id })

        ownerRepo.stopListeners()
        auth.signOut()

        // Non-owner student A registers and gets approved
        signInTestUser("offer_student_a@test.com")
        val studentARepo = HDTuitionRepository(firestore, auth)
        val regA = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.registerStudent("Karan Desai", "Nitinbhai", "9876511101", "Std 10", "passA1")
        }.getOrThrow()
        // Non-owner cannot create offer
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.addOffer(createdOffer.copy(id = "", title = "Unauthorized"))
        }.isFailure)
        studentARepo.stopListeners()
        auth.signOut()

        // Student B registers (also Std 10)
        signInTestUser("offer_student_b@test.com")
        val studentBRepo = HDTuitionRepository(firestore, auth)
        val regB = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentBRepo.registerStudent("Rohan Dave", "Sureshbhai", "9876511102", "Std 10", "passB1")
        }.getOrThrow()
        studentBRepo.stopListeners()
        auth.signOut()

        // Owner approves both students
        signInVerifiedOwner()
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { ownerRepo.adminApproveStudent(regA.id) }.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { ownerRepo.adminApproveStudent(regB.id) }.isSuccess)
        ownerRepo.stopListeners()
        auth.signOut()

        // Student A logs in -> auto-apply claims First-1 slot -> 10% of 11999 = 1199 discount
        signInTestUser("offer_student_a@test.com")
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.authenticateStudent(regA.id, "passA1")
        }.isSuccess)
        val claimARes = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentARepo.autoApplyEligibleOffersForStudent(regA.id)
        }
        assertTrue("Student A offer auto-apply failed: ${claimARes.exceptionOrNull()}", claimARes.isSuccess)
        assertNotNull("Expected offer to auto-apply to Student A", claimARes.getOrNull())

        val updatedA = withTimeout(FLOW_TIMEOUT_MS) {
            studentARepo.students.first { list -> list.any { it.id == regA.id && it.offerDiscount == 1199 } }
        }.first { it.id == regA.id }
        assertEquals(createdOffer.id, updatedA.appliedOfferId)
        assertEquals(11999 - 1199, updatedA.effectiveTotalFees)
        studentARepo.stopListeners()
        auth.signOut()

        // Student B logs in -> First-1 limit exhausted -> autoApplyEligibleOffersForStudent returns null
        signInTestUser("offer_student_b@test.com")
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            studentBRepo.authenticateStudent(regB.id, "passB1")
        }.isSuccess)
        val claimBRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            studentBRepo.autoApplyEligibleOffersForStudent(regB.id)
        }
        assertTrue(claimBRes.isSuccess)
        assertEquals(null, claimBRes.getOrNull())
        studentBRepo.stopListeners()
        auth.signOut()

        // Owner revokes Student A's offer & deletes offer -> verifies REVOKED and DELETED history
        signInVerifiedOwner()
        ownerRepo.startAdminListeners()
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.adminRevokeStudentOffer(regA.id)
        }.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            ownerRepo.deleteOffer(createdOffer.id)
        }.isSuccess)

        val finalHistory = withTimeout(FLOW_TIMEOUT_MS) {
            ownerRepo.offerHistory.first { list ->
                list.any { it.action == OfferHistoryAction.REVOKED } &&
                    list.any { it.action == OfferHistoryAction.DELETED }
            }
        }
        assertTrue(finalHistory.any { it.action == OfferHistoryAction.CLAIMED && it.studentId == regA.id })
        ownerRepo.stopListeners()
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 6000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
