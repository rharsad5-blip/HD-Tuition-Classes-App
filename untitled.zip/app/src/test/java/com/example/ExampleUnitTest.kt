package com.example

import com.example.data.model.ExamResult
import com.example.data.model.OfferAudience
import com.example.data.model.OfferDiscountType
import com.example.data.model.SpecialOffer
import com.example.data.model.Student
import com.example.data.model.SubjectScore
import com.example.data.remote.PasswordHasher
import com.example.data.repository.HDTuitionRepository
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Date

class ExampleUnitTest {

    @Test
    fun standardAnnualFee_returnsExpectedCatalogFeesForAllStandards() {
        assertEquals(3599, HDTuitionRepository.standardAnnualFee("Std 1"))
        assertEquals(3599, HDTuitionRepository.standardAnnualFee("Std 3"))
        assertEquals(5999, HDTuitionRepository.standardAnnualFee("Std 4"))
        assertEquals(5999, HDTuitionRepository.standardAnnualFee("Std 5"))
        assertEquals(9599, HDTuitionRepository.standardAnnualFee("Std 6"))
        assertEquals(9599, HDTuitionRepository.standardAnnualFee("Std 8"))
        assertEquals(10799, HDTuitionRepository.standardAnnualFee("Std 9"))
        assertEquals(11999, HDTuitionRepository.standardAnnualFee("Std 10"))
        assertEquals(14399, HDTuitionRepository.standardAnnualFee("Std 11"))
        assertEquals(15999, HDTuitionRepository.standardAnnualFee("Std 12"))
    }

    @Test
    fun passwordHasher_hashesAndVerifiesWithSalt() {
        val salt = "HD_UNIT_TEST"
        val hash = PasswordHasher.hashPassword("mySecret#99", salt)
        assertEquals(64, hash.length)
        assertTrue(PasswordHasher.verifyPassword("mySecret#99", hash, salt))
        assertTrue(PasswordHasher.verifyPassword("  mySecret#99  ", hash, salt))
        assertFalse(PasswordHasher.verifyPassword("wrongPass", hash, salt))
        assertFalse(PasswordHasher.verifyPassword("mySecret#99", hash, "OTHER_SALT"))
    }

    @Test
    fun phoneNormalizationAndHashing_handlesCountryCodeAndSpaces() {
        val rawA = "+91 98765 43210"
        val rawB = "9876543210"
        assertEquals("9876543210", PasswordHasher.normalizePhone10(rawA))
        assertEquals(PasswordHasher.hashPhone(rawA), PasswordHasher.hashPhone(rawB))
        assertNotEquals(PasswordHasher.hashPhone(rawA), PasswordHasher.hashPhone("9876500000"))
    }

    @Test
    fun studentComputedBalances_respectDiscountsAndPayments() {
        val student = Student(
            id = "HD_T1",
            name = "Test Student",
            totalFees = 11999,
            paidFees = 5000,
            spinDiscount = 29,
            specialDiscount = 500,
            offerDiscount = 1000
        )
        assertEquals(10470, student.effectiveTotalFees)
        assertEquals(5470, student.remainingFees)
        assertEquals("Pending", student.feeStatus)

        val fullyPaid = student.copy(paidFees = 10470)
        assertEquals(0, fullyPaid.remainingFees)
        assertEquals("Paid", fullyPaid.feeStatus)
    }

    @Test
    fun examResultComputedMetrics_calculatePercentageAndGrade() {
        val result = ExamResult(
            id = "RES_1",
            studentId = "HD_T1",
            examName = "Monthly Test",
            standard = "Std 10",
            scores = listOf(
                SubjectScore("Maths", 92, 100),
                SubjectScore("Science", 88, 100)
            )
        )
        assertEquals(180, result.totalObtained)
        assertEquals(200, result.totalMax)
        assertEquals(90f, result.percentage, 0.01f)
        assertEquals("A1", result.grade)
    }

    @Test
    fun specialOffer_calculatesDiscountsAndValidatesEligibilityCorrectly() {
        val nowMs = 1_800_000_000_000L
        val pctOffer = SpecialOffer(
            id = "OFF_PCT",
            title = "Board 10% Off",
            discountType = OfferDiscountType.PERCENTAGE,
            discountValue = 10,
            applicableStandards = listOf("Std 10", "Std 12"),
            targetAudience = OfferAudience.ALL,
            startDateEpochMs = nowMs - 86_400_000L,
            endDateEpochMs = nowMs + (3L * 86_400_000L),
            maxClaims = 3,
            claimedCount = 1,
            isActive = true
        )
        assertEquals(1199, pctOffer.calculateDiscountForFee(11999))
        assertTrue(pctOffer.matchesStandard("Std 10"))
        assertTrue(pctOffer.matchesStandard("ધોરણ ૧૦ (Std 10 GSEB)"))
        assertFalse(pctOffer.matchesStandard("Std 1"))
        assertFalse(pctOffer.matchesStandard("Std 11"))
        assertTrue(pctOffer.isWithinDateWindow(nowMs))
        assertFalse(pctOffer.isExpired(nowMs))
        assertEquals(2, pctOffer.remainingClaimsCount())
        assertTrue(pctOffer.remainingValidityLabel(isGu = false, nowMs = nowMs).contains("3 d"))

        val fixedOffer = SpecialOffer(
            id = "OFF_FIX",
            title = "New Admission ₹500 Off",
            discountType = OfferDiscountType.FIXED,
            discountValue = 500,
            applicableStandards = listOf("All"),
            targetAudience = OfferAudience.NEW,
            startDateEpochMs = nowMs - 86_400_000L,
            endDateEpochMs = nowMs + 86_400_000L,
            maxClaims = 5,
            claimedCount = 5,
            isActive = true
        )
        assertEquals(500, fixedOffer.calculateDiscountForFee(3599))
        assertEquals(3599, fixedOffer.copy(discountValue = 10000).calculateDiscountForFee(3599))
        assertFalse(fixedOffer.hasRemainingClaims())

        val newStudent = Student(
            id = "S_NEW",
            standard = "Std 5",
            totalFees = 5999,
            paidFees = 0,
            createdAt = Timestamp(Date(nowMs))
        )
        val existingStudent = Student(
            id = "S_OLD",
            standard = "Std 5",
            totalFees = 5999,
            paidFees = 1000,
            createdAt = Timestamp(Date(nowMs - 5L * 86_400_000L))
        )
        val openNewOffer = fixedOffer.copy(claimedCount = 0)
        assertTrue(openNewOffer.isEligibleFor(newStudent, nowMs))
        assertFalse(openNewOffer.isEligibleFor(existingStudent, nowMs))

        val existingOnlyOffer = openNewOffer.copy(targetAudience = OfferAudience.EXISTING)
        assertTrue(existingOnlyOffer.isEligibleFor(existingStudent, nowMs))
        assertFalse(existingOnlyOffer.isEligibleFor(newStudent, nowMs))
    }
}
