package com.example.base

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.HDTuitionRepository
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import org.junit.After
import org.junit.Before
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.net.HttpURLConnection
import java.net.URL

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
@LooperMode(LooperMode.Mode.INSTRUMENTATION_TEST)
abstract class FirestoreEmulatorTestBase {

    protected lateinit var firestore: FirebaseFirestore
    protected lateinit var auth: FirebaseAuth
    protected lateinit var databaseId: String

    @Before
    open fun setUpFirebase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
        databaseId = if (resId != 0) context.getString(resId) else DEFAULT_DB_ID

        val app = if (FirebaseApp.getApps(context).isEmpty()) {
            val newApp = FirebaseApp.initializeApp(
                context,
                FirebaseOptions.Builder()
                    .setApplicationId("com.example.app")
                    .setProjectId(PROJECT_ID)
                    .setApiKey(EMULATOR_API_KEY)
                    .build()
            )
            val newFirestore = FirebaseFirestore.getInstance(newApp, databaseId)
            newFirestore.useEmulator(EMULATOR_HOST, FIRESTORE_PORT)
            newFirestore.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()

            val newAuth = FirebaseAuth.getInstance(newApp)
            newAuth.useEmulator(EMULATOR_HOST, AUTH_PORT)
            newApp
        } else {
            FirebaseApp.getInstance()
        }

        firestore = FirebaseFirestore.getInstance(app, databaseId)
        auth = FirebaseAuth.getInstance(app)
    }

    @After
    open fun tearDownFirebase() {
        auth.signOut()
    }

    protected suspend fun clearEmulatorFirestore() = withContext(Dispatchers.IO) {
        withTimeout(AUTH_TIMEOUT_MS) {
            val url = URL(
                "http://$EMULATOR_HOST:$FIRESTORE_PORT/emulator/v1/projects/$PROJECT_ID/databases/$databaseId/documents"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "DELETE"
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            val code = conn.responseCode
            conn.disconnect()
            check(code in 200..299) { "Failed to clear Firestore emulator data: HTTP $code" }
        }
    }

    protected suspend fun signInTestUser(email: String): String = withContext(Dispatchers.IO) {
        withTimeout(AUTH_TIMEOUT_MS) {
            val result = try {
                auth.signInWithEmailAndPassword(email, DEFAULT_PASSWORD).await()
            } catch (unused: FirebaseAuthInvalidUserException) {
                auth.createUserWithEmailAndPassword(email, DEFAULT_PASSWORD).await()
            }
            checkNotNull(result.user?.uid) { "User auth failed for $email" }
        }
    }

    protected suspend fun signInVerifiedOwner(): String = withContext(Dispatchers.IO) {
        withTimeout(AUTH_TIMEOUT_MS) {
            val result = try {
                auth.signInWithEmailAndPassword(HDTuitionRepository.OWNER_EMAIL, DEFAULT_PASSWORD).await()
            } catch (unused: FirebaseAuthInvalidUserException) {
                auth.createUserWithEmailAndPassword(HDTuitionRepository.OWNER_EMAIL, DEFAULT_PASSWORD).await()
            }
            val user = checkNotNull(result.user) { "Owner auth failed" }
            if (!user.isEmailVerified) {
                user.sendEmailVerification().await()
                val url = URL("http://$EMULATOR_HOST:$AUTH_PORT/emulator/v1/projects/$PROJECT_ID/oobCodes")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4000
                    readTimeout = 4000
                }
                val code = conn.responseCode
                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                check(code in 200..299) { "Failed to query Auth emulator oobCodes: HTTP $code" }

                val oobArray = JSONObject(responseText).optJSONArray("oobCodes")
                var oobCode: String? = null
                if (oobArray != null) {
                    for (i in oobArray.length() - 1 downTo 0) {
                        val item = oobArray.getJSONObject(i)
                        if (item.optString("email").equals(HDTuitionRepository.OWNER_EMAIL, ignoreCase = true) &&
                            item.optString("requestType") == "VERIFY_EMAIL"
                        ) {
                            oobCode = item.optString("oobCode")
                            break
                        }
                    }
                }
                check(!oobCode.isNullOrBlank()) { "No VERIFY_EMAIL oobCode found in emulator response" }
                auth.applyActionCode(oobCode).await()
                user.reload().await()
                user.getIdToken(true).await()
            } else {
                user.getIdToken(true).await()
            }
            check(user.isEmailVerified) { "Owner user emailVerified is still false" }
            user.uid
        }
    }

    protected fun Throwable.unwrapFirestoreException(): FirebaseFirestoreException? {
        var current: Throwable? = this
        while (current != null) {
            if (current is FirebaseFirestoreException) return current
            current = current.cause
        }
        return null
    }

    protected companion object {
        const val EMULATOR_HOST = "127.0.0.1"
        const val FIRESTORE_PORT = 8085
        const val AUTH_PORT = 9099
        const val PROJECT_ID = "demo-no-project"
        const val DEFAULT_DB_ID = "ai-studio-android-e037186c-e77c-4dfe-8d92-249de20e1cf5"
        const val EMULATOR_API_KEY = "fake-api-key-for-emulator"
        const val DEFAULT_PASSWORD = "password123"
        const val AUTH_TIMEOUT_MS = 8000L
    }
}
