package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdmissionInquiry
import com.example.data.model.AppLanguage
import com.example.data.model.InquiryStatus
import com.example.data.repository.HDTuitionRepository
import com.example.ui.components.HDLogo
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdmissionScreen(
    repository: HDTuitionRepository,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentLang by repository.currentLanguage.collectAsState()
    val settings by repository.settings.collectAsState()
    val isGu = currentLang == AppLanguage.GUJARATI

    var studentName by remember { mutableStateOf("") }
    var parentName by remember { mutableStateOf("") }
    var mobileNumber by remember { mutableStateOf("") }
    var whatsappNumber by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var selectedStandard by remember { mutableStateOf("ધોરણ ૧૦ (Std 10)") }
    var previousSchool by remember { mutableStateOf("") }
    var specialNotes by remember { mutableStateOf("") }

    val standardOptions = listOf(
        "ધોરણ ૧ (Std 1)",
        "ધોરણ ૨ (Std 2)",
        "ધોરણ ૩ (Std 3)",
        "ધોરણ ૪ (Std 4)",
        "ધોરણ ૫ (Std 5)",
        "ધોરણ ૬ (Std 6)",
        "ધોરણ ૭ (Std 7)",
        "ધોરણ ૮ (Std 8)",
        "ધોરણ ૯ (Std 9)",
        "ધોરણ ૧૦ (Std 10 GSEB)",
        "ધોરણ ૧૧ કોમર્સ (Std 11 Commerce)",
        "ધોરણ ૧૨ કોમર્સ (Std 12 Commerce)",
        "ધોરણ ૧૧ આર્ટસ (Std 11 Arts)",
        "ધોરણ ૧૨ આર્ટસ (Std 12 Arts)"
    )

    var standardDropdownExpanded by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) }
    var isSubmitted by remember { mutableStateOf(false) }
    var generatedInquiryId by remember { mutableStateOf("") }

    val todayStr = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
    val founderName = settings.founderName.ifBlank { "Harshadsinh Rathod" }
    val contactPhone = settings.contactPhone.ifBlank { "+91 85112 73911" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isGu) "નવું એડમિશન ફોર્મ" else "New Admission Form",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("admission_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
            )
        },
        modifier = modifier
    ) { innerPadding ->
        if (isSubmitted) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = StatusSuccess,
                    modifier = Modifier.size(72.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (isGu) "એડમિશન ફોર્મ સફળતાપૂર્વક સબમિટ થયું!" else "Admission Inquiry Submitted!",
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = PurplePrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PurpleContainer,
                    modifier = Modifier.padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isGu) "તમારો ઇન્ક્વાયરી નંબર (Inquiry ID)" else "Your Inquiry ID",
                            fontSize = 12.sp,
                            color = PurplePrimary
                        )
                        Text(
                            text = generatedInquiryId,
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            color = PurplePrimary
                        )
                    }
                }

                Text(
                    text = if (isGu) {
                        "સંચાલક $founderName ($contactPhone) ટૂંક સમયમાં તમારો સંપર્ક કરશે. તમે એડવાન્સ સીટ બુકિંગ ₹${settings.advanceBookingAmount} પણ કરી શકો છો."
                    } else {
                        "Director $founderName ($contactPhone) will contact you shortly. You may also reserve your seat for ₹${settings.advanceBookingAmount}."
                    },
                    fontSize = 13.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admission_done_btn")
                ) {
                    Text(
                        text = if (isGu) "હોમ પેજ પર પાછા જાઓ" else "Back to Home",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PurpleContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HDLogo(size = 44.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = settings.businessName.ifBlank { "HD TUITION CLASSES" },
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = PurplePrimary
                            )
                            Text(
                                text = if (isGu) "નવું સત્ર પ્રવેશ ફોર્મ" else "New Session Admission Form",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = GoldYellowDeep
                            )
                            Text(
                                text = "ગુજરાતી માધ્યમ • ધોરણ ૧ થી ૧૨",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = studentName,
                    onValueChange = { studentName = it },
                    label = { Text(if (isGu) "વિદ્યાર્થીનું પૂરું નામ (Student Name) *" else "Student Full Name *") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_name"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = parentName,
                    onValueChange = { parentName = it },
                    label = { Text(if (isGu) "વાલીનું પૂરું નામ (Parent / Guardian Name) *" else "Parent/Guardian Name *") },
                    leadingIcon = { Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_parent_name"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = { if (it.length <= 10) mobileNumber = it.filter { ch -> ch.isDigit() } },
                    label = { Text(if (isGu) "મોબાઇલ નંબર (10 અંક) *" else "Mobile Number (10 digits) *") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PurplePrimary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_mobile_number"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = whatsappNumber,
                    onValueChange = { if (it.length <= 10) whatsappNumber = it.filter { ch -> ch.isDigit() } },
                    label = { Text(if (isGu) "વોટ્સએપ નંબર (WhatsApp Number)" else "WhatsApp Number") },
                    leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null, tint = PurplePrimary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_whatsapp_number"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(
                    expanded = standardDropdownExpanded,
                    onExpandedChange = { standardDropdownExpanded = !standardDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedStandard,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isGu) "પ્રવેશ મેળવવાનું ધોરણ (Standard) *" else "Standard *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = standardDropdownExpanded) },
                        leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = PurplePrimary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                            .testTag("input_standard_select"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = standardDropdownExpanded,
                        onDismissRequest = { standardDropdownExpanded = false }
                    ) {
                        standardOptions.forEach { std ->
                            DropdownMenuItem(
                                text = { Text(std) },
                                onClick = {
                                    selectedStandard = std
                                    standardDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = "ગુજરાતી માધ્યમ (Gujarati Medium)",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(if (isGu) "માધ્યમ (Medium)" else "Medium") },
                    leadingIcon = { Icon(Icons.Default.Translate, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_medium"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = dob,
                    onValueChange = { dob = it },
                    label = { Text(if (isGu) "જન્મ તારીખ (DOB - e.g. 15-08-2010)" else "Date of Birth (DD-MM-YYYY)") },
                    leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_dob"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(if (isGu) "સરનામું અને ગામ (Address & Village) *" else "Address & Village *") },
                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_address"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = false,
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = previousSchool,
                    onValueChange = { previousSchool = it },
                    label = { Text(if (isGu) "અગાઉની શાળાનું નામ (Previous School Name)" else "Previous School Name") },
                    leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_previous_school"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = todayStr,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(if (isGu) "એડમિશન તારીખ (Admission Date)" else "Admission Date") },
                    leadingIcon = { Icon(Icons.Default.Today, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_admission_date"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = specialNotes,
                    onValueChange = { specialNotes = it },
                    label = { Text(if (isGu) "કોઈ ખાસ નોંધ / ઇચ્છિત વિષયો (Optional)" else "Special Notes / Subjects") },
                    leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_notes"),
                    shape = RoundedCornerShape(12.dp),
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (studentName.isBlank() || parentName.isBlank() || mobileNumber.length < 10 || address.isBlank()) {
                            Toast.makeText(
                                context,
                                if (isGu) "કૃપા કરીને જરૂરી વિગતો અને ૧૦ અંકનો મોબાઇલ લખો (*)" else "Please fill required fields and 10-digit mobile",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }

                        val inquiry = AdmissionInquiry(
                            studentName = studentName.trim(),
                            parentName = parentName.trim(),
                            mobileNumber = mobileNumber.trim(),
                            whatsappNumber = if (whatsappNumber.isNotBlank()) whatsappNumber.trim() else mobileNumber.trim(),
                            address = address.trim(),
                            dateOfBirth = dob.trim(),
                            standard = selectedStandard,
                            medium = "ગુજરાતી માધ્યમ",
                            previousSchool = previousSchool.trim().ifBlank { "સ્થાનિક શાળા" },
                            submissionDate = todayStr,
                            status = InquiryStatus.PENDING,
                            notes = specialNotes.trim()
                        )
                        scope.launch {
                            isSubmitting = true
                            val result = repository.submitAdmission(inquiry)
                            isSubmitting = false
                            result.onSuccess { saved ->
                                generatedInquiryId = saved.id
                                isSubmitted = true
                            }.onFailure { err ->
                                Toast.makeText(context, err.message ?: "Submission failed", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !isSubmitting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_admission_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGu) "એડમિશન ફોર્મ સબમિટ કરો" else "Submit Admission Form",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
