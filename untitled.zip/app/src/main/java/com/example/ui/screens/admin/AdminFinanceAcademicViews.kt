package com.example.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.HDTuitionRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ========================================================
// SECTION 4: FEES MANAGEMENT
// ========================================================
@Composable
fun AdminFeesView(
    students: List<Student>,
    isBusy: Boolean,
    onRecordPayment: () -> Unit,
    onApplySpecialDiscount: (studentId: String, discountAmount: Int, reason: String) -> Unit
) {
    val context = LocalContext.current
    var discountTargetStudent by remember { mutableStateOf<Student?>(null) }
    var discountAmountStr by remember { mutableStateOf("") }
    var discountReason by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "ફી વસૂલાત અને છૂટ (${students.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PurplePrimary)
            Button(
                onClick = onRecordPayment,
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ફી જમા કરો", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (students.isEmpty()) {
                item { AdminEmptyStateCard("હજુ સુધી કોઈ વિદ્યાર્થી ઉમેરાયેલ નથી.") }
            } else {
                items(students, key = { it.id }) { std ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = std.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                                    Text(text = "ID: ${std.id} • ${std.standard}", fontSize = 11.sp, color = TextMuted)
                                }
                                Text(
                                    text = if (std.remainingFees == 0) "પૂર્ણ ભરેલ" else "બાકી: ₹${std.remainingFees}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (std.remainingFees == 0) StatusSuccess else StatusWarning
                                )
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = BorderSubtle)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "વાર્ષિક ફી: ₹${std.totalFees} (અસરકારક: ₹${std.effectiveTotalFees})", fontSize = 11.sp)
                                    Text(text = "જમા: ₹${std.paidFees} • છૂટ: ₹${std.spinDiscount + std.specialDiscount}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusSuccess)
                                }
                                OutlinedButton(
                                    onClick = {
                                        discountTargetStudent = std
                                        discountAmountStr = std.specialDiscount.toString()
                                        discountReason = std.discountReason
                                    },
                                    enabled = !isBusy,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("છૂટ / માફી", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (discountTargetStudent != null) {
        val target = discountTargetStudent!!
        AlertDialog(
            onDismissRequest = { discountTargetStudent = null },
            title = { Text("ખાસ ફી છૂટ / માફી (${target.name})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "કુલ વાર્ષિક ફી: ₹${target.totalFees}", fontSize = 12.sp, color = TextDark)
                    OutlinedTextField(
                        value = discountAmountStr,
                        onValueChange = { discountAmountStr = it },
                        label = { Text("સ્પેશિયલ ડિસ્કાઉન્ટ / ફી માફી રકમ (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = discountReason,
                        onValueChange = { discountReason = it },
                        label = { Text("કારણ (દા.ત. જૂના વિદ્યાર્થી ઑફર / જરૂરિયાતમંદ માફી)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = discountAmountStr.toIntOrNull()
                        if (amt == null || amt < 0) {
                            Toast.makeText(context, "સાચી રકમ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onApplySpecialDiscount(target.id, amt, discountReason.ifBlank { "Admin Special Discount" })
                        discountTargetStudent = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("સેવ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { discountTargetStudent = null }) { Text("રદ કરો") }
            }
        )
    }
}

// ========================================================
// SECTION 5: RECEIPTS MANAGEMENT (WITH UPI UTR VERIFICATION)
// ========================================================
@Composable
fun AdminReceiptsView(
    receipts: List<FeeReceipt>,
    isBusy: Boolean,
    onViewReceipt: (FeeReceipt) -> Unit,
    onVerifyPendingReceipt: (receiptId: String, approve: Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "સત્તાવાર ફી પાવતીઓ અને UPI ચકાસણી (${receipts.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
        }

        if (receipts.isEmpty()) {
            item { AdminEmptyStateCard("હજુ સુધી કોઈ ફી પાવતી બનેલ નથી.") }
        } else {
            items(receipts, key = { it.id }) { rec ->
                val statusColor = when (rec.paymentStatus) {
                    "SUCCESS" -> StatusSuccess
                    "PENDING_VERIFICATION" -> StatusWarning
                    else -> StatusError
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = rec.receiptNo, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                Text(text = "${rec.studentName} (${rec.standard})", fontSize = 12.sp, color = TextDark)
                                Text(
                                    text = "તારીખ: ${rec.paymentDate} • રકમ: ₹${rec.amountPaid} (${rec.paymentStatus})",
                                    fontSize = 11.sp,
                                    color = statusColor,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (rec.transactionRef.isNotBlank()) {
                                    Text(text = "Ref/UTR: ${rec.transactionRef}", fontSize = 10.sp, color = TextMuted)
                                }
                            }

                            Button(
                                onClick = { onViewReceipt(rec) },
                                colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("પાવતી જુઓ", color = PurplePrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (rec.paymentStatus == "PENDING_VERIFICATION") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onVerifyPendingReceipt(rec.id, true) },
                                    enabled = !isBusy,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("વેરિફાય & જમા ગણો ✓", fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { onVerifyPendingReceipt(rec.id, false) },
                                    enabled = !isBusy,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("રદ / અસ્વીકાર", fontSize = 11.sp, color = StatusError)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// SECTION 6: ATTENDANCE MANAGEMENT
// ========================================================
@Composable
fun AdminAttendanceView(
    students: List<Student>,
    repository: HDTuitionRepository
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isSaving by remember { mutableStateOf(false) }
    val todayDate = remember { SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date()) }

    val attendanceMap = remember { mutableStateMapOf<String, AttendanceStatus>() }
    LaunchedEffect(students) {
        students.forEach { std ->
            if (!attendanceMap.containsKey(std.id)) {
                attendanceMap[std.id] = AttendanceStatus.PRESENT
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "દૈનિક હાજરી માર્કિંગ", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PurplePrimary)
                    Text(text = "તારીખ: $todayDate (${students.size} વિદ્યાર્થી)", fontSize = 12.sp, color = TextMuted)
                }

                Button(
                    onClick = {
                        if (students.isEmpty()) return@Button
                        coroutineScope.launch {
                            isSaving = true
                            val records = students.map {
                                AttendanceRecord(
                                    studentId = it.id,
                                    studentAuthUid = it.authUid,
                                    standard = it.standard,
                                    date = todayDate,
                                    status = attendanceMap[it.id] ?: AttendanceStatus.PRESENT
                                )
                            }
                            val res = repository.markBatchAttendance(records)
                            isSaving = false
                            res.onSuccess {
                                Toast.makeText(context, "આજની હાજરી સફળતાપૂર્વક નોંધાઈ ગઈ!", Toast.LENGTH_SHORT).show()
                            }.onFailure { err ->
                                Toast.makeText(context, err.localizedMessage ?: "Attendance failed", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !isSaving && students.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("હાજરી સેવ કરો", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (students.isEmpty()) {
            item { AdminEmptyStateCard("હાજરી નોંધવા માટે પહેલા વિદ્યાર્થી ઉમેરો અથવા મંજૂર કરો.") }
        } else {
            items(students, key = { it.id }) { std ->
                val status = attendanceMap[std.id] ?: AttendanceStatus.PRESENT
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = std.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextDark)
                            Text(text = "${std.standard} • ID: ${std.id}", fontSize = 11.sp, color = TextMuted)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = status == AttendanceStatus.PRESENT,
                                onClick = { attendanceMap[std.id] = AttendanceStatus.PRESENT },
                                label = { Text("P", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StatusSuccessContainer,
                                    selectedLabelColor = StatusSuccess
                                )
                            )
                            FilterChip(
                                selected = status == AttendanceStatus.ABSENT,
                                onClick = { attendanceMap[std.id] = AttendanceStatus.ABSENT },
                                label = { Text("A", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StatusErrorContainer,
                                    selectedLabelColor = StatusError
                                )
                            )
                            FilterChip(
                                selected = status == AttendanceStatus.LEAVE,
                                onClick = { attendanceMap[std.id] = AttendanceStatus.LEAVE },
                                label = { Text("L", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StatusWarningContainer,
                                    selectedLabelColor = StatusWarning
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// SECTION 7: HOMEWORK MANAGEMENT
// ========================================================
@Composable
fun AdminHomeworkView(
    homeworkList: List<HomeworkItem>,
    onAddHomework: () -> Unit,
    onDeleteHomework: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "ગૃહકાર્ય સંચાલન (${homeworkList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PurplePrimary)
            Button(
                onClick = onAddHomework,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("હોમવર્ક ઉમેરો", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (homeworkList.isEmpty()) {
                item { AdminEmptyStateCard("હજુ સુધી કોઈ ગૃહકાર્ય મૂકાયેલ નથી.") }
            } else {
                items(homeworkList, key = { it.id }) { hw ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "${hw.standard} • ${hw.subject}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                IconButton(onClick = { onDeleteHomework(hw.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusError)
                                }
                            }
                            Text(text = hw.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextDark)
                            if (hw.description.isNotBlank()) {
                                Text(text = hw.description, fontSize = 12.sp, color = TextMuted)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "જમા તારીખ: ${hw.dueDate} • શિક્ષક: ${hw.teacherName}", fontSize = 10.sp, color = GoldYellowDeep)
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// SECTION 8: RESULTS & TOPPERS MANAGEMENT
// ========================================================
@Composable
fun AdminResultsView(
    students: List<Student>,
    toppers: List<TopperResult>,
    repository: HDTuitionRepository
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isSaving by remember { mutableStateOf(false) }

    var selectedStudentId by remember { mutableStateOf("") }
    LaunchedEffect(students) {
        if (selectedStudentId.isBlank() || students.none { it.id == selectedStudentId }) {
            selectedStudentId = students.firstOrNull()?.id.orEmpty()
        }
    }
    var examName by remember { mutableStateOf("સાપ્તાહિક મોક ટેસ્ટ (Weekly Test)") }
    var subj1Name by remember { mutableStateOf("ગણિત / એકાઉન્ટ") }
    var mathMarks by remember { mutableStateOf("45") }
    var subj2Name by remember { mutableStateOf("વિજ્ઞાન / સ્ટેટ") }
    var sciMarks by remember { mutableStateOf("42") }
    var showAddTopperDialog by remember { mutableStateOf(false) }

    val examDateStr = remember { SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "પરીક્ષા પરિણામ એન્ટ્રી (Marks Entry)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (students.isEmpty()) {
                        Text(text = "પહેલા વિદ્યાર્થી ઉમેરો પછી પરિણામ એન્ટ્રી કરી શકાશે.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        Text(text = "વિદ્યાર્થી પસંદ કરો:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        students.forEach { std ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedStudentId = std.id }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedStudentId == std.id,
                                    onClick = { selectedStudentId = std.id }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "${std.name} (${std.standard} • ${std.id})", fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = examName,
                            onValueChange = { examName = it },
                            label = { Text("પરીક્ષાનું નામ (Exam Name)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = subj1Name,
                                onValueChange = { subj1Name = it },
                                label = { Text("વિષય ૧") },
                                modifier = Modifier.weight(1.3f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = mathMarks,
                                onValueChange = { mathMarks = it },
                                label = { Text("ગુણ (/50)") },
                                modifier = Modifier.weight(0.7f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = subj2Name,
                                onValueChange = { subj2Name = it },
                                label = { Text("વિષય ૨") },
                                modifier = Modifier.weight(1.3f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = sciMarks,
                                onValueChange = { sciMarks = it },
                                label = { Text("ગુણ (/50)") },
                                modifier = Modifier.weight(0.7f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val targetStudent = students.firstOrNull { it.id == selectedStudentId }
                                if (targetStudent == null || examName.trim().length < 2) {
                                    Toast.makeText(context, "વિદ્યાર્થી અને પરીક્ષાનું નામ લખો", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val m1 = (mathMarks.toIntOrNull() ?: 0).coerceIn(0, 50)
                                val m2 = (sciMarks.toIntOrNull() ?: 0).coerceIn(0, 50)
                                coroutineScope.launch {
                                    isSaving = true
                                    val res = ExamResult(
                                        studentId = selectedStudentId,
                                        studentAuthUid = targetStudent.authUid,
                                        examName = examName.trim(),
                                        examDate = examDateStr,
                                        standard = targetStudent.standard,
                                        scores = listOf(
                                            SubjectScore(subj1Name.ifBlank { "વિષય ૧" }, m1, 50),
                                            SubjectScore(subj2Name.ifBlank { "વિષય ૨" }, m2, 50)
                                        )
                                    )
                                    val result = repository.addExamResult(res)
                                    isSaving = false
                                    result.onSuccess {
                                        Toast.makeText(context, "પરિણામ સેવ થઈ ગયું! (%.1f%%)".format(it.percentage), Toast.LENGTH_SHORT).show()
                                    }.onFailure { err ->
                                        Toast.makeText(context, err.localizedMessage ?: "Marks save failed", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isSaving,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("પરિણામ સેવ કરો (Save Marks)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "હોમપેજ બોર્ડ ટોપર્સ (${toppers.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = PurplePrimary
                )
                Button(
                    onClick = { showAddTopperDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ ટોપર ઉમેરો", color = TextDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (toppers.isEmpty()) {
            item { AdminEmptyStateCard("હજુ સુધી કોઈ બોર્ડ ટોપર ઉમેરેલ નથી.") }
        } else {
            items(toppers, key = { it.id }) { top ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "${top.studentName} • ${top.percentage}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                            Text(text = "${top.standard} (${top.year}) • ${top.school}", fontSize = 11.sp, color = TextMuted)
                        }
                        IconButton(onClick = {
                            coroutineScope.launch {
                                repository.deletePublicTopper(top.id)
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Topper", tint = StatusError)
                        }
                    }
                }
            }
        }
    }

    if (showAddTopperDialog) {
        var studentName by remember { mutableStateOf("") }
        var standard by remember { mutableStateOf("Std 10") }
        var percentage by remember { mutableStateOf("") }
        var year by remember { mutableStateOf("2025") }
        var school by remember { mutableStateOf("") }
        var remark by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddTopperDialog = false },
            title = { Text("બોર્ડ ટોપર ઉમેરો (Public Results)") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = studentName, onValueChange = { studentName = it }, label = { Text("વિદ્યાર્થીનું નામ *") }, singleLine = true)
                    OutlinedTextField(value = standard, onValueChange = { standard = it }, label = { Text("ધોરણ *") }, singleLine = true)
                    OutlinedTextField(value = percentage, onValueChange = { percentage = it }, label = { Text("ટકાવારી / PR (દા.ત. 95.4%) *") }, singleLine = true)
                    OutlinedTextField(value = year, onValueChange = { year = it }, label = { Text("વર્ષ *") }, singleLine = true)
                    OutlinedTextField(value = school, onValueChange = { school = it }, label = { Text("શાળા") }, singleLine = true)
                    OutlinedTextField(value = remark, onValueChange = { remark = it }, label = { Text("નોંધ / ઉપલબ્ધિ") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (studentName.trim().length < 2 || percentage.isBlank() || year.trim().length < 2) {
                            Toast.makeText(context, "નામ, ટકાવારી અને વર્ષ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        coroutineScope.launch {
                            val res = repository.addPublicTopper(
                                TopperResult(
                                    studentName = studentName.trim(),
                                    standard = standard.trim(),
                                    percentage = percentage.trim(),
                                    year = year.trim(),
                                    school = school.trim(),
                                    remark = remark.trim()
                                )
                            )
                            res.onSuccess {
                                showAddTopperDialog = false
                                Toast.makeText(context, "ટોપર ઉમેરાયા!", Toast.LENGTH_SHORT).show()
                            }.onFailure { err ->
                                Toast.makeText(context, err.localizedMessage ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("સેવ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTopperDialog = false }) { Text("રદ કરો") }
            }
        )
    }
}
