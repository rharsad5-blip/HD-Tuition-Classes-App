package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdvanceBooking
import com.example.data.model.AppLanguage
import com.example.data.model.BookingPaymentStatus
import com.example.data.repository.HDTuitionRepository
import com.example.ui.components.HDLogo
import com.example.ui.components.PaymentQRCodeView
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvanceBookingScreen(
    repository: HDTuitionRepository,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentLang by repository.currentLanguage.collectAsState()
    val settings by repository.settings.collectAsState()
    val isGu = currentLang == AppLanguage.GUJARATI
    val bookingAmount = settings.advanceBookingAmount.coerceAtLeast(1)

    var currentStep by remember { mutableIntStateOf(1) }
    var isSubmitting by remember { mutableStateOf(false) }

    var studentName by remember { mutableStateOf("") }
    var selectedStandard by remember { mutableStateOf("ધોરણ ૧૦ (Std 10)") }
    var parentName by remember { mutableStateOf("") }
    var mobileNumber by remember { mutableStateOf("") }
    var whatsappNumber by remember { mutableStateOf("") }
    var upiTxnId by remember { mutableStateOf("") }
    var paymentConfirmedToggle by remember { mutableStateOf(false) }
    var generatedBookingId by remember { mutableStateOf("") }

    val standardOptions = listOf(
        "ધોરણ ૧ (Std 1)", "ધોરણ ૨ (Std 2)", "ધોરણ ૩ (Std 3)",
        "ધોરણ ૪ (Std 4)", "ધોરણ ૫ (Std 5)", "ધોરણ ૬ (Std 6)",
        "ધોરણ ૭ (Std 7)", "ધોરણ ૮ (Std 8)", "ધોરણ ૯ (Std 9)",
        "ધોરણ ૧૦ (Std 10 GSEB)", "ધોરણ ૧૧ કોમર્સ (Std 11)",
        "ધોરણ ૧૨ કોમર્સ (Std 12)", "ધોરણ ૧૧ આર્ટસ (Std 11)",
        "ધોરણ ૧૨ આર્ટસ (Std 12)"
    )
    var standardDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isGu) "એડવાન્સ સીટ બુકિંગ ₹$bookingAmount" else "Advance Seat Booking ₹$bookingAmount",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("booking_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            Surface(
                color = PurpleContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StepBadge(stepNum = 1, title = if (isGu) "વિદ્યાર્થી વિગત" else "Details", active = currentStep >= 1)
                    HorizontalDivider(modifier = Modifier.width(30.dp), color = PurpleMedium)
                    StepBadge(stepNum = 2, title = if (isGu) "QR પેમેન્ટ ₹$bookingAmount" else "Payment", active = currentStep >= 2)
                    HorizontalDivider(modifier = Modifier.width(30.dp), color = PurpleMedium)
                    StepBadge(stepNum = 3, title = if (isGu) "પુષ્ટિ" else "Receipt", active = currentStep >= 3)
                }
            }

            when (currentStep) {
                1 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = GoldYellowContainer)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(GoldYellow),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("₹$bookingAmount", fontWeight = FontWeight.Black, fontSize = 15.sp, color = TextDark)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isGu) "મર્યાદિત ૨૫ બેઠકો માટે વિશેષ ઑફર (2027-28)" else "Special Early Seat Booking (2027-28)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextDark
                                    )
                                    Text(
                                        text = if (isGu) "માત્ર ₹$bookingAmount માં બેઠક આરક્ષિત કરો + મફત સ્ટડી મટિરિયલ કિટ" else "Reserve seat for ₹$bookingAmount + Free study material kit",
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = studentName,
                            onValueChange = { studentName = it },
                            label = { Text(if (isGu) "૧. વિદ્યાર્થીનું નામ (Student Name) *" else "1. Student Full Name *") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_student_name"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        ExposedDropdownMenuBox(
                            expanded = standardDropdownExpanded,
                            onExpandedChange = { standardDropdownExpanded = !standardDropdownExpanded },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedStandard,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text(if (isGu) "૨. ધોરણ પસંદ કરો (Select Standard) *" else "2. Select Standard *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = standardDropdownExpanded) },
                                leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = PurplePrimary) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .testTag("booking_standard_select"),
                                shape = RoundedCornerShape(12.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = standardDropdownExpanded,
                                onDismissRequest = { standardDropdownExpanded = false }
                            ) {
                                standardOptions.forEach { std ->
                                    DropdownMenuItem(
                                        text = { Text(std) },
                                        onClick = {
                                            selectedStandard = std
                                            standardDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = parentName,
                            onValueChange = { parentName = it },
                            label = { Text(if (isGu) "૩. વાલીનું નામ (Parent Name) *" else "3. Parent/Guardian Name *") },
                            leadingIcon = { Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_parent_name"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = mobileNumber,
                            onValueChange = { if (it.length <= 10) mobileNumber = it.filter { ch -> ch.isDigit() } },
                            label = { Text(if (isGu) "મોબાઇલ નંબર (10 અંક) *" else "Mobile Number (10 digits) *") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PurplePrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_mobile_number"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = whatsappNumber,
                            onValueChange = { if (it.length <= 10) whatsappNumber = it.filter { ch -> ch.isDigit() } },
                            label = { Text(if (isGu) "વોટ્સએપ નંબર (WhatsApp Number)" else "WhatsApp Number") },
                            leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null, tint = PurplePrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_whatsapp_number"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                if (studentName.isBlank() || parentName.isBlank() || mobileNumber.length < 10) {
                                    Toast.makeText(
                                        context,
                                        if (isGu) "કૃપા કરીને નામ, વાલીનું નામ અને ૧૦ અંકનો મોબાઇલ લખો (*)" else "Please enter name, parent name, and 10-digit mobile",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    return@Button
                                }
                                currentStep = 2
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_proceed_step2_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 14.dp)
                        ) {
                            Text(
                                text = if (isGu) "આગળ વધો - QR પેમેન્ટ ₹$bookingAmount" else "Proceed to Payment (₹$bookingAmount)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                        }
                    }
                }

                2 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = PurpleContainer,
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = "વિદ્યાર્થી: $studentName | $selectedStandard",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = PurplePrimary,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        PaymentQRCodeView(
                            amount = bookingAmount,
                            upiId = settings.upiId.ifBlank { "8511273911@upi" },
                            payeeName = settings.upiPayeeName.ifBlank { "Harshadsinh Rathod (HD Tuition Classes)" },
                            note = "Advance Seat Booking - $studentName"
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isGu) "૫. UPI Transaction ID / UTR નંબર દાખલ કરો *" else "5. Enter UPI Transaction ID / UTR *",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = PurplePrimary
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = upiTxnId,
                                    onValueChange = { upiTxnId = it },
                                    label = { Text(if (isGu) "૧૨ અંકનો UTR / Transaction Ref No *" else "UPI Ref / UTR Number *") },
                                    placeholder = { Text("દા.ત. 412345678901") },
                                    leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null, tint = PurplePrimary) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("booking_txn_id"),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (paymentConfirmedToggle) StatusSuccessContainer else BackgroundLight)
                                        .border(
                                            width = 1.5.dp,
                                            color = if (paymentConfirmedToggle) StatusSuccess else BorderSubtle,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { paymentConfirmedToggle = !paymentConfirmedToggle }
                                        .padding(14.dp)
                                        .testTag("upload_screenshot_btn"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (paymentConfirmedToggle) Icons.Default.CheckCircle else Icons.Default.Verified,
                                            contentDescription = null,
                                            tint = if (paymentConfirmedToggle) StatusSuccess else PurplePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = if (paymentConfirmedToggle) {
                                                "✓ મેં ₹$bookingAmount નું UPI પેમેન્ટ પૂર્ણ કર્યું છે"
                                            } else {
                                                if (isGu) "પેમેન્ટ પૂર્ણ કર્યાની ખાતરી કરવા અહીં ટિક કરો" else "Tap to confirm you completed the ₹$bookingAmount UPI payment"
                                            },
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (paymentConfirmedToggle) StatusSuccess else TextDark
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                val cleanUtr = upiTxnId.trim()
                                if (cleanUtr.length < 6) {
                                    Toast.makeText(
                                        context,
                                        if (isGu) "કૃપા કરીને તમારો સાચો UTR / Transaction ID (૬+ અક્ષર) દાખલ કરો." else "Enter valid UPI Transaction ID / UTR (min 6 chars).",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    return@Button
                                }
                                val booking = AdvanceBooking(
                                    studentName = studentName.trim(),
                                    standard = selectedStandard,
                                    parentName = parentName.trim(),
                                    mobileNumber = mobileNumber.trim(),
                                    whatsappNumber = if (whatsappNumber.isNotBlank()) whatsappNumber.trim() else mobileNumber.trim(),
                                    amount = bookingAmount,
                                    upiTransactionId = cleanUtr,
                                    paymentStatus = BookingPaymentStatus.PENDING_VERIFICATION,
                                    bookingDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date()),
                                    hasScreenshot = paymentConfirmedToggle
                                )
                                scope.launch {
                                    isSubmitting = true
                                    val result = repository.submitAdvanceBooking(booking)
                                    isSubmitting = false
                                    result.onSuccess { saved ->
                                        generatedBookingId = saved.id
                                        currentStep = 3
                                    }.onFailure { err ->
                                        Toast.makeText(context, err.message ?: "Booking failed", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isSubmitting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("submit_booking_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 14.dp)
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextDark, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Check, contentDescription = null, tint = TextDark)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isGu) "૬. સીટ બુકિંગ પૂર્ણ કરો (Submit Booking)" else "6. Submit Booking",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = TextDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        TextButton(
                            onClick = { currentStep = 1 },
                            enabled = !isSubmitting,
                            modifier = Modifier.testTag("booking_back_to_step1_btn")
                        ) {
                            Text("વિગતો સુધારો (Edit Details)", color = PurplePrimary)
                        }
                    }
                }

                3 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusSuccess,
                            modifier = Modifier.size(64.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (isGu) "એડવાન્સ સીટ બુકિંગ સફળતાપૂર્વક નોંધાયું!" else "Advance Seat Booking Submitted!",
                            fontWeight = FontWeight.Black,
                            fontSize = 19.sp,
                            color = PurplePrimary,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = if (isGu) "એડમિન દ્વારા તમારા UTRની ચકાસણી થયા પછી સીટ કન્ફર્મ થશે અને ફી પાવતી મળશે." else "Your seat will be confirmed and receipt issued once Admin verifies your UTR.",
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    HDLogo(size = 36.dp)
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = GoldYellowContainer
                                    ) {
                                        Text(
                                            text = "બુકિંગ ID: $generatedBookingId",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = GoldYellowDeep,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderSubtle)

                                BookingRow(label = "વિદ્યાર્થી (Student):", value = studentName)
                                BookingRow(label = "ધોરણ (Standard):", value = selectedStandard)
                                BookingRow(label = "વાલી (Parent):", value = parentName)
                                BookingRow(label = "મોબાઇલ (Mobile):", value = mobileNumber)
                                BookingRow(label = "બુકિંગ ફી (Fee):", value = "₹$bookingAmount (UPI: $upiTxnId)")
                                BookingRow(label = "સ્થિતિ (Status):", value = "એડમિન ચકાસણી બાકી (Pending)")
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = onBack,
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_finish_btn")
                        ) {
                            Text(
                                text = if (isGu) "હોમ પેજ પર પાછા જાઓ" else "Back to Home",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepBadge(stepNum: Int, title: String, active: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (active) PurplePrimary else PurpleMedium.copy(alpha = 0.4f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$stepNum",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            color = if (active) PurplePrimary else TextMuted
        )
    }
}

@Composable
private fun BookingRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextMuted)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextDark)
    }
}
