package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Student
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

data class SpinSector(
    val label: String,
    val discountAmount: Int,
    val isPercentage: Boolean,
    val color: Color
)

@Composable
fun SpinAndWinDialog(
    student: Student,
    onDismiss: () -> Unit,
    onSpinWon: (discountAmount: Int, prizeLabel: String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isSpinning by remember { mutableStateOf(false) }
    var wonPrize by remember { mutableStateOf<String?>(null) }
    var wonDiscount by remember { mutableStateOf(0) }
    var alreadyPlayed by remember { mutableStateOf(student.spinPlayed) }

    // Sectors on the wheel
    val sectors = remember {
        listOf(
            SpinSector("₹29 OFF", 29, false, Color(0xFF673AB7)),
            SpinSector("TRY AGAIN", 0, false, Color(0xFFFFB300)),
            SpinSector("₹49 OFF", 49, false, Color(0xFF3F51B5)),
            SpinSector("BETTER LUCK", 0, false, Color(0xFFE91E63)),
            SpinSector("3% OFF", (student.totalFees * 0.03).toInt(), true, Color(0xFF009688)),
            SpinSector("₹29 OFF", 29, false, Color(0xFFFF5722)),
            SpinSector("TRY AGAIN", 0, false, Color(0xFF9C27B0)),
            SpinSector("₹29 OFF", 29, false, Color(0xFF4CAF50))
        )
    }

    val rotationAngle = remember { Animatable(0f) }

    Dialog(onDismissRequest = { if (!isSpinning) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("spin_and_win_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Casino, contentDescription = null, tint = GoldYellow, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SPIN & WIN OFFER",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = PurplePrimary
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSpinning
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Text(
                    text = "HD Tuition વિદ્યાર્થીઓ માટે ખાસ લકી સ્પિન!\nફક્ત ૧ જ વાર રમી શકાશે - જીતો ₹49 સુધીનું ફી ડિસ્કાઉન્ટ!",
                    fontSize = 12.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Wheel container with pointer
                Box(
                    modifier = Modifier
                        .size(230.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(rotationAngle.value)
                    ) {
                        val canvasSize = size.minDimension
                        val radius = canvasSize / 2f
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val sectorAngle = 360f / sectors.size

                        for (i in sectors.indices) {
                            val startAngle = i * sectorAngle
                            drawArc(
                                color = sectors[i].color,
                                startAngle = startAngle,
                                sweepAngle = sectorAngle,
                                useCenter = true,
                                topLeft = Offset(center.x - radius, center.y - radius),
                                size = Size(radius * 2, radius * 2),
                                style = Fill
                            )

                            // Draw text in sector
                            val textAngle = Math.toRadians((startAngle + sectorAngle / 2f).toDouble())
                            val textDist = radius * 0.65f
                            val textX = (center.x + textDist * cos(textAngle)).toFloat()
                            val textY = (center.y + textDist * sin(textAngle)).toFloat()

                            drawContext.canvas.nativeCanvas.apply {
                                save()
                                rotate((startAngle + sectorAngle / 2f) + 90f, textX, textY)
                                val paint = android.graphics.Paint().apply {
                                    color = android.graphics.Color.WHITE
                                    textSize = 28f
                                    textAlign = android.graphics.Paint.Align.CENTER
                                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                                }
                                drawText(sectors[i].label, textX, textY, paint)
                                restore()
                            }
                        }
                    }

                    // Center Hub
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(3.dp, PurplePrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "HD",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )
                    }

                    // Pointer Top Arrow
                    Canvas(
                        modifier = Modifier
                            .size(26.dp)
                            .align(Alignment.TopCenter)
                            .offset(y = (-6).dp)
                    ) {
                        val path = Path().apply {
                            moveTo(size.width / 2f, size.height)
                            lineTo(0f, 0f)
                            lineTo(size.width, 0f)
                            close()
                        }
                        drawPath(path, color = Color(0xFFFFD700))
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Result display
                if (wonPrize != null) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (wonDiscount > 0) StatusSuccessContainer else PurpleContainer
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (wonDiscount > 0) "🎉 અભિનંદન! તમે જીત્યા:" else "👍 પ્રયાસ સારો રહ્યો!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (wonDiscount > 0) StatusSuccess else PurplePrimary
                            )
                            Text(
                                text = wonPrize!!,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = if (wonDiscount > 0) StatusSuccess else TextDark
                            )
                            if (wonDiscount > 0) {
                                Text(
                                    text = "આ ડિસ્કાઉન્ટ આપોઆપ તમારી વાર્ષિક ફીમાંથી બાદ કરી દેવાયું છે!",
                                    fontSize = 11.sp,
                                    color = TextDark,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Spin Button
                Button(
                    onClick = {
                        if (alreadyPlayed) return@Button
                        isSpinning = true
                        coroutineScope.launch {
                            // Guaranteed winning logic: 5 winners: ₹29 (3 students), ₹49 (1 student), 3% (1 student)
                            // Pick one of the winning sectors (index 0, 2, 4, 5, 7) or friendly trial
                            val winningIndices = listOf(0, 2, 4, 5, 7)
                            val targetIndex = winningIndices.random()
                            val sectorAngle = 360f / sectors.size
                            val targetAngle = 360f * 5 + (360f - (targetIndex * sectorAngle + sectorAngle / 2f))

                            rotationAngle.animateTo(
                                targetValue = targetAngle,
                                animationSpec = tween(
                                    durationMillis = 3500,
                                    easing = FastOutSlowInEasing
                                )
                            )

                            val prize = sectors[targetIndex]
                            wonPrize = prize.label
                            wonDiscount = prize.discountAmount
                            alreadyPlayed = true
                            isSpinning = false
                            onSpinWon(prize.discountAmount, prize.label)
                        }
                    },
                    enabled = !isSpinning && !alreadyPlayed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("spin_wheel_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (alreadyPlayed) Color.Gray else GoldYellow
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(
                        Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = if (alreadyPlayed) Color.White else TextDark
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (alreadyPlayed) "તમે સ્પિન રમી ચૂક્યા છો (Already Played)" else if (isSpinning) "ચક્ર ફરી રહ્યું છે..." else "હમણાં જ સ્પિન કરો (SPIN NOW)",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = if (alreadyPlayed) Color.White else TextDark
                    )
                }
            }
        }
    }
}
