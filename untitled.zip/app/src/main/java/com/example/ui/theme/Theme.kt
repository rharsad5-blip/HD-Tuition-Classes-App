package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = PurplePrimary,
    onPrimary = SurfaceWhite,
    primaryContainer = PurpleContainer,
    onPrimaryContainer = PurplePrimary,
    secondary = GoldYellow,
    onSecondary = TextDark,
    secondaryContainer = GoldYellowContainer,
    onSecondaryContainer = GoldYellowDeep,
    tertiary = PurpleMedium,
    onTertiary = SurfaceWhite,
    background = BackgroundLight,
    onBackground = TextDark,
    surface = SurfaceWhite,
    onSurface = TextDark,
    surfaceVariant = PurpleSurface,
    onSurfaceVariant = TextMuted,
    outline = BorderSubtle,
    error = StatusError,
    onError = SurfaceWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = PurpleMedium,
    onPrimary = SurfaceWhite,
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = PurpleContainer,
    secondary = GoldYellowLight,
    onSecondary = DarkBackground,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = GoldYellowLight,
    tertiary = PurpleLight,
    onTertiary = SurfaceWhite,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextMuted,
    outline = DarkSurfaceVariant,
    error = StatusError,
    onError = SurfaceWhite
)

@Composable
fun HDTuitionTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
