package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.data.repository.HDTuitionRepository
import com.example.ui.components.HDLogo
import com.example.ui.components.OfferBannerCard
import com.example.ui.components.OfficialReceiptCard
import com.example.ui.components.OnlinePaymentGatewayDialog
import com.example.ui.components.SpinAndWinDialog
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentPortalScreen(
    repository: HDTuitionRepository,
    initialStudent: Student? = null,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val currentLang by repository.currentLanguage.collectAsState()
    val isGu = currentLang == AppLanguage.GUJARATI

    val settings by repository.settings.collectAsState()

    var currentStudent by remember { mutableStateOf<Student?>(initialStudent) }
    var inputStudentId by remember { mutableStateOf("") }
    var inputPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoggingIn by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }

    var selectedTab by remember { mutableIntStateOf(0) }
    // 0: Profile, Overview, Notices & Timetable, 1: Attendance, 2: Homework, 3: Results, 4: Fees & Receipts

    var showPasswordChangeDialog by remember { mutableStateOf(false) }
    var showForgotHelpDialog by remember { mutableStateOf(false) }
    var showSpinDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var selectedHomeworkForSubmit by remember { mutableStateOf<HomeworkItem?>(null) }
    var homeworkSubmissionText by remember { mutableStateOf("") }
    var selectedReceiptForView by remember { mutableStateOf<FeeReceipt?>(null) }

    if (currentStudent == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = if (isGu) "વિદ્યાર્થી લૉગિન (Student Portal)" else "Student Login",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("student_login_back_btn")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
                )
            },
            modifier = modifier
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                HDLogo(size = 72.dp)
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = settings.businessName.ifBlank { "HD TUITION CLASSES" },
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = PurplePrimary
                )
                Text(
                    text = if (isGu) "વિદ્યાર્થી પોર્ટલ લૉગિન" else "Student Portal Login",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = inputStudentId,
                    onValueChange = { inputStudentId = it },
                    label = { Text(if (isGu) "વિદ્યાર્થી આઈડી અથવા મોબાઇલ *" else "Student ID or Mobile *") },
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_id_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    enabled = !isLoggingIn
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = inputPassword,
                    onValueChange = { inputPassword = it },
                    label = { Text(if (isGu) "પાસવર્ડ (Password) *" else "Password *") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (passwordVisible) "Hide Password" else "Show Password"
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_password_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    enabled = !isLoggingIn
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = if (isGu) "પાસવર્ડ ભૂલી ગયા છો?" else "Forgot Password?",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurplePrimary,
                        modifier = Modifier
                            .clickable { showForgotHelpDialog = true }
                            .padding(8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (inputStudentId.isBlank() || inputPassword.isBlank()) {
                            Toast.makeText(
                                context,
                                if (isGu) "Student ID અને પાસવર્ડ લખો" else "Please enter Student ID and Password",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }
                        coroutineScope.launch {
                            isLoggingIn = true
                            val result = repository.authenticateStudent(inputStudentId, inputPassword)
                            isLoggingIn = false
                            result.onSuccess { student ->
                                currentStudent = student
                                inputPassword = ""
                                Toast.makeText(context, "સ્વાગત છે, ${student.name}!", Toast.LENGTH_SHORT).show()
                            }.onFailure { err ->
                                Toast.makeText(
                                    context,
                                    err.localizedMessage ?: "ખોટો Student ID અથવા પાસવર્ડ!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    },
                    enabled = !isLoggingIn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_login_submit_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    if (isLoggingIn) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = if (isGu) "લૉગિન કરો (Login)" else "Login",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        if (showForgotHelpDialog) {
            AlertDialog(
                onDismissRequest = { showForgotHelpDialog = false },
                title = { Text(if (isGu) "પાસવર્ડ સહાય (Password Help)" else "Password Reset Assistance") },
                text = {
                    Text(
                        text = if (isGu) {
                            "સુરક્ષા માટે અનધિકૃત રીતે પાસવર્ડ બદલી શકાતો નથી.\n\n• જો તમે જૂનો પાસવર્ડ જાણતા હો, તો લૉગિન કર્યા પછી ઉપરના 🔒 બટનથી પાસવર્ડ બદલી શકો છો.\n• જો પાસવર્ડ ભૂલી ગયા હો, તો કૃપા કરીને સંચાલક (Admin) નો સંપર્ક કરો: ${settings.contactPhone}"
                        } else {
                            "For account security, unauthenticated password resets are disabled.\n\n• If you know your password, log in and use the top Lock icon to change it.\n• If you forgot your password, contact Admin (${settings.contactPhone}) to reset it."
                        },
                        fontSize = 13.sp,
                        color = TextDark
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showForgotHelpDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                    ) {
                        Text(if (isGu) "સમજાયું" else "OK")
                    }
                }
            )
        }
    } else {
        // Authenticated Student Dashboard
        val allStudents by repository.students.collectAsState()
        val student = allStudents.firstOrNull { it.id == currentStudent!!.id } ?: currentStudent!!

        val allAttendance by repository.attendance.collectAsState()
        val studentAttendance = remember(allAttendance, student.id) {
            allAttendance.filter { it.studentId == student.id }
        }

        val allHomework by repository.homework.collectAsState()
        val studentStdNum = HDTuitionRepository.extractStandardNumber(student.standard)
        val studentHomework = remember(allHomework, student.standard, studentStdNum) {
            allHomework.filter {
                HDTuitionRepository.extractStandardNumber(it.standard) == studentStdNum ||
                    it.standard.equals(student.standard, ignoreCase = true) ||
                    it.standard.equals("All", ignoreCase = true)
            }
        }

        val allSubmissions by repository.homeworkSubmissions.collectAsState()
        val studentSubmissions = remember(allSubmissions, student.id) {
            allSubmissions.filter { it.studentId == student.id }
        }

        val allResults by repository.examResults.collectAsState()
        val studentResults = remember(allResults, student.id) {
            allResults.filter { it.studentId == student.id }
        }

        val allReceipts by repository.receipts.collectAsState()
        val studentReceipts = remember(allReceipts, student.id) {
            allReceipts.filter { it.studentId == student.id }
        }

        val allTimetable by repository.timetable.collectAsState()
        val timetable = remember(allTimetable, student.standard, studentStdNum) {
            allTimetable.filter {
                HDTuitionRepository.extractStandardNumber(it.standard) == studentStdNum ||
                    it.standard.equals(student.standard, ignoreCase = true)
            }
        }

        val allAnnouncements by repository.announcements.collectAsState()
        val studentNotices = remember(allAnnouncements, student.standard, studentStdNum) {
            allAnnouncements.filter { ann ->
                ann.targetStandard.equals("All", ignoreCase = true) ||
                    ann.targetStandard.equals(student.standard, ignoreCase = true) ||
                    HDTuitionRepository.extractStandardNumber(ann.targetStandard) == studentStdNum
            }
        }

        val allOffers by repository.offers.collectAsState()
        val nowMs = System.currentTimeMillis()
        val eligibleOffers = remember(allOffers, student, nowMs) {
            allOffers.filter { offer ->
                offer.isWithinDateWindow(nowMs) &&
                    offer.matchesStandard(student.standard) &&
                    offer.matchesAudience(student, nowMs) &&
                    (offer.hasRemainingClaims() || student.appliedOfferId == offer.id)
            }
        }

        LaunchedEffect(student.id, allOffers) {
            repository.autoApplyEligibleOffersForStudent(student.id)
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = student.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "${student.standard} • ID: ${student.id}",
                                fontSize = 11.sp,
                                color = GoldYellowLight
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                repository.clearPortalSession()
                                currentStudent = null
                            },
                            modifier = Modifier.testTag("student_logout_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showPasswordChangeDialog = true },
                            modifier = Modifier.testTag("student_change_pwd_btn")
                        ) {
                            Icon(Icons.Default.LockReset, contentDescription = "Change Password", tint = GoldYellow)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(0, if (isGu) "પ્રોફાઇલ" else "Profile", Icons.Default.Person),
                        Triple(1, if (isGu) "હાજરી" else "Attend.", Icons.Default.EventAvailable),
                        Triple(2, if (isGu) "હોમવર્ક" else "Homework", Icons.Default.Assignment),
                        Triple(3, if (isGu) "પરિણામ" else "Results", Icons.Default.EmojiEvents),
                        Triple(4, if (isGu) "ફી & પાવતી" else "Fees", Icons.Default.ReceiptLong)
                    )
                    tabs.forEach { (index, label, icon) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PurplePrimary,
                                selectedTextColor = PurplePrimary,
                                indicatorColor = PurpleContainer
                            ),
                            modifier = Modifier.testTag("student_tab_$index")
                        )
                    }
                }
            },
            modifier = modifier
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BackgroundLight)
            ) {
                when (selectedTab) {
                    0 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(60.dp)
                                                    .clip(CircleShape)
                                                    .background(PurplePrimary),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = student.name.take(2).uppercase(),
                                                    color = GoldYellow,
                                                    fontWeight = FontWeight.Black,
                                                    fontSize = 20.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(14.dp))
                                            Column {
                                                Text(text = student.name, fontWeight = FontWeight.Black, fontSize = 17.sp, color = PurplePrimary)
                                                Text(text = "રોલ નંબર: ${student.rollNo} • ${student.standard}", fontSize = 13.sp, color = TextDark)
                                                Text(text = student.medium, fontSize = 11.sp, color = TextMuted)
                                            }
                                        }

                                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderSubtle)

                                        ProfileDetailRow(label = "વિદ્યાર્થી ID:", value = student.id)
                                        ProfileDetailRow(label = "વાલીનું નામ:", value = student.parentName)
                                        ProfileDetailRow(label = "સંપર્ક નંબર:", value = student.mobileNumber)
                                        ProfileDetailRow(label = "સરનામું:", value = student.address)
                                        ProfileDetailRow(label = "શાળા:", value = student.school)
                                        ProfileDetailRow(label = "જોડાયા તારીખ:", value = student.joinDate)
                                    }
                                }
                            }

                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = PurpleContainer)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = "ફી સ્ટેટસ સમરી", fontWeight = FontWeight.Bold, color = PurplePrimary)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (student.remainingFees == 0) StatusSuccessContainer else StatusWarningContainer
                                            ) {
                                                Text(
                                                    text = if (student.remainingFees == 0) "ફૂલ પેઇડ ✓" else "બાકી ફી: ₹${student.remainingFees}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = if (student.remainingFees == 0) StatusSuccess else StatusWarning,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceAround
                                        ) {
                                            FeeStatPill(title = "કુલ ફી", amount = "₹${student.effectiveTotalFees}", color = PurplePrimary)
                                            FeeStatPill(title = "ભરેલ ફી", amount = "₹${student.paidFees}", color = StatusSuccess)
                                            FeeStatPill(title = "બાકી ફી", amount = "₹${student.remainingFees}", color = StatusWarning)
                                        }
                                    }
                                }
                            }

                            item {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("spin_and_win_card"),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = GoldYellowContainer)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(CircleShape)
                                                    .background(GoldYellow),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Casino, contentDescription = null, tint = TextDark)
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = "SPIN & WIN (લકી ડ્રો ઑફર)",
                                                    fontWeight = FontWeight.Black,
                                                    fontSize = 13.sp,
                                                    color = TextDark
                                                )
                                                Text(
                                                    text = if (student.spinPlayed) {
                                                        "તમે લકી ડ્રો રમી લીધો છે ✓ (લાભ: ₹${student.spinDiscount})"
                                                    } else {
                                                        "ફીમાં ₹49 સુધીનું ઇન્સ્ટન્ટ ડિસ્કાઉન્ટ જીતો!"
                                                    },
                                                    fontSize = 11.sp,
                                                    color = TextDark.copy(alpha = 0.85f)
                                                )
                                            }
                                        }

                                        if (!student.spinPlayed) {
                                            Button(
                                                onClick = { showSpinDialog = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.testTag("open_spin_wheel_btn")
                                            ) {
                                                Text("રમો", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldYellow)
                                            }
                                        }
                                    }
                                }
                            }

                            if (eligibleOffers.isNotEmpty()) {
                                item {
                                    Text(
                                        text = if (isGu) "તમારા માટે ખાસ લાઇવ ઑફર્સ (Special Offers)" else "Active Offers for You",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = PurplePrimary
                                    )
                                }
                                items(eligibleOffers, key = { "student_offer_${it.id}" }) { offer ->
                                    val calcDiscount = offer.calculateDiscountForFee(student.totalFees)
                                    OfferBannerCard(
                                        offer = offer,
                                        isGu = isGu,
                                        isAppliedToStudent = student.appliedOfferId == offer.id,
                                        calculatedStudentDiscount = calcDiscount
                                    )
                                }
                            }

                            item {
                                Text(
                                    text = if (isGu) "જાહેરાતો અને સૂચનાઓ (Notices)" else "Notices & Announcements",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (studentNotices.isEmpty()) {
                                item {
                                    EmptyPortalCard(
                                        message = if (isGu) "હાલમાં કોઈ નવી સૂચના નથી." else "No active notices at the moment."
                                    )
                                }
                            } else {
                                items(studentNotices, key = { it.id }) { ann ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (ann.isUrgent) GoldYellowContainer else Color.White
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = ann.title,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = PurplePrimary,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                if (ann.isUrgent) {
                                                    Text(
                                                        text = "URGENT",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = StatusError
                                                    )
                                                }
                                            }
                                            if (ann.content.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(text = ann.content, fontSize = 12.sp, color = TextDark)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "${ann.date} • ${ann.authorName}",
                                                fontSize = 10.sp,
                                                color = TextMuted
                                            )
                                        }
                                    }
                                }
                            }

                            item {
                                Text(
                                    text = if (isGu) "સાપ્તાહિક સમયપત્રક (Weekly Timetable)" else "Weekly Timetable",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (timetable.isEmpty()) {
                                item {
                                    EmptyPortalCard(
                                        message = if (isGu) "${student.standard} માટે હજુ સમયપત્રક મૂકાયેલ નથી." else "No timetable uploaded yet for ${student.standard}."
                                    )
                                }
                            } else {
                                items(timetable, key = { it.id }) { slot ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = "${slot.dayOfWeek} • ${slot.subject}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextDark)
                                                Text(text = "શિક્ષક: ${slot.teacherName} • ${slot.room}", fontSize = 11.sp, color = TextMuted)
                                            }
                                            Text(text = slot.timeSlot, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = PurplePrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        val presentCount = studentAttendance.count { it.status == AttendanceStatus.PRESENT }
                                        val totalCount = studentAttendance.size
                                        val percentage = if (totalCount > 0) (presentCount.toFloat() / totalCount.toFloat()) * 100f else 0f

                                        Text(text = "માસિક હાજરી ટકાવારી", fontSize = 13.sp, color = TextMuted)
                                        Text(
                                            text = if (totalCount > 0) "%.1f%%".format(percentage) else "--",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 32.sp,
                                            color = if (totalCount == 0) PurplePrimary else if (percentage >= 80) StatusSuccess else StatusWarning
                                        )
                                        Text(
                                            text = "હાજર: $presentCount દિવસ • કુલ: $totalCount દિવસ",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextDark
                                        )
                                    }
                                }
                            }

                            item {
                                Text(
                                    text = "દૈનિક હાજરી વિગત",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (studentAttendance.isEmpty()) {
                                item {
                                    EmptyPortalCard(
                                        message = if (isGu) "હજુ સુધી કોઈ હાજરી નોંધાયેલ નથી." else "No attendance records found yet."
                                    )
                                }
                            } else {
                                items(studentAttendance, key = { it.id }) { record ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = record.date, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = when (record.status) {
                                                    AttendanceStatus.PRESENT -> StatusSuccessContainer
                                                    AttendanceStatus.ABSENT -> StatusErrorContainer
                                                    AttendanceStatus.LEAVE -> StatusWarningContainer
                                                }
                                            ) {
                                                Text(
                                                    text = when (record.status) {
                                                        AttendanceStatus.PRESENT -> "હાજર (Present)"
                                                        AttendanceStatus.ABSENT -> "ગેરહાજર (Absent)"
                                                        AttendanceStatus.LEAVE -> "રજા (Leave)"
                                                    },
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = when (record.status) {
                                                        AttendanceStatus.PRESENT -> StatusSuccess
                                                        AttendanceStatus.ABSENT -> StatusError
                                                        AttendanceStatus.LEAVE -> StatusWarning
                                                    },
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Text(
                                    text = "ચાલુ ગૃહકાર્ય (Active Homework)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (studentHomework.isEmpty()) {
                                item {
                                    EmptyPortalCard(
                                        message = if (isGu) "${student.standard} માટે હજુ સુધી કોઈ હોમવર્ક અપાયું નથી." else "No homework assigned yet for ${student.standard}."
                                    )
                                }
                            } else {
                                items(studentHomework, key = { it.id }) { hw ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = PurpleContainer
                                                ) {
                                                    Text(
                                                        text = hw.subject,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = PurplePrimary,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "જમા તારીખ: ${hw.dueDate}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = StatusWarning
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            Text(text = hw.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextDark)
                                            if (hw.description.isNotBlank()) {
                                                Text(text = hw.description, fontSize = 12.sp, color = TextMuted)
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            Text(
                                                text = "શિક્ષક: ${hw.teacherName} • સોંપેલ: ${hw.assignedDate}",
                                                fontSize = 10.sp,
                                                color = PurpleMedium
                                            )

                                            val submissions = studentSubmissions.filter { it.homeworkId == hw.id }
                                            if (submissions.isNotEmpty()) {
                                                val latest = submissions.first()
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (latest.status == "Checked") StatusSuccessContainer else BackgroundLight,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(top = 8.dp)
                                                ) {
                                                    Column(modifier = Modifier.padding(8.dp)) {
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(16.dp))
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = "ગૃહકાર્ય જમા થયેલ છે (${latest.submittedAt})",
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 11.sp,
                                                                color = if (latest.status == "Checked") StatusSuccess else PurplePrimary
                                                            )
                                                        }
                                                        if (latest.teacherFeedback.isNotBlank()) {
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = "શિક્ષક પ્રતિભાવ: ${latest.teacherFeedback}",
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = StatusSuccess
                                                            )
                                                        }
                                                    }
                                                }
                                            } else {
                                                OutlinedButton(
                                                    onClick = { selectedHomeworkForSubmit = hw },
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(top = 8.dp)
                                                        .testTag("submit_hw_btn_${hw.id}")
                                                ) {
                                                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("ગૃહકાર્ય ઓનલાઇન જમા કરો (Submit)", fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Text(
                                    text = "પરીક્ષા પરિણામો અને માર્કશીટ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (studentResults.isEmpty()) {
                                item {
                                    EmptyPortalCard(
                                        message = if (isGu) "હજુ સુધી કોઈ પરીક્ષા પરિણામ અપલોડ થયેલ નથી." else "No exam results published yet."
                                    )
                                }
                            } else {
                                items(studentResults, key = { it.id }) { res ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = res.examName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                                                    Text(text = "તારીખ: ${res.examDate}", fontSize = 11.sp, color = TextMuted)
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = GoldYellowContainer
                                                ) {
                                                    Text(
                                                        text = "%.1f%% (${res.grade})".format(res.percentage),
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 14.sp,
                                                        color = GoldYellowDeep,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }

                                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = BorderSubtle)

                                            res.scores.forEach { score ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(vertical = 3.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(text = score.subject, fontSize = 12.sp, color = TextDark)
                                                    Text(
                                                        text = "${score.marksObtained} / ${score.maxMarks}",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (score.marksObtained >= score.maxMarks * 0.8) StatusSuccess else TextDark
                                                    )
                                                }
                                            }

                                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = BorderSubtle)

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(text = "કુલ ગુણ:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(
                                                    text = "${res.totalObtained} / ${res.totalMax}",
                                                    fontWeight = FontWeight.Black,
                                                    fontSize = 14.sp,
                                                    color = PurplePrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    4 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(text = "ફી એકાઉન્ટ વિગત", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PurplePrimary)
                                        Spacer(modifier = Modifier.height(10.dp))
                                        FeeDetailRow("કુલ વાર્ષિક ફી:", "₹${student.totalFees}")
                                        if (student.spinDiscount > 0) {
                                            FeeDetailRow("લકી ડ્રો છૂટ (Spin & Win):", "-₹${student.spinDiscount}", isPaid = true)
                                        }
                                        if (student.specialDiscount > 0) {
                                            FeeDetailRow("સ્પેશિયલ સ્કોલરશીપ / માફી:", "-₹${student.specialDiscount}", isPaid = true)
                                        }
                                        if (student.offerDiscount > 0) {
                                            val titleLabel = student.appliedOfferTitle.ifBlank { if (isGu) "ઑફર ડિસ્કાઉન્ટ" else "Offer Discount" }
                                            FeeDetailRow("$titleLabel:", "-₹${student.offerDiscount}", isPaid = true)
                                        }
                                        FeeDetailRow("જમા થયેલ રકમ:", "₹${student.paidFees}", isPaid = true)
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                                        FeeDetailRow(
                                            "બાકી રહેતી ફી:",
                                            "₹${student.remainingFees}",
                                            isDue = student.remainingFees > 0
                                        )

                                        if (student.remainingFees > 0) {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Button(
                                                onClick = { showPaymentDialog = true },
                                                enabled = !isBusy,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("pay_online_btn"),
                                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Icon(Icons.Default.Payment, contentDescription = null, tint = GoldYellow)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "ઓનલાઇન ફી ભરો (UPI / QR)",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Text(
                                    text = "ફી પાવતીઓ (Fee Receipts & Status)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (studentReceipts.isEmpty()) {
                                item {
                                    EmptyPortalCard(
                                        message = if (isGu) "હજુ સુધી કોઈ ફી પાવતી બનેલ નથી." else "No fee receipts generated yet."
                                    )
                                }
                            } else {
                                items(studentReceipts, key = { it.id }) { receipt ->
                                    val statusColor = when (receipt.paymentStatus) {
                                        "SUCCESS" -> StatusSuccess
                                        "PENDING_VERIFICATION" -> StatusWarning
                                        else -> StatusError
                                    }
                                    val statusLabel = when (receipt.paymentStatus) {
                                        "SUCCESS" -> "વેરિફાઇડ ✓"
                                        "PENDING_VERIFICATION" -> "ચકાસણી બાકી"
                                        "FAILED" -> "નિષ્ફળ"
                                        "CANCELLED" -> "રદ"
                                        "REJECTED" -> "અસ્વીકૃત"
                                        else -> receipt.paymentStatus
                                    }
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("receipt_item_${receipt.receiptNo}"),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = receipt.receiptNo, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                                Text(text = "તારીખ: ${receipt.paymentDate} • ${receipt.paymentMode}", fontSize = 11.sp, color = TextMuted)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(text = "રકમ: ₹${receipt.amountPaid}", fontWeight = FontWeight.Black, fontSize = 14.sp, color = statusColor)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(text = statusLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = statusColor)
                                                }
                                            }

                                            Button(
                                                onClick = { selectedReceiptForView = receipt },
                                                colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("પાવતી જુઓ", color = PurplePrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (showPasswordChangeDialog) {
                    PasswordChangeDialog(
                        isBusy = isBusy,
                        onDismiss = { if (!isBusy) showPasswordChangeDialog = false },
                        onSubmit = { oldPass, newPass ->
                            coroutineScope.launch {
                                isBusy = true
                                val res = repository.changeStudentPassword(student.id, oldPass, newPass)
                                isBusy = false
                                res.onSuccess {
                                    Toast.makeText(context, "પાસવર્ડ સફળતાપૂર્વક બદલાઈ ગયો!", Toast.LENGTH_SHORT).show()
                                    showPasswordChangeDialog = false
                                }.onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "જૂનો પાસવર્ડ ખોટો છે!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                }

                if (selectedReceiptForView != null) {
                    Dialog(onDismissRequest = { selectedReceiptForView = null }) {
                        OfficialReceiptCard(
                            receipt = selectedReceiptForView!!,
                            onDismiss = { selectedReceiptForView = null }
                        )
                    }
                }

                if (showSpinDialog) {
                    SpinAndWinDialog(
                        student = student,
                        onDismiss = { showSpinDialog = false },
                        onSpinWon = { discount, prize ->
                            coroutineScope.launch {
                                val res = repository.recordSpinWin(student.id, discount, prize)
                                showSpinDialog = false
                                res.onSuccess {
                                    Toast.makeText(context, "અભિનંદન! $prize ફીમાં બાદ કરવામાં આવેલ છે.", Toast.LENGTH_LONG).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Spin record failed", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    )
                }

                if (showPaymentDialog) {
                    OnlinePaymentGatewayDialog(
                        amount = student.remainingFees,
                        studentName = student.name,
                        studentId = student.id,
                        standard = student.standard,
                        upiId = settings.upiId,
                        payeeName = settings.upiPayeeName,
                        onDismiss = { showPaymentDialog = false },
                        onPaymentResult = { txnId, mode, amt, status ->
                            coroutineScope.launch {
                                isBusy = true
                                val res = repository.recordOnlinePayment(student.id, amt, mode, txnId, status)
                                isBusy = false
                                showPaymentDialog = false
                                res.onSuccess { rec ->
                                    when (status) {
                                        "SUCCESS" -> Toast.makeText(context, "પેમેન્ટ સફળ! પાવતી નંબર: ${rec.receiptNo}", Toast.LENGTH_LONG).show()
                                        "PENDING_VERIFICATION" -> Toast.makeText(context, "UTR સબમિટ થયું (${rec.receiptNo}). એડમિન વેરિફિકેશન બાકી છે.", Toast.LENGTH_LONG).show()
                                        "FAILED" -> Toast.makeText(context, "પેમેન્ટ નિષ્ફળ થયું (${rec.receiptNo}).", Toast.LENGTH_LONG).show()
                                        else -> Toast.makeText(context, "પેમેન્ટ રદ કરવામાં આવ્યું (${rec.receiptNo}).", Toast.LENGTH_SHORT).show()
                                    }
                                }.onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Payment recording failed", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    )
                }

                if (selectedHomeworkForSubmit != null) {
                    AlertDialog(
                        onDismissRequest = { if (!isBusy) selectedHomeworkForSubmit = null },
                        title = {
                            Text(
                                text = "ગૃહકાર્ય જમા કરો: ${selectedHomeworkForSubmit!!.subject}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = PurplePrimary
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = selectedHomeworkForSubmit!!.title,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    color = TextDark
                                )
                                Text(
                                    text = "તમારું લખાણ અથવા દાખલાનું સોલ્યુશન અહીં લખો:",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                                OutlinedTextField(
                                    value = homeworkSubmissionText,
                                    onValueChange = { homeworkSubmissionText = it },
                                    placeholder = { Text("દાખલા નં ૧ થી ૬ ના જવાબો અથવા નોંધ...") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(110.dp)
                                        .testTag("homework_submission_text_input")
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    if (homeworkSubmissionText.trim().length < 2) {
                                        Toast.makeText(context, "કૃપા કરીને યોગ્ય જવાબ અથવા નોંધ લખો", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    val targetHw = selectedHomeworkForSubmit!!
                                    coroutineScope.launch {
                                        isBusy = true
                                        val res = repository.submitHomework(
                                            HomeworkSubmission(
                                                homeworkId = targetHw.id,
                                                studentId = student.id,
                                                teacherUid = targetHw.teacherUid,
                                                studentName = student.name,
                                                subject = targetHw.subject,
                                                submissionText = homeworkSubmissionText.trim(),
                                                submittedAt = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
                                            )
                                        )
                                        isBusy = false
                                        res.onSuccess {
                                            homeworkSubmissionText = ""
                                            selectedHomeworkForSubmit = null
                                            Toast.makeText(context, "ગૃહકાર્ય સફળતાપૂર્વક જમા થયું!", Toast.LENGTH_SHORT).show()
                                        }.onFailure { err ->
                                            Toast.makeText(context, err.localizedMessage ?: "Submission failed", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = !isBusy,
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                modifier = Modifier.testTag("submit_homework_dialog_btn")
                            ) {
                                Text("જમા કરો")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { selectedHomeworkForSubmit = null }, enabled = !isBusy) {
                                Text("રદ")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyPortalCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Text(
            text = message,
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextMuted)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
    }
}

@Composable
private fun FeeStatPill(title: String, amount: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, fontSize = 11.sp, color = TextMuted)
        Text(text = amount, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
    }
}

@Composable
private fun FeeDetailRow(label: String, value: String, isPaid: Boolean = false, isDue: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp, color = TextDark)
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = when {
                isPaid -> StatusSuccess
                isDue -> StatusWarning
                else -> TextDark
            }
        )
    }
}

@Composable
private fun PasswordChangeDialog(
    isBusy: Boolean = false,
    onDismiss: () -> Unit,
    onSubmit: (oldPass: String, newPass: String) -> Unit
) {
    var oldPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("પાસવર્ડ બદલો (Change Password)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = oldPassword,
                    onValueChange = { oldPassword = it },
                    label = { Text("જૂનો પાસવર્ડ (Current Password)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("નવો પાસવર્ડ (New Password)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("નવો પાસવર્ડ ફરી લખો (Confirm)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword != confirmPassword) {
                        Toast.makeText(context, "નવા પાસવર્ડ મેળ ખાતા નથી!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (newPassword.trim().length < 4) {
                        Toast.makeText(context, "પાસવર્ડ ઓછામાં ઓછો ૪ અક્ષરનો હોવો જોઈએ", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onSubmit(oldPassword, newPassword)
                },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
            ) {
                Text("બદલો")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isBusy) { Text("રદ કરો") }
        }
    )
}
