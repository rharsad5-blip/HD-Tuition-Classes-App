package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.repository.HDTuitionRepository
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: HDTuitionRepository,
    onNavigateToAdmission: () -> Unit,
    onNavigateToBooking: () -> Unit,
    onNavigateToStudentLogin: () -> Unit,
    onNavigateToTeacherLogin: () -> Unit,
    onNavigateToAdminLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentLang by repository.currentLanguage.collectAsState()
    val offers by repository.offers.collectAsState()
    val faculty by repository.publicFaculty.collectAsState()
    val toppers by repository.toppers.collectAsState()
    val announcements by repository.announcements.collectAsState()
    val settings by repository.settings.collectAsState()
    val courses = repository.courses

    val isGu = currentLang == AppLanguage.GUJARATI
    val phoneNumber = settings.contactPhone.ifBlank { "+91 85112 73911" }
    val waDigits = settings.whatsappNumber.filter { it.isDigit() }.let {
        if (it.length == 10) "91$it" else it.ifBlank { "918511273911" }
    }
    val founderName = settings.founderName.ifBlank { "Harshadsinh Rathod" }
    val businessName = settings.businessName.ifBlank { "HD TUITION CLASSES" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HDLogo(size = 36.dp)
                        Column {
                            Text(
                                text = businessName,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = SurfaceWhite
                            )
                            Text(
                                text = "$founderName | કવિથા",
                                fontSize = 10.sp,
                                color = GoldYellowLight
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clickable { repository.toggleLanguage() }
                            .testTag("lang_toggle_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Language,
                                contentDescription = "Language",
                                tint = GoldYellow,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isGu) "ENG" else "ગુજ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onNavigateToTeacherLogin,
                        modifier = Modifier.testTag("nav_teacher_login_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CoPresent,
                            contentDescription = "Teacher Portal",
                            tint = GoldYellowLight
                        )
                    }

                    IconButton(
                        onClick = onNavigateToStudentLogin,
                        modifier = Modifier.testTag("nav_student_login_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Student Portal",
                            tint = GoldYellow
                        )
                    }

                    IconButton(
                        onClick = onNavigateToAdminLogin,
                        modifier = Modifier.testTag("nav_admin_login_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Login",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PurplePrimary
                )
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FloatingActionButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                        context.startActivity(intent)
                    },
                    containerColor = GoldYellow,
                    contentColor = TextDark,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("fab_call_btn")
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Call")
                }

                ExtendedFloatingActionButton(
                    onClick = {
                        val url = "https://wa.me/$waDigits?text=${Uri.encode("નમસ્તે $founderName સર, મારે $businessName વિશે વધુ માહિતી મેળવવી છે.")}"
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "WhatsApp: $phoneNumber", Toast.LENGTH_SHORT).show()
                        }
                    },
                    containerColor = Color(0xFF25D366),
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_whatsapp_btn"),
                    icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                    text = { Text("WhatsApp", fontWeight = FontWeight.Bold) }
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // 1. Live Ticker
            item {
                Surface(
                    color = GoldYellow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Campaign,
                            contentDescription = null,
                            tint = PurplePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isGu) settings.tickerText else "Admissions Open! Book your seat in advance at ₹${settings.advanceBookingAmount}.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PurplePrimary,
                            maxLines = 1
                        )
                    }
                }
            }

            // 2. Hero Section
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(PurplePrimary, PurpleVariant, PurpleMedium)
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        HDBadgeLogo(size = 110.dp)

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isGu) "★ લૉગિન પોર્ટલ પસંદ કરો ★" else "★ SELECT LOGIN PORTAL ★",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = GoldYellow,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("three_portal_boxes_row"),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PortalBoxCard(
                                modifier = Modifier.weight(1f),
                                title = "ADMIN",
                                subtitle = if (isGu) "સંચાલક" else "Admin",
                                desc = if (isGu) "કંટ્રોલ પેનલ" else "Dashboard",
                                icon = Icons.Default.AdminPanelSettings,
                                bgBrush = Brush.verticalGradient(listOf(Color(0xFF2E0854), PurplePrimary)),
                                accentColor = GoldYellow,
                                testTag = "box_portal_admin",
                                onClick = onNavigateToAdminLogin
                            )

                            PortalBoxCard(
                                modifier = Modifier.weight(1f),
                                title = "TEACHER",
                                subtitle = if (isGu) "શિક્ષક" else "Faculty",
                                desc = if (isGu) "હાજરી & હોમવર્ક" else "Attendance",
                                icon = Icons.Default.CoPresent,
                                bgBrush = Brush.verticalGradient(listOf(Color(0xFF303F9F), Color(0xFF5C6BC0))),
                                accentColor = Color(0xFFFFD54F),
                                testTag = "box_portal_teacher",
                                onClick = onNavigateToTeacherLogin
                            )

                            PortalBoxCard(
                                modifier = Modifier.weight(1f),
                                title = "STUDENT",
                                subtitle = if (isGu) "વિદ્યાર્થી" else "Student",
                                desc = if (isGu) "રિઝલ્ટ & ફી" else "Results & Fee",
                                icon = Icons.Default.School,
                                bgBrush = Brush.verticalGradient(listOf(Color(0xFFFF8F00), Color(0xFFFFA000))),
                                accentColor = Color.White,
                                textColor = TextDark,
                                testTag = "box_portal_student",
                                onClick = onNavigateToStudentLogin
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onNavigateToAdmission,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_new_admission"),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(vertical = 12.dp)
                            ) {
                                Icon(Icons.Default.AppRegistration, contentDescription = null, tint = TextDark)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isGu) "૧. નવું એડમિશન ફોર્મ ભરો" else "1. New Admission Form",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = TextDark
                                )
                            }

                            Button(
                                onClick = onNavigateToBooking,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_advance_booking"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(vertical = 12.dp)
                            ) {
                                Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = PurplePrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isGu) "૨. એડવાન્સ સીટ બુકિંગ ₹${settings.advanceBookingAmount}" else "2. Advance Seat Booking ₹${settings.advanceBookingAmount}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        Toast.makeText(context, if (isGu) "નીચે અમારા તમામ કોર્સ ઉપલબ્ધ છે" else "View courses below", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_view_courses"),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(GoldYellow, Color.White))),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isGu) "૩. અમારા કોર્સ" else "3. Courses",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }

                                Button(
                                    onClick = {
                                        val url = "https://wa.me/$waDigits?text=${Uri.encode("$businessName Inquiry")}"
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                        try {
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "WhatsApp: $phoneNumber", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_whatsapp_contact"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isGu) "૪. વોટ્સએપ સંપર્ક" else "4. WhatsApp",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Admission Open Banner
            if (settings.admissionOpen) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .testTag("admission_open_banner"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = GoldYellowContainer),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GoldYellow, PurpleMedium)))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = PurplePrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isGu) "નવા શૈક્ષણિક સત્ર માટે પ્રવેશ શરૂ છે!" else "ADMISSIONS OPEN FOR NEW SESSION!",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = PurplePrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isGu) "ધોરણ ૧ થી ૧૨ | તમામ વિષયો | ગુજરાતી માધ્યમ" else "Standard 1 to 12 | All Subjects | Gujarati Medium",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextDark
                            )
                            Text(
                                text = if (isGu) "• મર્યાદિત ૨૫ બેઠકો • વ્યક્તિગત ધ્યાન • નિયમિત ટેસ્ટ સિરીઝ" else "• Limited 25 Seats • Personal Attention • Regular Test Series",
                                fontSize = 12.sp,
                                color = TextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // 3b. Live Announcements from Admin/Teachers
            if (announcements.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = if (isGu) "તાજી જાહેરાતો (Live Notices)" else "Latest Announcements",
                        icon = Icons.Default.Notifications
                    )
                }
                items(announcements.take(3)) { ann ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (ann.isUrgent) GoldYellowContainer else Color.White
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ann.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                Text(ann.date, fontSize = 10.sp, color = TextMuted)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(ann.content, fontSize = 12.sp, color = TextDark)
                        }
                    }
                }
            }

            // 4. Special Offers Section (Live from Firestore)
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionHeader(
                    title = if (isGu) "વિશેષ ઑફર્સ અને સ્કોલરશીપ" else "Special Offers & Discounts",
                    icon = Icons.Default.LocalOffer
                )
            }

            val activeVisibleOffers = offers.filter { it.isWithinDateWindow() && it.hasRemainingClaims() }
            if (activeVisibleOffers.isEmpty()) {
                item {
                    EmptyLiveInfoBanner(
                        text = if (isGu) "હાલમાં કોઈ નવી ઑફર પ્રકાશિત કરેલ નથી. વાર્ષિક ફી પર 5% ઓટોમેટિક ડિસ્કાઉન્ટ ઉપલબ્ધ છે."
                        else "No special seasonal offers published yet. Automatic 5% discount applies on full annual fees."
                    )
                }
            } else {
                items(activeVisibleOffers, key = { "home_offer_${it.id}" }) { offer ->
                    OfferBannerCard(
                        offer = offer,
                        isGu = isGu,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }

            // 5. Fee Structure Section (Official Institute Fees)
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeader(
                    title = if (isGu) "ફી સ્ટ્રક્ચર (પારદર્શક ધોરણવાર ફી)" else "Fee Structure",
                    icon = Icons.Default.CurrencyRupee
                )
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("fee_structure_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        FeeRow(std = "ધોરણ ૧ થી ૩ (Std 1 to 3)", monthly = "₹350 / માસ", annual = "₹3,599 / વર્ષ")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                        FeeRow(std = "ધોરણ ૪ થી ૫ (Std 4 to 5)", monthly = "₹550 / માસ", annual = "₹5,999 / વર્ષ")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                        FeeRow(std = "ધોરણ ૬ થી ૮ (Std 6 to 8)", monthly = "₹850 / માસ", annual = "₹9,599 / વર્ષ")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                        FeeRow(std = "ધોરણ ૯ (Standard 9)", monthly = "₹1,000 / માસ", annual = "₹10,799 / વર્ષ")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                        FeeRow(std = "ધોરણ ૧૦ બોર્ડ (Std 10 GSEB)", monthly = "₹1,150 / માસ", annual = "₹11,999 / વર્ષ", highlight = true)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                        FeeRow(std = "ધોરણ ૧૧ (Standard 11)", monthly = "₹1,350 / માસ", annual = "₹14,399 / વર્ષ")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = BorderSubtle)
                        FeeRow(std = "ધોરણ ૧૨ બોર્ડ (Std 12 GSEB)", monthly = "₹1,500 / માસ", annual = "₹15,999 / વર્ષ", highlight = true)

                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GoldYellowContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isGu) "★ એકસાથે વાર્ષિક ફી ભરવા પર 5% ઓટોમેટિક ડિસ્કાઉન્ટ! જૂના વિદ્યાર્થીઓ માટે ખાસ ઓફર & હપ્તાની સગવડ." else "★ Automatic 5% discount on full annual fee payment! Special offers & installment options available.",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldYellowDeep,
                                modifier = Modifier.padding(10.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // 6. About Tuition Classes
            item {
                SectionHeader(
                    title = if (isGu) "HD ટ્યુશન ક્લાસીસ વિશે" else "About HD Tuition Classes",
                    icon = Icons.Default.Info
                )
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("about_us_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HDLogo(size = 46.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isGu) "સંચાલક: $founderName" else "Founder: $founderName",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PurplePrimary
                                )
                                Text(
                                    text = "M.Com, B.Ed (12+ Years Experience)",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isGu) {
                                "HD ટ્યુશન ક્લાસીસ એ કવિથા અને બદરખા વિસ્તારમાં ગુજરાતી માધ્યમના વિદ્યાર્થીઓ માટે ગુણવત્તાયુક્ત શિક્ષણનું અગ્રણી કેન્દ્ર છે. અમારો મુખ્ય ઉદ્દેશ્ય માત્ર ગોખણપટ્ટી કરાવવાનો નહીં, પરંતુ દરેક વિદ્યાર્થીમાં વિષય પ્રત્યે ઊંડી સમજ અને આત્મવિશ્વાસ નિર્માણ કરવાનો છે."
                            } else {
                                "HD Tuition Classes is a leading academic coaching center in Kavitha and Badarkha dedicated to Gujarati Medium students. Founded by $founderName, we focus on conceptual clarity, individual mentoring, regular weekly testing, and student success."
                            },
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = TextDark
                        )
                    }
                }
            }

            // 7. Why Choose Us?
            item {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeader(
                    title = if (isGu) "શા માટે HD ટ્યુશન ક્લાસીસ પસંદ કરશો?" else "Why Choose HD Tuition?",
                    icon = Icons.Default.ThumbUp
                )
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WhyChooseItem(icon = Icons.Default.Groups, title = if (isGu) "મર્યાદિત સંખ્યાની બેચ" else "Small Batch Sizes", desc = if (isGu) "દરેક બાળક પર વ્યક્તિગત ધ્યાન અને દેખરેખ." else "Personalized attention for every child.")
                    WhyChooseItem(icon = Icons.Default.AssignmentTurnedIn, title = if (isGu) "દર રવિવારે સાપ્તાહિક ટેસ્ટ" else "Weekly Sunday Tests", desc = if (isGu) "નિયમિત પરીક્ષા અને વાલીઓને પરિણામનું રિપોર્ટિંગ." else "Regular tests with direct reporting to parents.")
                    WhyChooseItem(icon = Icons.Default.Checklist, title = if (isGu) "દૈનિક હાજરી અને હોમવર્ક ટ્રેકિંગ" else "Daily Attendance & Homework", desc = if (isGu) "મોબાઇલ પોર્ટલ દ્વારા વાલીઓ ઘરબેઠા હાજરી જાણી શકે છે." else "Parents can monitor daily attendance via mobile portal.")
                    WhyChooseItem(icon = Icons.Default.Psychology, title = if (isGu) "સ્પેશિયલ ડાઉટ સોલ્વિંગ સેશન" else "Special Doubt Solving", desc = if (isGu) "નબળા વિદ્યાર્થીઓ માટે અઠવાડિયામાં વધારાનો સમય." else "Extra remedial classes for conceptual doubts.")
                }
            }

            // 8. Our Courses
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SectionHeader(
                    title = if (isGu) "અમારા ઉપલબ્ધ કોર્સ (Std 1 to 12)" else "Our Courses",
                    icon = Icons.Default.AutoStories
                )
            }

            items(courses) { course ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("course_card_${course.standardRange}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = course.standardRange,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = PurplePrimary
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = GoldYellowContainer
                            ) {
                                Text(
                                    text = "₹${course.feeMonthly}/માસ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = GoldYellowDeep,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = if (isGu) course.titleGujarati else course.titleEnglish,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = TextDark
                        )

                        Text(
                            text = if (isGu) course.descriptionGujarati else course.descriptionEnglish,
                            fontSize = 12.sp,
                            color = TextMuted
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "વિષયો: ${course.subjects.joinToString(" • ")}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PurpleMedium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OutlinedButton(
                                onClick = onNavigateToBooking,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("બુકિંગ ₹${settings.advanceBookingAmount}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = onNavigateToAdmission,
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("એડમિશન ફોર્મ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 9. Results & Toppers Gallery (Live from Firestore public_toppers)
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SectionHeader(
                    title = if (isGu) "અમારા તેજસ્વી તારલાઓ (ટોપર્સ પરિણામ)" else "Our Toppers & Results",
                    icon = Icons.Default.EmojiEvents
                )
            }

            if (toppers.isEmpty()) {
                item {
                    EmptyLiveInfoBanner(
                        text = if (isGu) "બોર્ડ અને વાર્ષિક ટોપર્સની વિગતો એડમિન દ્વારા અપડેટ કરવામાં આવશે."
                        else "Official topper results will appear here once published by Admin."
                    )
                }
            } else {
                item {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(toppers) { topper ->
                            Card(
                                modifier = Modifier
                                    .width(220.dp)
                                    .testTag("topper_card_${topper.studentName}"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(CircleShape)
                                            .background(PurpleContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.School,
                                            contentDescription = null,
                                            tint = PurplePrimary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = topper.studentName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextDark,
                                        textAlign = TextAlign.Center
                                    )

                                    Text(
                                        text = "${topper.standard}${if (topper.year.isNotBlank()) " (${topper.year})" else ""}",
                                        fontSize = 12.sp,
                                        color = TextMuted
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = GoldYellowContainer
                                    ) {
                                        Text(
                                            text = topper.percentage,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 18.sp,
                                            color = GoldYellowDeep,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = topper.remark,
                                        fontSize = 10.sp,
                                        color = StatusSuccess,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 10. Faculty Information (Live from Firestore public_faculty)
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SectionHeader(
                    title = if (isGu) "અમારા અનુભવી શિક્ષકો (શિક્ષક માહિતી)" else "Faculty & Teachers",
                    icon = Icons.Default.Badge
                )
            }

            if (faculty.isEmpty()) {
                item {
                    EmptyLiveInfoBanner(
                        text = if (isGu) "મંજૂર થયેલા શિક્ષકોની માહિતી અહીં પ્રદર્શિત થશે."
                        else "Approved faculty members will appear here once approved by Admin."
                    )
                }
            } else {
                items(faculty) { teacher ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .testTag("teacher_card_${teacher.name}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(PurplePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = teacher.name.take(2),
                                    color = GoldYellow,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = teacher.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextDark
                                )
                                Text(
                                    text = teacher.role,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PurpleMedium
                                )
                                Text(
                                    text = "${teacher.qualification} • ${teacher.experience}",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = "વિષયો: ${teacher.subjects}",
                                    fontSize = 10.sp,
                                    color = TextDark
                                )
                            }
                        }
                    }
                }
            }

            // 11. Contact Information Card
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SectionHeader(
                    title = if (isGu) "સંપર્ક માહિતી અને સરનામું" else "Contact Information",
                    icon = Icons.Default.LocationOn
                )
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("contact_info_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        ContactRow(
                            icon = Icons.Default.Person,
                            title = if (isGu) "સંચાલક" else "Founder",
                            detail = founderName
                        )
                        ContactRow(
                            icon = Icons.Default.Phone,
                            title = if (isGu) "સંપર્ક નંબર" else "Mobile Number",
                            detail = phoneNumber
                        )
                        ContactRow(
                            icon = Icons.Default.Chat,
                            title = if (isGu) "વોટ્સએપ" else "WhatsApp",
                            detail = settings.whatsappNumber.ifBlank { phoneNumber }
                        )
                        ContactRow(
                            icon = Icons.Default.LocationOn,
                            title = if (isGu) "સરનામું" else "Address",
                            detail = settings.address.ifBlank { "કવિથા, રાજપૂત સમાજ વાડી, કોટડિયા ફળી, કવિથા, ગુજરાત" }
                        )
                        ContactRow(
                            icon = Icons.Default.Schedule,
                            title = if (isGu) "સમય" else "Timings",
                            detail = "સોમ થી શનિ: સવારે ૮:૦૦ થી રાત્રે ૮:૦૦"
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("કૉલ કરો", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val url = "https://wa.me/$waDigits"
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    try {
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Call: $phoneNumber", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("વોટ્સએપ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Footer
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PurplePrimary)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    HDLogo(size = 48.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = businessName,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Text(
                        text = "સંચાલક: $founderName • મો. $phoneNumber",
                        fontSize = 12.sp,
                        color = GoldYellowLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "© $businessName • સર્વ હક સુરક્ષિત.",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyLiveInfoBanner(text: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            color = TextMuted,
            modifier = Modifier.padding(14.dp),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SectionHeader(title: String, icon: ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(PurpleContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = title,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 17.sp,
            color = PurplePrimary
        )
    }
}

@Composable
private fun FeeRow(std: String, monthly: String, annual: String, highlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = std,
                fontWeight = if (highlight) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp,
                color = if (highlight) PurplePrimary else TextDark
            )
            Text(
                text = "વાર્ષિક: $annual",
                fontSize = 11.sp,
                color = TextMuted
            )
        }
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (highlight) GoldYellowContainer else BackgroundLight
        ) {
            Text(
                text = monthly,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (highlight) GoldYellowDeep else TextDark,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun WhyChooseItem(icon: ImageVector, title: String, desc: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PurpleContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextDark)
                Text(text = desc, fontSize = 11.sp, color = TextMuted)
            }
        }
    }
}

@Composable
private fun ContactRow(icon: ImageVector, title: String, detail: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.SemiBold)
            Text(text = detail, fontSize = 12.sp, color = TextDark, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun PortalBoxCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    desc: String,
    icon: ImageVector,
    bgBrush: Brush,
    accentColor: Color = GoldYellow,
    textColor: Color = Color.White,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .shadow(6.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(bgBrush)
                .border(1.5.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                .padding(vertical = 14.dp, horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = title,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = textColor,
                    letterSpacing = 0.5.sp,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = subtitle,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = accentColor,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = desc,
                    fontSize = 9.sp,
                    color = textColor.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}
