package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.data.repository.HDTuitionRepository
import com.example.ui.components.OfficialReceiptCard
import com.example.ui.screens.admin.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPortalScreen(
    repository: HDTuitionRepository,
    onBack: () -> Unit,
    initialAuthenticated: Boolean = false,
    onGoogleSignOut: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val currentLang by repository.currentLanguage.collectAsState()
    val isGu = currentLang == AppLanguage.GUJARATI

    var isAuthenticated by remember { mutableStateOf(initialAuthenticated) }
    var inputAdminId by remember { mutableStateOf("") }
    var inputPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoggingIn by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }

    val isOwnerGoogleUser = repository.isCurrentUserOwner()
    val adminSetupDone by repository.isAdminSetupComplete.collectAsState()
    val adminAccount by repository.adminAccount.collectAsState()

    LaunchedEffect(isAuthenticated, isOwnerGoogleUser) {
        if (!isAuthenticated && isOwnerGoogleUser) {
            repository.refreshAdminSetupState()
        }
    }

    // 0: Overview, 1: Students, 2: Admissions, 3: Advance Bookings, 4: Fees Management,
    // 5: Receipts, 6: Attendance, 7: Homework, 8: Results & Toppers, 9: Timetable,
    // 10: Offers, 11: Announcements, 12: Teachers, 13: Reports & Accounts, 14: Settings
    var selectedSection by remember { mutableIntStateOf(0) }

    var selectedReceiptForView by remember { mutableStateOf<FeeReceipt?>(null) }
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var showRecordFeeDialog by remember { mutableStateOf(false) }
    var showAddHomeworkDialog by remember { mutableStateOf(false) }
    var showAddAnnouncementDialog by remember { mutableStateOf(false) }

    val students by repository.students.collectAsState()
    val admissions by repository.admissions.collectAsState()
    val advanceBookings by repository.advanceBookings.collectAsState()
    val receipts by repository.receipts.collectAsState()
    val homeworkList by repository.homework.collectAsState()
    val announcements by repository.announcements.collectAsState()
    val offers by repository.offers.collectAsState()
    val offerHistory by repository.offerHistory.collectAsState()
    val teachers by repository.teachers.collectAsState()
    val toppers by repository.toppers.collectAsState()
    val settings by repository.settings.collectAsState()

    if (!isAuthenticated) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = if (isGu) "એડમિન લૉગિન (Admin Login)" else "Admin Login",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("admin_login_back_btn")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
                )
            },
            modifier = modifier
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(PurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = "Admin",
                        tint = PurplePrimary,
                        modifier = Modifier.size(44.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = settings.businessName.ifBlank { "HD TUITION CLASSES" },
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = PurplePrimary
                )
                Text(
                    text = if (isGu) "સંચાલક / એડમિનિસ્ટ્રેટર લૉગિન (માત્ર એડમિન)" else "Administrator Portal (Owner Only)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(20.dp))

                if (!isOwnerGoogleUser) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = StatusErrorContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.GppBad, contentDescription = null, tint = StatusError, modifier = Modifier.size(34.dp))
                            Text(
                                text = if (isGu) "માત્ર અધિકૃત સંચાલક Google એકાઉન્ટ જ Admin ઍક્સેસ કરી શકે છે" else "Owner Google Account Required",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = StatusError,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Signed in as: ${repository.currentAuthEmail() ?: "Unknown"}\nRequired: ${HDTuitionRepository.OWNER_EMAIL}",
                                fontSize = 12.sp,
                                color = TextDark,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onGoogleSignOut,
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (isGu) "Google એકાઉન્ટ બદલો (Sign Out)" else "Switch Google Account")
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = inputAdminId,
                        onValueChange = { inputAdminId = it },
                        label = { Text(if (isGu) "એડમિન ID અથવા મોબાઇલ નંબર *" else "Admin ID or Mobile *") },
                        leadingIcon = { Icon(Icons.Default.AccountCircle, contentDescription = null, tint = PurplePrimary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_id_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        enabled = !isLoggingIn
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = inputPassword,
                        onValueChange = { inputPassword = it },
                        label = { Text(if (isGu) "પાસવર્ડ (Password) *" else "Password *") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (passwordVisible) "Hide Password" else "Show Password"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_password_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        enabled = !isLoggingIn
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            if (!adminSetupDone) {
                                Toast.makeText(
                                    context,
                                    if (isGu) "કૃપા કરીને મુખ્ય સ્ક્રીન પર 'Admin Login' માં ઓનર સેટઅપ પૂર્ણ કરો." else "Complete Owner Admin Setup on the main Admin Login screen first.",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@Button
                            }
                            if (inputAdminId.isBlank() || inputPassword.isBlank()) {
                                Toast.makeText(context, "Admin ID અને પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            coroutineScope.launch {
                                isLoggingIn = true
                                val res = repository.authenticateAdmin(inputAdminId.trim(), inputPassword.trim())
                                isLoggingIn = false
                                res.onSuccess {
                                    isAuthenticated = true
                                    inputPassword = ""
                                    Toast.makeText(context, "સ્વાગત છે! એડમિન કંટ્રોલ પેનલ સક્રિય છે.", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(
                                        context,
                                        err.localizedMessage ?: "ખોટો Admin ID અથવા Password!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        },
                        enabled = !isLoggingIn,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_login_submit_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(vertical = 14.dp)
                    ) {
                        if (isLoggingIn) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text(
                                text = if (isGu) "એડમિન પેનલ ખોલો (Login)" else "Access Admin Dashboard",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "HD ADMIN DASHBOARD",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "${settings.founderName.ifBlank { "હર્ષદસિંહ રાઠોડ" }} • લાઇવ કંટ્રોલ",
                                fontSize = 11.sp,
                                color = GoldYellowLight
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                repository.clearPortalSession()
                                isAuthenticated = false
                            },
                            modifier = Modifier.testTag("admin_logout_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { onBack() },
                            modifier = Modifier.testTag("admin_view_website_btn")
                        ) {
                            Icon(Icons.Default.Home, contentDescription = "Go to Home", tint = GoldYellow)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
                )
            },
            modifier = modifier
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BackgroundLight)
            ) {
                val sections = listOf(
                    Pair(0, "૧. ઓવરવ્યૂ"),
                    Pair(1, "૨. વિદ્યાર્થીઓ"),
                    Pair(2, "૩. એડમિશન"),
                    Pair(3, "૪. સીટ બુકિંગ"),
                    Pair(4, "૫. ફી મેનેજમેન્ટ"),
                    Pair(5, "૬. પાવતીઓ"),
                    Pair(6, "૭. હાજરી"),
                    Pair(7, "૮. હોમવર્ક"),
                    Pair(8, "૯. પરિણામ & ટોપર"),
                    Pair(9, "૧૦. ટાઇમટેબલ"),
                    Pair(10, if (isGu) "૧૧. ઑફર્સ મેનેજ" else "11. Manage Offers"),
                    Pair(11, "૧૨. જાહેરાતો"),
                    Pair(12, "૧૩. શિક્ષકો"),
                    Pair(13, "૧૪. હિસાબ રિપોર્ટ"),
                    Pair(14, "૧૫. સેટિંગ્સ")
                )

                PrimaryScrollableTabRow(
                    selectedTabIndex = selectedSection,
                    containerColor = Color.White,
                    contentColor = PurplePrimary,
                    edgePadding = 12.dp
                ) {
                    sections.forEach { (index, title) ->
                        Tab(
                            selected = selectedSection == index,
                            onClick = { selectedSection = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedSection == index) FontWeight.Black else FontWeight.Medium
                                )
                            },
                            modifier = Modifier.testTag("admin_section_tab_$index")
                        )
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (selectedSection) {
                        0 -> AdminOverviewView(
                            students = students,
                            teachers = teachers,
                            admissions = admissions,
                            bookings = advanceBookings,
                            receipts = receipts,
                            onNavigateTo = { selectedSection = it },
                            onRecordFee = { showRecordFeeDialog = true },
                            onAddStudent = { showAddStudentDialog = true }
                        )

                        1 -> AdminStudentsView(
                            students = students,
                            isBusy = isBusy,
                            onAddStudent = { showAddStudentDialog = true },
                            onApproveStudent = { studentId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminApproveStudent(studentId)
                                        .onSuccess { Toast.makeText(context, "વિદ્યાર્થી મંજૂર થયો ✓", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onRejectStudent = { studentId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminRejectStudent(studentId)
                                        .onSuccess { Toast.makeText(context, "અસ્વીકાર નોંધાયો", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onToggleActive = { studentId, active ->
                                coroutineScope.launch {
                                    repository.adminToggleStudentActive(studentId, active)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_SHORT).show() }
                                }
                            },
                            onUpdateStudent = { updatedStd ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateStudent(updatedStd)
                                        .onSuccess { Toast.makeText(context, "વિદ્યાર્થી વિગત અપડેટ થઈ!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onDeleteStudent = { std ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.deleteStudent(std)
                                        .onSuccess { Toast.makeText(context, "વિદ્યાર્થી ડિલીટ થયો", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onResetPassword = { studentId, newPass ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminSetStudentPassword(studentId, newPass)
                                        .onSuccess { Toast.makeText(context, "વિદ્યાર્થી પાસવર્ડ બદલાઈ ગયો!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        2 -> AdminAdmissionsView(
                            admissions = admissions,
                            isBusy = isBusy,
                            onApprove = { id ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateInquiryStatus(id, InquiryStatus.APPROVED)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_SHORT).show() }
                                    isBusy = false
                                }
                            },
                            onReject = { id ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateInquiryStatus(id, InquiryStatus.REJECTED)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_SHORT).show() }
                                    isBusy = false
                                }
                            },
                            onConvertToStudent = { inquiryId, initPass ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.convertInquiryToStudent(inquiryId, initPass)
                                        .onSuccess { newStd ->
                                            Toast.makeText(context, "વિદ્યાર્થી એકાઉન્ટ બન્યું: ID ${newStd.id}!", Toast.LENGTH_LONG).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Conversion failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        3 -> AdminBookingsView(
                            bookings = advanceBookings,
                            isBusy = isBusy,
                            onConfirm = { bookingId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.approveBookingWithReceipt(bookingId)
                                        .onSuccess { rec ->
                                            Toast.makeText(context, "બુકિંગ મંજૂર! પાવતી નંબર: ${rec.receiptNo}", Toast.LENGTH_SHORT).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Approval failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onReject = { bookingId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateBookingStatus(bookingId, BookingPaymentStatus.REJECTED)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_SHORT).show() }
                                    isBusy = false
                                }
                            },
                            onAddRemainingFees = { bookingId, remAmount, initPass ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.addBookingRemainingFees(bookingId, remAmount, initPass)
                                        .onSuccess { std ->
                                            Toast.makeText(context, "વિદ્યાર્થી તરીકે સફળતાપૂર્વક ઉમેરાયા: ${std.id}", Toast.LENGTH_LONG).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        4 -> AdminFeesView(
                            students = students,
                            isBusy = isBusy,
                            onRecordPayment = { showRecordFeeDialog = true },
                            onApplySpecialDiscount = { studentId, amt, reason ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.applySpecialDiscount(studentId, amt, reason)
                                        .onSuccess { Toast.makeText(context, "ફી છૂટ / માફી અપડેટ થઈ!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        5 -> AdminReceiptsView(
                            receipts = receipts,
                            isBusy = isBusy,
                            onViewReceipt = { selectedReceiptForView = it },
                            onVerifyPendingReceipt = { receiptId, approve ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminVerifyPendingReceipt(receiptId, approve)
                                        .onSuccess {
                                            Toast.makeText(
                                                context,
                                                if (approve) "UPI પેમેન્ટ વેરિફાય અને ફી જમા થઈ ✓" else "પાવતી અસ્વીકૃત માર્ક થઈ",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Verification failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        6 -> AdminAttendanceView(
                            students = students,
                            repository = repository
                        )

                        7 -> AdminHomeworkView(
                            homeworkList = homeworkList,
                            onAddHomework = { showAddHomeworkDialog = true },
                            onDeleteHomework = { id ->
                                coroutineScope.launch {
                                    repository.deleteHomework(id)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_SHORT).show() }
                                }
                            }
                        )

                        8 -> AdminResultsView(
                            students = students,
                            toppers = toppers,
                            repository = repository
                        )

                        9 -> AdminTimetableView(repository = repository)

                        10 -> AdminManageOffersView(
                            offers = offers,
                            offerHistory = offerHistory,
                            students = students,
                            isGu = isGu,
                            isBusy = isBusy,
                            onCreateOffer = { offer ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.addOffer(offer)
                                        .onSuccess { created ->
                                            Toast.makeText(
                                                context,
                                                if (isGu) "નવી ઑફર લાઇવ થઈ: ${created.title} ✓" else "Offer published live ✓",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onUpdateOffer = { updated ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateOffer(updated)
                                        .onSuccess {
                                            Toast.makeText(
                                                context,
                                                if (isGu) "ઑફર અપડેટ થઈ ✓" else "Offer updated ✓",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onDeleteOffer = { id ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.deleteOffer(id)
                                        .onSuccess {
                                            Toast.makeText(
                                                context,
                                                if (isGu) "ઑફર ડિલીટ થઈ" else "Offer deleted",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onToggleStatus = { id ->
                                coroutineScope.launch {
                                    repository.toggleOfferStatus(id)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_SHORT).show() }
                                }
                            },
                            onApplyOfferToEligible = { offerId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminApplyOfferToEligibleStudents(offerId)
                                        .onSuccess { count ->
                                            Toast.makeText(
                                                context,
                                                if (isGu) "$count પાત્ર વિદ્યાર્થીઓને ઑફર લાગુ થઈ ✓" else "Applied offer to $count eligible student(s) ✓",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onRevokeStudentOffer = { studentId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminRevokeStudentOffer(studentId)
                                        .onSuccess {
                                            Toast.makeText(
                                                context,
                                                if (isGu) "વિદ્યાર્થીની ઑફર રદ થઈ" else "Offer discount revoked",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        11 -> AdminAnnouncementsView(
                            announcements = announcements,
                            onAdd = { showAddAnnouncementDialog = true },
                            onDelete = { id ->
                                coroutineScope.launch {
                                    repository.deleteAnnouncement(id)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Delete failed", Toast.LENGTH_SHORT).show() }
                                }
                            }
                        )

                        12 -> AdminTeachersView(
                            teachers = teachers,
                            isBusy = isBusy,
                            onAddTeacher = { name, mobile, subjects, qualification, experience, password, standards ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.registerTeacher(name, mobile, subjects, qualification, experience, password, standards)
                                        .onSuccess { created ->
                                            Toast.makeText(context, "શિક્ષક ઉમેરાયા: ${created.name} (${created.teacherId})", Toast.LENGTH_SHORT).show()
                                        }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Add teacher failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onApproveTeacher = { docId, assignedStds ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminApproveTeacher(docId, assignedStds)
                                        .onSuccess { Toast.makeText(context, "શિક્ષક મંજૂર થયા ✓", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onRejectTeacher = { docId ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminRejectTeacher(docId)
                                        .onSuccess { Toast.makeText(context, "શિક્ષક અસ્વીકાર નોંધાયો", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onToggleTeacherActive = { teacher, active ->
                                coroutineScope.launch {
                                    repository.adminToggleTeacherActive(teacher, active)
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_SHORT).show() }
                                }
                            },
                            onUpdateTeacher = { updatedTeacher ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateTeacher(updatedTeacher)
                                        .onSuccess { Toast.makeText(context, "શિક્ષકની વિગત અપડેટ થઈ!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onDeleteTeacher = { teacher ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.deleteTeacher(teacher)
                                        .onSuccess { Toast.makeText(context, "શિક્ષક ડિલીટ થયા", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onResetPassword = { teacherDocId, newPass ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.adminSetTeacherPassword(teacherDocId, newPass)
                                        .onSuccess { Toast.makeText(context, "શિક્ષક પાસવર્ડ બદલાઈ ગયો!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Error", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )

                        13 -> AdminReportsView(students = students, receipts = receipts)

                        14 -> AdminSettingsView(
                            settings = settings,
                            adminAccount = adminAccount,
                            isBusy = isBusy,
                            onSaveSettings = { updated ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateSettings(updated)
                                        .onSuccess { Toast.makeText(context, "સેટિંગ્સ સફળતાપૂર્વક અપડેટ થયા!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            },
                            onUpdateAdminCredentials = { newId, newPass ->
                                coroutineScope.launch {
                                    isBusy = true
                                    repository.updateAdminCredentials(newId, newPass)
                                        .onSuccess { Toast.makeText(context, "એડમિન ક્રેડેન્શિયલ સફળતાપૂર્વક અપડેટ થયા!", Toast.LENGTH_SHORT).show() }
                                        .onFailure { Toast.makeText(context, it.localizedMessage ?: "Failed", Toast.LENGTH_LONG).show() }
                                    isBusy = false
                                }
                            }
                        )
                    }
                }
            }

            if (showAddStudentDialog) {
                AddStudentDialog(
                    onDismiss = { showAddStudentDialog = false },
                    onAdd = { name, parent, phone, std, totalFee, pwd ->
                        coroutineScope.launch {
                            isBusy = true
                            repository.adminCreateStudent(
                                name = name,
                                parentName = parent,
                                mobileNumber = phone,
                                standard = std,
                                password = pwd,
                                totalFees = totalFee
                            ).onSuccess { created ->
                                Toast.makeText(context, "વિદ્યાર્થી ઉમેરાયો: ${created.name} (${created.id})", Toast.LENGTH_SHORT).show()
                                showAddStudentDialog = false
                            }.onFailure { err ->
                                Toast.makeText(context, err.localizedMessage ?: "Add student failed", Toast.LENGTH_LONG).show()
                            }
                            isBusy = false
                        }
                    }
                )
            }

            if (showRecordFeeDialog) {
                RecordFeePaymentDialog(
                    students = students,
                    onDismiss = { showRecordFeeDialog = false },
                    onSubmit = { studentId, amount, mode, ref ->
                        coroutineScope.launch {
                            isBusy = true
                            repository.recordFeePayment(studentId, amount, mode, ref)
                                .onSuccess { receipt ->
                                    Toast.makeText(context, "ફી જમા થઈ ગઈ! પાવતી નં: ${receipt.receiptNo}", Toast.LENGTH_LONG).show()
                                    selectedReceiptForView = receipt
                                    showRecordFeeDialog = false
                                }
                                .onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Payment failed", Toast.LENGTH_LONG).show()
                                }
                            isBusy = false
                        }
                    }
                )
            }

            if (showAddHomeworkDialog) {
                AddHomeworkDialog(
                    onDismiss = { showAddHomeworkDialog = false },
                    onAdd = { hw ->
                        coroutineScope.launch {
                            isBusy = true
                            repository.addHomework(hw)
                                .onSuccess {
                                    Toast.makeText(context, "નવું ગૃહકાર્ય મુકાયું!", Toast.LENGTH_SHORT).show()
                                    showAddHomeworkDialog = false
                                }
                                .onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Homework post failed", Toast.LENGTH_LONG).show()
                                }
                            isBusy = false
                        }
                    }
                )
            }

            if (showAddAnnouncementDialog) {
                AddAnnouncementDialog(
                    onDismiss = { showAddAnnouncementDialog = false },
                    onAdd = { item ->
                        coroutineScope.launch {
                            isBusy = true
                            repository.addAnnouncement(item)
                                .onSuccess {
                                    Toast.makeText(context, "જાહેરાત પ્રસિદ્ધ થઈ!", Toast.LENGTH_SHORT).show()
                                    showAddAnnouncementDialog = false
                                }
                                .onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Publish failed", Toast.LENGTH_LONG).show()
                                }
                            isBusy = false
                        }
                    }
                )
            }

            if (selectedReceiptForView != null) {
                Dialog(onDismissRequest = { selectedReceiptForView = null }) {
                    OfficialReceiptCard(
                        receipt = selectedReceiptForView!!,
                        onDismiss = { selectedReceiptForView = null }
                    )
                }
            }
        }
    }
}
