package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.HDTuitionRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun matchesAssignedStandards(targetStd: String, assigned: List<String>): Boolean {
    if (assigned.isEmpty() || assigned.any { it.equals("All", ignoreCase = true) }) return true
    val targetNum = HDTuitionRepository.extractStandardNumber(targetStd)
    return assigned.any { s ->
        s.equals(targetStd, ignoreCase = true) ||
            HDTuitionRepository.extractStandardNumber(s) == targetNum
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherPortalScreen(
    repository: HDTuitionRepository,
    initialTeacher: TeacherProfile? = null,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val currentLang by repository.currentLanguage.collectAsState()
    val isGu = currentLang == AppLanguage.GUJARATI

    val settings by repository.settings.collectAsState()

    var currentTeacher by remember { mutableStateOf<TeacherProfile?>(initialTeacher) }
    var inputTeacherId by remember { mutableStateOf("") }
    var inputPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoggingIn by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }

    var showPasswordChangeDialog by remember { mutableStateOf(false) }
    var showForgotHelpDialog by remember { mutableStateOf(false) }

    var selectedTab by remember { mutableIntStateOf(0) }
    // 0: Attendance, 1: Homework & Review, 2: Marks & Notices, 3: Timetable, 4: Profile

    val allStudents by repository.students.collectAsState()
    val teachers by repository.teachers.collectAsState()
    val allHomework by repository.homework.collectAsState()
    val homeworkSubmissions by repository.homeworkSubmissions.collectAsState()
    val timetable by repository.timetable.collectAsState()
    val announcements by repository.announcements.collectAsState()

    var reviewingSubmission by remember { mutableStateOf<HomeworkSubmission?>(null) }
    var reviewFeedbackText by remember { mutableStateOf("") }

    val todayDate = remember { SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date()) }
    val assignedDateShort = remember { SimpleDateFormat("dd-MMM", Locale.ENGLISH).format(Date()) }

    if (currentTeacher == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = if (isGu) "શિક્ષક લૉગિન (Teacher Portal)" else "Teacher Login",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("teacher_login_back_btn")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PurpleMedium)
                )
            },
            modifier = modifier
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(PurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CoPresent,
                        contentDescription = "Teacher",
                        tint = PurplePrimary,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = settings.businessName.ifBlank { "HD TUITION CLASSES" },
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = PurplePrimary
                )
                Text(
                    text = if (isGu) "શિક્ષક / ફેકલ્ટી પોર્ટલ લૉગિન" else "Faculty Portal Login",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = inputTeacherId,
                    onValueChange = { inputTeacherId = it },
                    label = { Text(if (isGu) "શિક્ષક આઈડી અથવા મોબાઇલ નંબર *" else "Teacher ID or Mobile *") },
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = PurplePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("teacher_id_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    enabled = !isLoggingIn
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = inputPassword,
                    onValueChange = { inputPassword = it },
                    label = { Text(if (isGu) "પાસવર્ડ (Password) *" else "Password *") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (passwordVisible) "Hide Password" else "Show Password"
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("teacher_password_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    enabled = !isLoggingIn
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = if (isGu) "પાસવર્ડ ભૂલી ગયા છો?" else "Forgot Password?",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurplePrimary,
                        modifier = Modifier
                            .clickable { showForgotHelpDialog = true }
                            .padding(8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (inputTeacherId.isBlank() || inputPassword.isBlank()) {
                            Toast.makeText(
                                context,
                                if (isGu) "Teacher ID અને પાસવર્ડ લખો" else "Enter Teacher ID and Password",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }
                        coroutineScope.launch {
                            isLoggingIn = true
                            val res = repository.authenticateTeacher(inputTeacherId.trim(), inputPassword.trim())
                            isLoggingIn = false
                            res.onSuccess { teacher ->
                                currentTeacher = teacher
                                inputPassword = ""
                                Toast.makeText(context, "સ્વાગત છે, ${teacher.name}!", Toast.LENGTH_SHORT).show()
                            }.onFailure { err ->
                                Toast.makeText(
                                    context,
                                    err.localizedMessage ?: "ખોટો Teacher ID અથવા પાસવર્ડ!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    },
                    enabled = !isLoggingIn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("teacher_login_submit_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    if (isLoggingIn) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = if (isGu) "શિક્ષક પોર્ટલ ખોલો (Login)" else "Open Teacher Portal",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        if (showForgotHelpDialog) {
            AlertDialog(
                onDismissRequest = { showForgotHelpDialog = false },
                title = { Text(if (isGu) "શિક્ષક પાસવર્ડ સહાય" else "Password Assistance") },
                text = {
                    Text(
                        text = if (isGu) {
                            "સુરક્ષા માટે લૉગિન વગર પાસવર્ડ બદલી શકાતો નથી.\n\n• લૉગિન કર્યા બાદ ટોપ બારમાં 🔒 આઇકનથી તમારો પાસવર્ડ બદલી શકો છો.\n• પાસવર્ડ ભૂલી ગયા હો તો એડમિન (${settings.contactPhone}) નો સંપર્ક કરો."
                        } else {
                            "Unauthenticated password reset is disabled for security.\n\n• Log in and use the top Lock icon to change your password.\n• If you forgot your password, contact Admin (${settings.contactPhone})."
                        },
                        fontSize = 13.sp,
                        color = TextDark
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showForgotHelpDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium)
                    ) {
                        Text(if (isGu) "સમજાયું" else "OK")
                    }
                }
            )
        }
    } else {
        // Authenticated Teacher Dashboard
        val teacher = teachers.firstOrNull { it.id == currentTeacher!!.id } ?: currentTeacher!!
        val scopedStudents = remember(allStudents, teacher.assignedStandards) {
            allStudents.filter { matchesAssignedStandards(it.standard, teacher.assignedStandards) }
        }
        val scopedHomework = remember(allHomework, teacher.assignedStandards) {
            allHomework.filter { matchesAssignedStandards(it.standard, teacher.assignedStandards) }
        }
        val teacherTimetable = remember(timetable, teacher.name, teacher.assignedStandards) {
            timetable.filter { slot ->
                slot.teacherName.contains(teacher.name, ignoreCase = true) ||
                    matchesAssignedStandards(slot.standard, teacher.assignedStandards)
            }
        }
        val currentUid = repository.currentAuthUid().orEmpty()
        val teacherNotices = remember(announcements, currentUid) {
            announcements.filter { it.teacherUid == currentUid || currentUid.isBlank() }
        }

        val attendanceMap = remember { mutableStateMapOf<String, AttendanceStatus>() }
        LaunchedEffect(scopedStudents) {
            scopedStudents.forEach { std ->
                if (!attendanceMap.containsKey(std.id)) {
                    attendanceMap[std.id] = AttendanceStatus.PRESENT
                }
            }
        }

        val defaultStandard = remember(teacher.assignedStandards) {
            teacher.assignedStandards.firstOrNull { !it.equals("All", ignoreCase = true) } ?: "Std 10"
        }
        var hwStandard by remember(defaultStandard) { mutableStateOf(defaultStandard) }
        var hwSubject by remember { mutableStateOf(teacher.subjects.split(",").firstOrNull()?.trim()?.ifBlank { "ગણિત (Mathematics)" } ?: "ગણિત (Mathematics)") }
        var hwTitle by remember { mutableStateOf("") }
        var hwDesc by remember { mutableStateOf("") }
        var hwDue by remember { mutableStateOf(todayDate) }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = teacher.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "${teacher.teacherId} • ${teacher.assignedStandards.ifEmpty { listOf("All") }.joinToString(", ")}",
                                fontSize = 11.sp,
                                color = GoldYellowLight
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                repository.clearPortalSession()
                                currentTeacher = null
                            },
                            modifier = Modifier.testTag("teacher_logout_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showPasswordChangeDialog = true },
                            modifier = Modifier.testTag("teacher_change_pwd_btn")
                        ) {
                            Icon(Icons.Default.LockReset, contentDescription = "Change Password", tint = GoldYellow)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PurpleMedium)
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(0, if (isGu) "હાજરી" else "Attend.", Icons.Default.EventAvailable),
                        Triple(1, if (isGu) "હોમવર્ક" else "Homework", Icons.Default.Assignment),
                        Triple(2, if (isGu) "ગુણ & નોટિસ" else "Marks/Notice", Icons.Default.Grade),
                        Triple(3, if (isGu) "સમયપત્રક" else "Schedule", Icons.Default.Schedule),
                        Triple(4, if (isGu) "પ્રોફાઇલ" else "Profile", Icons.Default.Person)
                    )
                    tabs.forEach { (index, label, icon) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PurpleMedium,
                                selectedTextColor = PurpleMedium,
                                indicatorColor = PurpleContainer
                            ),
                            modifier = Modifier.testTag("teacher_tab_$index")
                        )
                    }
                }
            },
            modifier = modifier
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BackgroundLight)
            ) {
                when (selectedTab) {
                    0 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = "બેચ હાજરી માર્કિંગ", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PurplePrimary)
                                        Text(text = "તારીખ: $todayDate (${scopedStudents.size} વિદ્યાર્થી)", fontSize = 12.sp, color = TextMuted)
                                    }

                                    Button(
                                        onClick = {
                                            if (scopedStudents.isEmpty()) {
                                                Toast.makeText(context, "તમારા ધોરણમાં હજુ કોઈ વિદ્યાર્થી નથી.", Toast.LENGTH_SHORT).show()
                                                return@Button
                                            }
                                            coroutineScope.launch {
                                                isBusy = true
                                                val records = scopedStudents.map { std ->
                                                    AttendanceRecord(
                                                        studentId = std.id,
                                                        studentAuthUid = std.authUid,
                                                        standard = std.standard,
                                                        date = todayDate,
                                                        status = attendanceMap[std.id] ?: AttendanceStatus.PRESENT
                                                    )
                                                }
                                                val res = repository.markBatchAttendance(records)
                                                isBusy = false
                                                res.onSuccess {
                                                    Toast.makeText(context, "હાજરી સફળતાપૂર્વક સેવ થઈ ગઈ!", Toast.LENGTH_SHORT).show()
                                                }.onFailure { err ->
                                                    Toast.makeText(context, err.localizedMessage ?: "Attendance save failed", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        enabled = !isBusy && scopedStudents.isNotEmpty(),
                                        colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("હાજરી સેવ કરો", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (scopedStudents.isEmpty()) {
                                item {
                                    TeacherEmptyCard("તમને સોંપેલા ધોરણમાં હજુ કોઈ મંજૂર વિદ્યાર્થી ઉમેરાયેલ નથી.")
                                }
                            } else {
                                items(scopedStudents, key = { it.id }) { std ->
                                    val status = attendanceMap[std.id] ?: AttendanceStatus.PRESENT
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = std.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(text = "${std.standard} • ID: ${std.id}", fontSize = 11.sp, color = TextMuted)
                                            }

                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                FilterChip(
                                                    selected = status == AttendanceStatus.PRESENT,
                                                    onClick = { attendanceMap[std.id] = AttendanceStatus.PRESENT },
                                                    label = { Text("P", fontSize = 11.sp) },
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = StatusSuccessContainer,
                                                        selectedLabelColor = StatusSuccess
                                                    )
                                                )
                                                FilterChip(
                                                    selected = status == AttendanceStatus.ABSENT,
                                                    onClick = { attendanceMap[std.id] = AttendanceStatus.ABSENT },
                                                    label = { Text("A", fontSize = 11.sp) },
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = StatusErrorContainer,
                                                        selectedLabelColor = StatusError
                                                    )
                                                )
                                                FilterChip(
                                                    selected = status == AttendanceStatus.LEAVE,
                                                    onClick = { attendanceMap[std.id] = AttendanceStatus.LEAVE },
                                                    label = { Text("L", fontSize = 11.sp) },
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = StatusWarningContainer,
                                                        selectedLabelColor = StatusWarning
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = "વિદ્યાર્થીઓને નવું ગૃહકાર્ય (Homework) સોંપો",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = PurplePrimary
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        if (teacher.assignedStandards.isNotEmpty() && !teacher.assignedStandards.contains("All")) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .horizontalScroll(rememberScrollState()),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                teacher.assignedStandards.forEach { std ->
                                                    FilterChip(
                                                        selected = hwStandard == std,
                                                        onClick = { hwStandard = std },
                                                        label = { Text(std, fontSize = 11.sp) }
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                        }

                                        OutlinedTextField(
                                            value = hwStandard,
                                            onValueChange = { hwStandard = it },
                                            label = { Text("ધોરણ (Standard)") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        OutlinedTextField(
                                            value = hwSubject,
                                            onValueChange = { hwSubject = it },
                                            label = { Text("વિષય (Subject)") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        OutlinedTextField(
                                            value = hwTitle,
                                            onValueChange = { hwTitle = it },
                                            label = { Text("પ્રકરણ / વિષય શીર્ષક *") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        OutlinedTextField(
                                            value = hwDesc,
                                            onValueChange = { hwDesc = it },
                                            label = { Text("વિગત / સ્વાધ્યાય દાખલા નંબર") },
                                            modifier = Modifier.fillMaxWidth(),
                                            maxLines = 3
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        OutlinedTextField(
                                            value = hwDue,
                                            onValueChange = { hwDue = it },
                                            label = { Text("જમા તારીખ") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Button(
                                            onClick = {
                                                if (hwStandard.trim().length < 2 || hwSubject.trim().length < 2 || hwTitle.trim().length < 2) {
                                                    Toast.makeText(context, "કૃપા કરીને ધોરણ, વિષય અને શીર્ષક લખો", Toast.LENGTH_SHORT).show()
                                                    return@Button
                                                }
                                                coroutineScope.launch {
                                                    isBusy = true
                                                    val hw = HomeworkItem(
                                                        standard = hwStandard.trim(),
                                                        subject = hwSubject.trim(),
                                                        title = hwTitle.trim(),
                                                        description = hwDesc.trim(),
                                                        assignedDate = assignedDateShort,
                                                        dueDate = hwDue.trim().ifBlank { todayDate },
                                                        teacherName = teacher.name
                                                    )
                                                    val res = repository.addHomework(hw)
                                                    isBusy = false
                                                    res.onSuccess {
                                                        Toast.makeText(context, "હોમવર્ક સફળતાપૂર્વક મુકાઈ ગયું!", Toast.LENGTH_SHORT).show()
                                                        hwTitle = ""
                                                        hwDesc = ""
                                                    }.onFailure { err ->
                                                        Toast.makeText(context, err.localizedMessage ?: "Homework post failed", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            },
                                            enabled = !isBusy,
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text("હોમવર્ક પોસ્ટ કરો (Post Homework)", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            item {
                                Text(text = "તાજેતરમાં આપેલ હોમવર્ક (${scopedHomework.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextDark)
                            }

                            if (scopedHomework.isEmpty()) {
                                item {
                                    TeacherEmptyCard("હજુ સુધી કોઈ ગૃહકાર્ય મૂકાયેલ નથી.")
                                }
                            } else {
                                items(scopedHomework, key = { it.id }) { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = "${item.standard} • ${item.subject}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                                Text(text = item.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextDark)
                                                if (item.description.isNotBlank()) {
                                                    Text(text = item.description, fontSize = 11.sp, color = TextMuted)
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(text = "જમા તારીખ: ${item.dueDate} • આપનાર: ${item.teacherName}", fontSize = 10.sp, color = GoldYellowDeep)
                                            }
                                            if (item.teacherUid == currentUid && currentUid.isNotBlank()) {
                                                IconButton(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            repository.deleteHomework(item.id)
                                                                .onFailure { err ->
                                                                    Toast.makeText(context, err.localizedMessage ?: "Delete failed", Toast.LENGTH_SHORT).show()
                                                                }
                                                        }
                                                    }
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete Homework", tint = StatusError)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "વિદ્યાર્થીઓ દ્વારા જમા થયેલ ગૃહકાર્ય (${homeworkSubmissions.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (homeworkSubmissions.isEmpty()) {
                                item {
                                    TeacherEmptyCard("હજુ સુધી કોઈ વિદ્યાર્થીએ ગૃહકાર્ય જમા કર્યું નથી.")
                                }
                            } else {
                                items(homeworkSubmissions, key = { it.id }) { sub ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = sub.studentName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextDark)
                                                    Text(text = "${sub.subject} • ${sub.submittedAt}", fontSize = 10.sp, color = TextMuted)
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (sub.status == "Checked") StatusSuccessContainer else GoldYellowContainer
                                                ) {
                                                    Text(
                                                        text = if (sub.status == "Checked") "ચેક કરેલ ✓" else "ચકાસણી બાકી",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 10.sp,
                                                        color = if (sub.status == "Checked") StatusSuccess else GoldYellowDeep,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "જમા લખાણ: ${sub.submissionText}",
                                                fontSize = 12.sp,
                                                color = TextDark
                                            )

                                            if (sub.teacherFeedback.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "પ્રતિભાવ: ${sub.teacherFeedback}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = StatusSuccess
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))
                                            Button(
                                                onClick = {
                                                    reviewingSubmission = sub
                                                    reviewFeedbackText = sub.teacherFeedback
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer),
                                                shape = RoundedCornerShape(6.dp),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                                modifier = Modifier.align(Alignment.End)
                                            ) {
                                                Text("ચેક કરો & ફીડબેક આપો", fontSize = 11.sp, color = PurplePrimary, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Teacher Marks Entry & Notices
                        var subTab by remember { mutableIntStateOf(0) } // 0: Marks Entry, 1: Notices

                        var selectedStudentId by remember { mutableStateOf("") }
                        LaunchedEffect(scopedStudents) {
                            if (selectedStudentId.isBlank() || scopedStudents.none { it.id == selectedStudentId }) {
                                selectedStudentId = scopedStudents.firstOrNull()?.id.orEmpty()
                            }
                        }
                        var examName by remember { mutableStateOf("સાપ્તાહિક મોક ટેસ્ટ") }
                        var subj1Name by remember { mutableStateOf("ગણિત / એકાઉન્ટ") }
                        var subj1Obtained by remember { mutableStateOf("45") }
                        var subj1Max by remember { mutableStateOf("50") }
                        var subj2Name by remember { mutableStateOf("વિજ્ઞાન / સ્ટેટ") }
                        var subj2Obtained by remember { mutableStateOf("42") }
                        var subj2Max by remember { mutableStateOf("50") }

                        var noticeTitle by remember { mutableStateOf("") }
                        var noticeContent by remember { mutableStateOf("") }
                        var noticeTargetStd by remember { mutableStateOf(defaultStandard) }
                        var noticeUrgent by remember { mutableStateOf(false) }

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterChip(
                                        selected = subTab == 0,
                                        onClick = { subTab = 0 },
                                        label = { Text("પરીક્ષા ગુણ (Marks Entry)", fontWeight = FontWeight.Bold) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    FilterChip(
                                        selected = subTab == 1,
                                        onClick = { subTab = 1 },
                                        label = { Text("નોટિસ મૂકો (Notices)", fontWeight = FontWeight.Bold) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            if (subTab == 0) {
                                item {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(16.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text(
                                                text = "પરીક્ષા પરિણામ અપલોડ કરો",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = PurplePrimary
                                            )

                                            if (scopedStudents.isEmpty()) {
                                                Text(
                                                    text = "તમારા ધોરણમાં હજુ કોઈ મંજૂર વિદ્યાર્થી નથી.",
                                                    fontSize = 12.sp,
                                                    color = TextMuted
                                                )
                                            } else {
                                                Text(text = "વિદ્યાર્થી પસંદ કરો:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                                scopedStudents.forEach { std ->
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clickable { selectedStudentId = std.id }
                                                            .padding(vertical = 3.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        RadioButton(
                                                            selected = selectedStudentId == std.id,
                                                            onClick = { selectedStudentId = std.id }
                                                        )
                                                        Text(
                                                            text = "${std.name} (${std.standard} • ${std.id})",
                                                            fontSize = 13.sp
                                                        )
                                                    }
                                                }

                                                OutlinedTextField(
                                                    value = examName,
                                                    onValueChange = { examName = it },
                                                    label = { Text("પરીક્ષાનું નામ *") },
                                                    modifier = Modifier.fillMaxWidth(),
                                                    singleLine = true
                                                )

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = subj1Name,
                                                        onValueChange = { subj1Name = it },
                                                        label = { Text("વિષય ૧") },
                                                        modifier = Modifier.weight(1.4f),
                                                        singleLine = true
                                                    )
                                                    OutlinedTextField(
                                                        value = subj1Obtained,
                                                        onValueChange = { subj1Obtained = it },
                                                        label = { Text("મેળવેલ") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.weight(0.8f),
                                                        singleLine = true
                                                    )
                                                    OutlinedTextField(
                                                        value = subj1Max,
                                                        onValueChange = { subj1Max = it },
                                                        label = { Text("કુલ") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.weight(0.8f),
                                                        singleLine = true
                                                    )
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = subj2Name,
                                                        onValueChange = { subj2Name = it },
                                                        label = { Text("વિષય ૨ (વૈકલ્પિક)") },
                                                        modifier = Modifier.weight(1.4f),
                                                        singleLine = true
                                                    )
                                                    OutlinedTextField(
                                                        value = subj2Obtained,
                                                        onValueChange = { subj2Obtained = it },
                                                        label = { Text("મેળવેલ") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.weight(0.8f),
                                                        singleLine = true
                                                    )
                                                    OutlinedTextField(
                                                        value = subj2Max,
                                                        onValueChange = { subj2Max = it },
                                                        label = { Text("કુલ") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.weight(0.8f),
                                                        singleLine = true
                                                    )
                                                }

                                                Button(
                                                    onClick = {
                                                        val targetStd = scopedStudents.firstOrNull { it.id == selectedStudentId }
                                                        if (targetStd == null) {
                                                            Toast.makeText(context, "વિદ્યાર્થી પસંદ કરો", Toast.LENGTH_SHORT).show()
                                                            return@Button
                                                        }
                                                        if (examName.trim().length < 2) {
                                                            Toast.makeText(context, "પરીક્ષાનું યોગ્ય નામ લખો", Toast.LENGTH_SHORT).show()
                                                            return@Button
                                                        }
                                                        val scores = mutableListOf<SubjectScore>()
                                                        val m1 = subj1Obtained.toIntOrNull()
                                                        val max1 = subj1Max.toIntOrNull() ?: 50
                                                        if (subj1Name.isNotBlank() && m1 != null && max1 > 0) {
                                                            scores.add(SubjectScore(subj1Name.trim(), m1.coerceIn(0, max1), max1))
                                                        }
                                                        val m2 = subj2Obtained.toIntOrNull()
                                                        val max2 = subj2Max.toIntOrNull() ?: 50
                                                        if (subj2Name.isNotBlank() && m2 != null && max2 > 0) {
                                                            scores.add(SubjectScore(subj2Name.trim(), m2.coerceIn(0, max2), max2))
                                                        }
                                                        if (scores.isEmpty()) {
                                                            Toast.makeText(context, "ઓછામાં ઓછા એક વિષયના ગુણ લખો", Toast.LENGTH_SHORT).show()
                                                            return@Button
                                                        }
                                                        coroutineScope.launch {
                                                            isBusy = true
                                                            val res = repository.addExamResult(
                                                                ExamResult(
                                                                    studentId = targetStd.id,
                                                                    studentAuthUid = targetStd.authUid,
                                                                    examName = examName.trim(),
                                                                    examDate = todayDate,
                                                                    standard = targetStd.standard,
                                                                    scores = scores
                                                                )
                                                            )
                                                            isBusy = false
                                                            res.onSuccess { saved ->
                                                                Toast.makeText(
                                                                    context,
                                                                    "${targetStd.name} ના ગુણ સેવ થયા (%.1f%%)!".format(saved.percentage),
                                                                    Toast.LENGTH_SHORT
                                                                ).show()
                                                            }.onFailure { err ->
                                                                Toast.makeText(context, err.localizedMessage ?: "Marks save failed", Toast.LENGTH_LONG).show()
                                                            }
                                                        }
                                                    },
                                                    enabled = !isBusy,
                                                    modifier = Modifier.fillMaxWidth(),
                                                    colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                                                    shape = RoundedCornerShape(10.dp)
                                                ) {
                                                    Text("પરિણામ સેવ કરો (Save Marks)", fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                item {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(16.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = "વિદ્યાર્થીઓ માટે નવી નોટિસ મૂકો",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = PurplePrimary
                                            )
                                            OutlinedTextField(
                                                value = noticeTitle,
                                                onValueChange = { noticeTitle = it },
                                                label = { Text("નોટિસ શીર્ષક *") },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true
                                            )
                                            OutlinedTextField(
                                                value = noticeContent,
                                                onValueChange = { noticeContent = it },
                                                label = { Text("નોટિસ વિગત *") },
                                                modifier = Modifier.fillMaxWidth(),
                                                maxLines = 3
                                            )
                                            OutlinedTextField(
                                                value = noticeTargetStd,
                                                onValueChange = { noticeTargetStd = it },
                                                label = { Text("લક્ષિત ધોરણ (દા.ત. Std 10 અથવા All)") },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true
                                            )
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(checked = noticeUrgent, onCheckedChange = { noticeUrgent = it })
                                                Text("તાકીદની સૂચના (Urgent)", fontSize = 12.sp)
                                            }
                                            Button(
                                                onClick = {
                                                    if (noticeTitle.trim().length < 2 || noticeContent.trim().isBlank()) {
                                                        Toast.makeText(context, "શીર્ષક અને વિગત લખો", Toast.LENGTH_SHORT).show()
                                                        return@Button
                                                    }
                                                    coroutineScope.launch {
                                                        isBusy = true
                                                        val res = repository.addAnnouncement(
                                                            AnnouncementItem(
                                                                title = noticeTitle.trim(),
                                                                content = noticeContent.trim(),
                                                                date = todayDate,
                                                                isUrgent = noticeUrgent,
                                                                targetStandard = noticeTargetStd.trim().ifBlank { "All" },
                                                                authorName = teacher.name
                                                            )
                                                        )
                                                        isBusy = false
                                                        res.onSuccess {
                                                            noticeTitle = ""
                                                            noticeContent = ""
                                                            noticeUrgent = false
                                                            Toast.makeText(context, "નોટિસ પ્રસિદ્ધ થઈ ગઈ!", Toast.LENGTH_SHORT).show()
                                                        }.onFailure { err ->
                                                            Toast.makeText(context, err.localizedMessage ?: "Notice publish failed", Toast.LENGTH_LONG).show()
                                                        }
                                                    }
                                                },
                                                enabled = !isBusy,
                                                modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Text("નોટિસ પ્રસિદ્ધ કરો", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                item {
                                    Text(
                                        text = "મારી મૂકેલી નોટિસો (${teacherNotices.size})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextDark
                                    )
                                }

                                if (teacherNotices.isEmpty()) {
                                    item {
                                        TeacherEmptyCard("તમે હજુ સુધી કોઈ નોટિસ મૂકી નથી.")
                                    }
                                } else {
                                    items(teacherNotices, key = { it.id }) { ann ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color.White)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = "${ann.title} (${ann.targetStandard})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                                    Text(text = ann.content, fontSize = 12.sp, color = TextDark)
                                                    Text(text = ann.date, fontSize = 10.sp, color = TextMuted)
                                                }
                                                IconButton(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            repository.deleteAnnouncement(ann.id)
                                                                .onFailure { err ->
                                                                    Toast.makeText(context, err.localizedMessage ?: "Delete failed", Toast.LENGTH_SHORT).show()
                                                                }
                                                        }
                                                    }
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete Notice", tint = StatusError)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Text(
                                    text = "મારું સાપ્તાહિક સમયપત્રક (Teaching Schedule)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = PurplePrimary
                                )
                            }

                            if (teacherTimetable.isEmpty()) {
                                item {
                                    TeacherEmptyCard("હાલમાં તમારા ધોરણો માટે સમયપત્રક ઉપલબ્ધ નથી.")
                                }
                            } else {
                                items(teacherTimetable, key = { it.id }) { slot ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = "${slot.standard} • ${slot.dayOfWeek}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                                                Text(text = slot.subject, fontSize = 13.sp, color = TextDark)
                                                Text(text = "શિક્ષક: ${slot.teacherName} • રૂમ: ${slot.room}", fontSize = 11.sp, color = TextMuted)
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = PurpleContainer
                                            ) {
                                                Text(
                                                    text = slot.timeSlot,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = PurplePrimary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    4 -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(PurpleMedium),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = teacher.name.take(2).uppercase(),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 24.sp,
                                    color = GoldYellow
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(text = teacher.name, fontWeight = FontWeight.Black, fontSize = 18.sp, color = PurplePrimary)
                            Text(text = "${teacher.role} • ID: ${teacher.teacherId}", fontSize = 13.sp, color = TextMuted)

                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(text = "લાયકાત: ${teacher.qualification}", fontSize = 13.sp, color = TextDark)
                                    Text(text = "અનુભવ: ${teacher.experience}", fontSize = 13.sp, color = TextDark)
                                    Text(text = "વિષયો: ${teacher.subjects}", fontSize = 13.sp, color = TextDark)
                                    Text(
                                        text = "સોંપેલા ધોરણો: ${teacher.assignedStandards.ifEmpty { listOf("All") }.joinToString(", ")}",
                                        fontSize = 13.sp,
                                        color = PurplePrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(text = "સંપર્ક: ${teacher.contact}", fontSize = 13.sp, color = TextDark)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { showPasswordChangeDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.LockReset, contentDescription = null, tint = GoldYellow)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("પાસવર્ડ બદલો (Change Password)", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (showPasswordChangeDialog) {
                    var oldPassword by remember { mutableStateOf("") }
                    var newPassword by remember { mutableStateOf("") }
                    var confirmPassword by remember { mutableStateOf("") }

                    AlertDialog(
                        onDismissRequest = { if (!isBusy) showPasswordChangeDialog = false },
                        title = { Text("શિક્ષક પાસવર્ડ બદલો") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = oldPassword,
                                    onValueChange = { oldPassword = it },
                                    label = { Text("જૂનો પાસવર્ડ (Current Password)") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = newPassword,
                                    onValueChange = { newPassword = it },
                                    label = { Text("નવો પાસવર્ડ (New Password)") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = confirmPassword,
                                    onValueChange = { confirmPassword = it },
                                    label = { Text("નવો પાસવર્ડ કન્ફર્મ કરો") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    if (newPassword != confirmPassword) {
                                        Toast.makeText(context, "નવા પાસવર્ડ મેળ ખાતા નથી!", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    if (newPassword.trim().length < 4) {
                                        Toast.makeText(context, "પાસવર્ડ ઓછામાં ઓછો ૪ અક્ષરનો હોવો જોઈએ", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    coroutineScope.launch {
                                        isBusy = true
                                        val res = repository.changeTeacherPassword(teacher.id, teacher.teacherId, oldPassword, newPassword)
                                        isBusy = false
                                        res.onSuccess {
                                            Toast.makeText(context, "પાસવર્ડ સફળતાપૂર્વક બદલાઈ ગયો!", Toast.LENGTH_SHORT).show()
                                            showPasswordChangeDialog = false
                                        }.onFailure { err ->
                                            Toast.makeText(context, err.localizedMessage ?: "Password change failed", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                enabled = !isBusy,
                                colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium)
                            ) {
                                Text("બદલો")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showPasswordChangeDialog = false }, enabled = !isBusy) {
                                Text("રદ કરો")
                            }
                        }
                    )
                }

                if (reviewingSubmission != null) {
                    AlertDialog(
                        onDismissRequest = { if (!isBusy) reviewingSubmission = null },
                        title = {
                            Text(
                                text = "ગૃહકાર્ય ચકાસણી: ${reviewingSubmission!!.studentName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = PurplePrimary
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "વિષય: ${reviewingSubmission!!.subject}",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = TextDark
                                )
                                Text(
                                    text = "વિદ્યાર્થીનું લખાણ: ${reviewingSubmission!!.submissionText}",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                                OutlinedTextField(
                                    value = reviewFeedbackText,
                                    onValueChange = { reviewFeedbackText = it },
                                    label = { Text("શિક્ષક પ્રતિભાવ / માર્ગદર્શન") },
                                    placeholder = { Text("દા.ત. ખૂબ સરસ કામ! દાખલા નં ૪ માં ચિન્હનું ધ્યાન રાખવું.") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val subId = reviewingSubmission!!.id
                                    coroutineScope.launch {
                                        isBusy = true
                                        val res = repository.reviewHomeworkSubmission(
                                            submissionId = subId,
                                            status = "Checked",
                                            feedback = reviewFeedbackText.ifBlank { "સરસ પ્રયાસ! - ${teacher.name}" }
                                        )
                                        isBusy = false
                                        res.onSuccess {
                                            reviewingSubmission = null
                                            Toast.makeText(context, "ગૃહકાર્ય ચકાસીને સેવ કર્યું!", Toast.LENGTH_SHORT).show()
                                        }.onFailure { err ->
                                            Toast.makeText(context, err.localizedMessage ?: "Review save failed", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = !isBusy,
                                colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium)
                            ) {
                                Text("ચકાસેલ (Checked) માર્ક કરો")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { reviewingSubmission = null }, enabled = !isBusy) {
                                Text("બંધ કરો")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TeacherEmptyCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Text(
            text = message,
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
    }
}
