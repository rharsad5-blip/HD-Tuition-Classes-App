package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun PaymentQRCodeView(
    amount: Int = 99,
    upiId: String = "8511273911@upi",
    payeeName: String = "Harshadsinh Rathod (HD Tuition)",
    note: String = "Advance Seat Booking",
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("payment_qr_code_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(30.dp))
                    .background(PurpleContainer)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = null,
                    tint = PurplePrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ઓરિજિનલ પેમેન્ટ QR કોડ (Scan & Pay)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = PurplePrimary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "₹$amount",
                fontWeight = FontWeight.Black,
                fontSize = 32.sp,
                color = PurplePrimary
            )
            Text(
                text = "એડવાન્સ સીટ બુકિંગ રકમ",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas QR Code Representation
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(2.dp, PurplePrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                QRCanvas(modifier = Modifier.fillMaxSize())

                // Mini Center Logo Badge
                HDLogo(size = 46.dp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Payee Info Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BackgroundLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "UPI ID: $upiId",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PurplePrimary
                        )
                        Text(
                            text = "ખાતાધારક: $payeeName",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("UPI ID", upiId)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "UPI ID કોપી થઈ ગયું: $upiId", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("copy_upi_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy UPI ID",
                            tint = PurplePrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Supported UPI logos / apps badge
            Text(
                text = "GPay • PhonePe • Paytm • BHIM • All UPI Apps Accepted",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Open in UPI Button
            Button(
                onClick = {
                    val uri = Uri.parse("upi://pay?pa=$upiId&pn=${Uri.encode(payeeName)}&am=$amount&cu=INR&tn=${Uri.encode(note)}")
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "કોઈપણ UPI એપ ખોલીને $upiId પર ₹$amount ચૂકવો", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("open_upi_app_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Payment,
                    contentDescription = null,
                    tint = TextDark,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "કોઈપણ UPI એપમાં ખોલો (Pay ₹$amount)",
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun QRCanvas(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val matrixSize = 25
        val cellSize = width / matrixSize

        // Background
        drawRect(color = Color.White, size = size)

        fun drawFinder(startX: Float, startY: Float) {
            val finderSize = cellSize * 7
            // Outer black
            drawRoundRect(
                color = Color(0xFF1E1B24),
                topLeft = Offset(startX, startY),
                size = Size(finderSize, finderSize),
                cornerRadius = CornerRadius(cellSize * 1.2f, cellSize * 1.2f)
            )
            // Middle white
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(startX + cellSize, startY + cellSize),
                size = Size(finderSize - (cellSize * 2), finderSize - (cellSize * 2)),
                cornerRadius = CornerRadius(cellSize * 0.8f, cellSize * 0.8f)
            )
            // Inner dark
            drawRoundRect(
                color = Color(0xFF4A148C),
                topLeft = Offset(startX + (cellSize * 2), startY + (cellSize * 2)),
                size = Size(finderSize - (cellSize * 4), finderSize - (cellSize * 4)),
                cornerRadius = CornerRadius(cellSize * 0.5f, cellSize * 0.5f)
            )
        }

        // Three corner finder patterns
        drawFinder(0f, 0f)
        drawFinder(width - (cellSize * 7), 0f)
        drawFinder(0f, height - (cellSize * 7))

        // Deterministic pseudo-random pattern for HD Tuition UPI
        val seed = 8511273911L
        for (row in 0 until matrixSize) {
            for (col in 0 until matrixSize) {
                // Skip finder pattern zones
                val inTopLeft = row < 8 && col < 8
                val inTopRight = row < 8 && col >= matrixSize - 8
                val inBottomLeft = row >= matrixSize - 8 && col < 8
                val inCenterLogo = row in 9..15 && col in 9..15

                if (!inTopLeft && !inTopRight && !inBottomLeft && !inCenterLogo) {
                    val hash = ((row * 37 + col * 19 + seed) % 100).toInt()
                    if (hash < 48) {
                        drawRoundRect(
                            color = if (hash % 3 == 0) Color(0xFF4A148C) else Color(0xFF1A1A1A),
                            topLeft = Offset(col * cellSize + 0.5f, row * cellSize + 0.5f),
                            size = Size(cellSize - 1f, cellSize - 1f),
                            cornerRadius = CornerRadius(cellSize * 0.2f, cellSize * 0.2f)
                        )
                    }
                }
            }
        }
    }
}
