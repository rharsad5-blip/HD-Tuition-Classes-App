package com.example.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.HDTuitionRepository
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val STANDARD_OPTIONS = listOf(
    "All", "Std 1", "Std 2", "Std 3", "Std 4", "Std 5",
    "Std 6", "Std 7", "Std 8", "Std 9", "Std 10", "Std 11", "Std 12"
)

@Composable
fun AdminEmptyStateCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Text(
            text = message,
            fontSize = 13.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
    }
}

// ========================================================
// SECTION 0: OVERVIEW
// ========================================================
@Composable
fun AdminOverviewView(
    students: List<Student>,
    teachers: List<TeacherProfile>,
    admissions: List<AdmissionInquiry>,
    bookings: List<AdvanceBooking>,
    receipts: List<FeeReceipt>,
    onNavigateTo: (Int) -> Unit,
    onRecordFee: () -> Unit,
    onAddStudent: () -> Unit
) {
    val totalCollected = receipts.filter { it.paymentStatus == "SUCCESS" }.sumOf { it.amountPaid }
    val pendingStudents = students.count { it.approvalStatus == ApprovalStatusValues.PENDING }
    val pendingTeachers = teachers.count { it.approvalStatus == ApprovalStatusValues.PENDING }
    val pendingInquiries = admissions.count { it.status == InquiryStatus.PENDING }
    val pendingBookings = bookings.count { it.paymentStatus == BookingPaymentStatus.PENDING_VERIFICATION }
    val pendingReceipts = receipts.count { it.paymentStatus == "PENDING_VERIFICATION" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "એડમિન કંટ્રોલ સેન્ટર ઓવરવ્યૂ",
                fontWeight = FontWeight.Black,
                fontSize = 17.sp,
                color = PurplePrimary
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    modifier = Modifier.weight(1f),
                    title = "વિદ્યાર્થીઓ ($pendingStudents બાકી)",
                    value = "${students.size}",
                    color = PurplePrimary,
                    icon = Icons.Default.People,
                    onClick = { onNavigateTo(1) }
                )
                AdminStatCard(
                    modifier = Modifier.weight(1f),
                    title = "નવા એડમિશન",
                    value = "$pendingInquiries બાકી",
                    color = GoldYellowDark,
                    icon = Icons.Default.AppRegistration,
                    onClick = { onNavigateTo(2) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    modifier = Modifier.weight(1f),
                    title = "સીટ બુકિંગ ₹99",
                    value = "${bookings.size} ($pendingBookings બાકી)",
                    color = PurpleMedium,
                    icon = Icons.Default.ConfirmationNumber,
                    onClick = { onNavigateTo(3) }
                )
                AdminStatCard(
                    modifier = Modifier.weight(1f),
                    title = "ચકાસેલ વસૂલાત",
                    value = "₹$totalCollected",
                    color = StatusSuccess,
                    icon = Icons.Default.CurrencyRupee,
                    onClick = { onNavigateTo(4) }
                )
            }
        }

        if (pendingTeachers > 0 || pendingReceipts > 0) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (pendingTeachers > 0) {
                        AdminStatCard(
                            modifier = Modifier.weight(1f),
                            title = "શિક્ષક મંજૂરી બાકી",
                            value = "$pendingTeachers",
                            color = StatusWarning,
                            icon = Icons.Default.CoPresent,
                            onClick = { onNavigateTo(12) }
                        )
                    }
                    if (pendingReceipts > 0) {
                        AdminStatCard(
                            modifier = Modifier.weight(1f),
                            title = "UPI UTR ચકાસણી બાકી",
                            value = "$pendingReceipts",
                            color = StatusWarning,
                            icon = Icons.Default.VerifiedUser,
                            onClick = { onNavigateTo(5) }
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "ઝડપી ક્રિયાઓ (Quick Actions)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextDark
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onRecordFee,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ફી જમા લો", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAddStudent,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, tint = TextDark, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("નવો વિદ્યાર્થી", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextDark)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "તાજા એડમિશન ફોર્મ્સ", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                        TextButton(onClick = { onNavigateTo(2) }) { Text("બધા જુઓ") }
                    }

                    if (admissions.isEmpty()) {
                        Text(text = "હજુ સુધી કોઈ નવી એડમિશન અરજી નથી.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        admissions.take(3).forEach { inq ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = inq.studentName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(text = "${inq.standard} • મો. ${inq.mobileNumber}", fontSize = 11.sp, color = TextMuted)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (inq.status == InquiryStatus.PENDING) GoldYellowContainer else StatusSuccessContainer
                                ) {
                                    Text(
                                        text = inq.status.name,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (inq.status == InquiryStatus.PENDING) GoldYellowDeep else StatusSuccess,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    color: Color,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("admin_stat_${title.take(4)}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontSize = 11.sp, color = TextMuted)
            Text(text = value, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
        }
    }
}

// ========================================================
// SECTION 1: STUDENTS MANAGEMENT
// ========================================================
@Composable
fun AdminStudentsView(
    students: List<Student>,
    isBusy: Boolean,
    onAddStudent: () -> Unit,
    onApproveStudent: (String) -> Unit,
    onRejectStudent: (String) -> Unit,
    onToggleActive: (String, Boolean) -> Unit,
    onUpdateStudent: (Student) -> Unit,
    onDeleteStudent: (Student) -> Unit,
    onResetPassword: (studentId: String, newPass: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterMode by remember { mutableStateOf("ALL") } // ALL, PENDING, APPROVED
    var studentForPasswordReset by remember { mutableStateOf<Student?>(null) }
    var newPasswordInput by remember { mutableStateOf("") }
    var studentToEdit by remember { mutableStateOf<Student?>(null) }

    val filtered = students.filter { std ->
        val matchesStatus = when (filterMode) {
            "PENDING" -> std.approvalStatus == ApprovalStatusValues.PENDING
            "APPROVED" -> std.approvalStatus == ApprovalStatusValues.APPROVED
            else -> true
        }
        val matchesSearch = searchQuery.isBlank() ||
            std.name.contains(searchQuery, ignoreCase = true) ||
            std.id.contains(searchQuery, ignoreCase = true) ||
            std.standard.contains(searchQuery, ignoreCase = true) ||
            std.mobileNumber.contains(searchQuery, ignoreCase = true)
        matchesStatus && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "વિદ્યાર્થી સંચાલન (${students.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PurplePrimary)
            Button(
                onClick = onAddStudent,
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ઉમેરો", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = filterMode == "ALL",
                onClick = { filterMode = "ALL" },
                label = { Text("બધા (${students.size})", fontSize = 11.sp) }
            )
            val pendingCnt = students.count { it.approvalStatus == ApprovalStatusValues.PENDING }
            FilterChip(
                selected = filterMode == "PENDING",
                onClick = { filterMode = "PENDING" },
                label = { Text("મંજૂરી બાકી ($pendingCnt)", fontSize = 11.sp) }
            )
            FilterChip(
                selected = filterMode == "APPROVED",
                onClick = { filterMode = "APPROVED" },
                label = { Text("મંજૂર", fontSize = 11.sp) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("નામ, આઈડી, મોબાઇલ કે ધોરણથી શોધો...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    AdminEmptyStateCard("કોઈ વિદ્યાર્થી રેકોર્ડ મળ્યો નથી.")
                }
            } else {
                items(filtered, key = { it.id }) { std ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = std.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PurplePrimary)
                                    Text(text = "ID: ${std.id} • ${std.standard} • રોલ: ${std.rollNo}", fontSize = 12.sp, color = TextDark)
                                    Text(text = "મોબાઇલ: ${std.mobileNumber} • વાલી: ${std.parentName}", fontSize = 11.sp, color = TextMuted)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = when (std.approvalStatus) {
                                                ApprovalStatusValues.APPROVED -> StatusSuccessContainer
                                                ApprovalStatusValues.REJECTED -> StatusErrorContainer
                                                else -> GoldYellowContainer
                                            }
                                        ) {
                                            Text(
                                                text = std.approvalStatus,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (std.approvalStatus) {
                                                    ApprovalStatusValues.APPROVED -> StatusSuccess
                                                    ApprovalStatusValues.REJECTED -> StatusError
                                                    else -> GoldYellowDeep
                                                },
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Text(
                                            text = if (std.isActive) "Active ✓" else "Deactivated",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (std.isActive) StatusSuccess else StatusError
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = std.isActive,
                                        onCheckedChange = { onToggleActive(std.id, it) }
                                    )
                                    IconButton(onClick = { studentToEdit = std }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Student", tint = PurplePrimary)
                                    }
                                    IconButton(onClick = {
                                        studentForPasswordReset = std
                                        newPasswordInput = ""
                                    }) {
                                        Icon(Icons.Default.LockReset, contentDescription = "Reset Student Password", tint = PurplePrimary)
                                    }
                                    IconButton(onClick = { onDeleteStudent(std) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Student", tint = StatusError)
                                    }
                                }
                            }

                            if (std.approvalStatus == ApprovalStatusValues.PENDING) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { onApproveStudent(std.id) },
                                        enabled = !isBusy,
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("મંજૂર કરો (Approve)", fontSize = 11.sp)
                                    }
                                    OutlinedButton(
                                        onClick = { onRejectStudent(std.id) },
                                        enabled = !isBusy,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("અસ્વીકાર", fontSize = 11.sp, color = StatusError)
                                    }
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = BorderSubtle)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "કુલ ફી: ₹${std.effectiveTotalFees}", fontSize = 11.sp, color = TextMuted)
                                Text(text = "ભરેલ: ₹${std.paidFees}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusSuccess)
                                Text(
                                    text = "બાકી: ₹${std.remainingFees}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (std.remainingFees > 0) StatusWarning else StatusSuccess
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (studentForPasswordReset != null) {
        val target = studentForPasswordReset!!
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { studentForPasswordReset = null },
            title = { Text("વિદ્યાર્થી પાસવર્ડ બદલો") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "વિદ્યાર્થી: ${target.name} (ID: ${target.id})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "મોબાઇલ: ${target.mobileNumber}", fontSize = 12.sp, color = TextMuted)
                    OutlinedTextField(
                        value = newPasswordInput,
                        onValueChange = { newPasswordInput = it },
                        label = { Text("નવો પાસવર્ડ (ઓછામાં ઓછા ૪ અક્ષર)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPasswordInput.trim().length < 4) {
                            Toast.makeText(context, "ઓછામાં ઓછા ૪ અક્ષરનો પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onResetPassword(target.id, newPasswordInput.trim())
                        studentForPasswordReset = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("સેવ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { studentForPasswordReset = null }) {
                    Text("રદ કરો")
                }
            }
        )
    }

    if (studentToEdit != null) {
        val target = studentToEdit!!
        var name by remember(target.id) { mutableStateOf(target.name) }
        var parent by remember(target.id) { mutableStateOf(target.parentName) }
        var standard by remember(target.id) { mutableStateOf(target.standard) }
        var totalFeesStr by remember(target.id) { mutableStateOf(target.totalFees.toString()) }
        var school by remember(target.id) { mutableStateOf(target.school) }
        var address by remember(target.id) { mutableStateOf(target.address) }

        AlertDialog(
            onDismissRequest = { studentToEdit = null },
            title = { Text("વિદ્યાર્થી વિગત સુધારો (${target.id})") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("નામ") }, singleLine = true)
                    OutlinedTextField(value = parent, onValueChange = { parent = it }, label = { Text("વાલીનું નામ") }, singleLine = true)
                    OutlinedTextField(value = standard, onValueChange = { standard = it }, label = { Text("ધોરણ") }, singleLine = true)
                    OutlinedTextField(
                        value = totalFeesStr,
                        onValueChange = { totalFeesStr = it },
                        label = { Text("કુલ વાર્ષિક ફી ₹") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(value = school, onValueChange = { school = it }, label = { Text("શાળા") }, singleLine = true)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("સરનામું") }, maxLines = 2)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.trim().length < 2 || parent.isBlank()) return@Button
                        val updated = target.copy(
                            name = name.trim(),
                            parentName = parent.trim(),
                            standard = standard.trim(),
                            totalFees = totalFeesStr.toIntOrNull()?.coerceAtLeast(0) ?: target.totalFees,
                            school = school.trim(),
                            address = address.trim()
                        )
                        onUpdateStudent(updated)
                        studentToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("અપડેટ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToEdit = null }) { Text("રદ કરો") }
            }
        )
    }
}

// ========================================================
// SECTION 2: ADMISSION MANAGEMENT
// ========================================================
@Composable
fun AdminAdmissionsView(
    admissions: List<AdmissionInquiry>,
    isBusy: Boolean,
    onApprove: (String) -> Unit,
    onReject: (String) -> Unit,
    onConvertToStudent: (inquiryId: String, initialPassword: String) -> Unit
) {
    val context = LocalContext.current
    var convertingInquiry by remember { mutableStateOf<AdmissionInquiry?>(null) }
    var initialPassword by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "પ્રવેશ ફોર્મ સંચાલન (${admissions.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
        }

        if (admissions.isEmpty()) {
            item { AdminEmptyStateCard("હજુ સુધી કોઈ એડમિશન ફોર્મ આવેલ નથી.") }
        } else {
            items(admissions, key = { it.id }) { inq ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = inq.studentName, fontWeight = FontWeight.Black, fontSize = 15.sp, color = PurplePrimary)
                                Text(text = "ID: ${inq.id} • ${inq.standard}", fontSize = 12.sp, color = TextDark)
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (inq.status) {
                                    InquiryStatus.PENDING -> GoldYellowContainer
                                    InquiryStatus.APPROVED -> StatusSuccessContainer
                                    InquiryStatus.REJECTED -> StatusErrorContainer
                                }
                            ) {
                                Text(
                                    text = when (inq.status) {
                                        InquiryStatus.PENDING -> "પેન્ડિંગ"
                                        InquiryStatus.APPROVED -> "મંજૂર (Approved)"
                                        InquiryStatus.REJECTED -> "અસ્વીકાર"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = when (inq.status) {
                                        InquiryStatus.PENDING -> GoldYellowDeep
                                        InquiryStatus.APPROVED -> StatusSuccess
                                        InquiryStatus.REJECTED -> StatusError
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(text = "વાલી: ${inq.parentName} • મો: ${inq.mobileNumber}", fontSize = 12.sp, color = TextDark)
                        Text(text = "સરનામું: ${inq.address}", fontSize = 11.sp, color = TextMuted)
                        Text(text = "શાળા: ${inq.previousSchool} • જન્મ: ${inq.dateOfBirth}", fontSize = 11.sp, color = TextMuted)
                        if (inq.notes.isNotBlank()) {
                            Text(text = "નોંધ: ${inq.notes}", fontSize = 11.sp, color = PurpleMedium)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (inq.status == InquiryStatus.PENDING) {
                                Button(
                                    onClick = { onApprove(inq.id) },
                                    enabled = !isBusy,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("મંજૂર કરો", fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { onReject(inq.id) },
                                    enabled = !isBusy,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("અસ્વીકાર", fontSize = 11.sp, color = StatusError)
                                }
                            }

                            Button(
                                onClick = {
                                    convertingInquiry = inq
                                    initialPassword = ""
                                },
                                enabled = !isBusy,
                                modifier = Modifier.weight(1.3f),
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Student ID બનાવો", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (convertingInquiry != null) {
        val target = convertingInquiry!!
        AlertDialog(
            onDismissRequest = { convertingInquiry = null },
            title = { Text("Student ID & પાસવર્ડ બનાવો") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "વિદ્યાર્થી: ${target.studentName} (${target.standard})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "વાર્ષિક ફી: ₹${HDTuitionRepository.standardAnnualFee(target.standard)}", fontSize = 12.sp, color = StatusSuccess)
                    OutlinedTextField(
                        value = initialPassword,
                        onValueChange = { initialPassword = it },
                        label = { Text("પ્રારંભિક પાસવર્ડ (ઓછામાં ઓછા ૪ અક્ષર) *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (initialPassword.trim().length < 4) {
                            Toast.makeText(context, "ઓછામાં ઓછા ૪ અક્ષરનો પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onConvertToStudent(target.id, initialPassword.trim())
                        convertingInquiry = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("બનાવો")
                }
            },
            dismissButton = {
                TextButton(onClick = { convertingInquiry = null }) { Text("રદ કરો") }
            }
        )
    }
}

// ========================================================
// SECTION 3: ADVANCE BOOKING MANAGEMENT
// ========================================================
@Composable
fun AdminBookingsView(
    bookings: List<AdvanceBooking>,
    isBusy: Boolean,
    onConfirm: (String) -> Unit,
    onReject: (String) -> Unit,
    onAddRemainingFees: (bookingId: String, remainingAmount: Int, initialPassword: String) -> Unit
) {
    val context = LocalContext.current
    var selectedBookingForFees by remember { mutableStateOf<AdvanceBooking?>(null) }
    var remainingFeeInput by remember { mutableStateOf("") }
    var studentInitPassword by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "એડવાન્સ સીટ બુકિંગ મેનેજમેન્ટ (${bookings.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
        }

        if (bookings.isEmpty()) {
            item { AdminEmptyStateCard("હજુ સુધી કોઈ એડવાન્સ સીટ બુકિંગ આવેલ નથી.") }
        } else {
            items(bookings, key = { it.id }) { bk ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = bk.studentName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PurplePrimary)
                                Text(text = "બુકિંગ ID: ${bk.id} • ${bk.standard}", fontSize = 12.sp, color = TextDark)
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (bk.paymentStatus) {
                                    BookingPaymentStatus.PENDING_VERIFICATION -> GoldYellowContainer
                                    BookingPaymentStatus.CONFIRMED -> StatusSuccessContainer
                                    BookingPaymentStatus.REJECTED -> StatusErrorContainer
                                }
                            ) {
                                Text(
                                    text = when (bk.paymentStatus) {
                                        BookingPaymentStatus.PENDING_VERIFICATION -> "ચકાસણી બાકી"
                                        BookingPaymentStatus.CONFIRMED -> "વેરિફાઇડ ✓"
                                        BookingPaymentStatus.REJECTED -> "રદ"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = when (bk.paymentStatus) {
                                        BookingPaymentStatus.PENDING_VERIFICATION -> GoldYellowDeep
                                        BookingPaymentStatus.CONFIRMED -> StatusSuccess
                                        BookingPaymentStatus.REJECTED -> StatusError
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(text = "રકમ: ₹${bk.amount} • તારીખ: ${bk.bookingDate}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextDark)
                        Text(text = "વિદ્યાર્થી: ${bk.studentName} • મો: ${bk.mobileNumber}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
                        Text(text = "વાલી: ${bk.parentName} • WhatsApp: ${bk.whatsappNumber}", fontSize = 12.sp, color = TextDark)
                        Text(text = "UPI Ref / UTR: ${bk.upiTransactionId}", fontSize = 11.sp, color = PurpleMedium)

                        if (bk.hasScreenshot) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = BackgroundLight,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                            ) {
                                Text(
                                    text = "✓ પેમેન્ટ વિગત જોડાયેલ છે",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusSuccess,
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onConfirm(bk.id) },
                                enabled = !isBusy,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("YES (મંજૂર)", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { onReject(bk.id) },
                                enabled = !isBusy,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusError)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("NO (રદ)", fontSize = 12.sp, color = StatusError)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = {
                                selectedBookingForFees = bk
                                val annual = HDTuitionRepository.standardAnnualFee(bk.standard)
                                remainingFeeInput = (annual - bk.amount).coerceAtLeast(0).toString()
                                studentInitPassword = ""
                            },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp), tint = GoldYellow)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("બાકી ફી ઉમેરો & વિદ્યાર્થી બનાવો", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (selectedBookingForFees != null) {
        val bk = selectedBookingForFees!!
        AlertDialog(
            onDismissRequest = { selectedBookingForFees = null },
            title = {
                Text(
                    text = "બાકી ફી ઉમેરો: ${bk.studentName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = PurplePrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "ધોરણ: ${bk.standard}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "એડવાન્સ જમા: ₹${bk.amount} (બાદ થશે)", fontSize = 12.sp, color = StatusSuccess)
                    OutlinedTextField(
                        value = remainingFeeInput,
                        onValueChange = { remainingFeeInput = it },
                        label = { Text("બાકી ફી રકમ (Remaining Fee) ₹") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = studentInitPassword,
                        onValueChange = { studentInitPassword = it },
                        label = { Text("વિદ્યાર્થીનો પ્રારંભિક પાસવર્ડ *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = remainingFeeInput.toIntOrNull() ?: -1
                        if (amt < 0 || studentInitPassword.trim().length < 4) {
                            Toast.makeText(context, "સાચી રકમ અને ૪+ અક્ષરનો પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onAddRemainingFees(bk.id, amt, studentInitPassword.trim())
                        selectedBookingForFees = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("કન્વર્ટ & સેવ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedBookingForFees = null }) {
                    Text("રદ")
                }
            }
        )
    }
}

// ========================================================
// SECTION 12: TEACHER MANAGEMENT
// ========================================================
@Composable
fun AdminTeachersView(
    teachers: List<TeacherProfile>,
    isBusy: Boolean,
    onAddTeacher: (name: String, mobile: String, subjects: String, qualification: String, experience: String, password: String, standards: List<String>) -> Unit,
    onApproveTeacher: (teacherDocId: String, assignedStandards: List<String>) -> Unit,
    onRejectTeacher: (teacherDocId: String) -> Unit,
    onToggleTeacherActive: (TeacherProfile, Boolean) -> Unit,
    onUpdateTeacher: (TeacherProfile) -> Unit,
    onDeleteTeacher: (TeacherProfile) -> Unit,
    onResetPassword: (String, String) -> Unit
) {
    val context = LocalContext.current
    var filterMode by remember { mutableStateOf("ALL") }
    var showAddTeacherDialog by remember { mutableStateOf(false) }
    var teacherToApprove by remember { mutableStateOf<TeacherProfile?>(null) }
    var teacherToEdit by remember { mutableStateOf<TeacherProfile?>(null) }
    var teacherForPasswordReset by remember { mutableStateOf<TeacherProfile?>(null) }
    var newPasswordInput by remember { mutableStateOf("") }

    val filtered = teachers.filter { t ->
        when (filterMode) {
            "PENDING" -> t.approvalStatus == ApprovalStatusValues.PENDING
            "APPROVED" -> t.approvalStatus == ApprovalStatusValues.APPROVED
            else -> true
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "શિક્ષક સ્ટાફ વિગતો (${teachers.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = PurplePrimary
                )
                Button(
                    onClick = { showAddTeacherDialog = true },
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("શિક્ષક ઉમેરો", fontSize = 12.sp)
                }
            }
        }

        item {
            val pendingCount = teachers.count { it.approvalStatus == ApprovalStatusValues.PENDING }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = filterMode == "ALL",
                    onClick = { filterMode = "ALL" },
                    label = { Text("બધા (${teachers.size})", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = filterMode == "PENDING",
                    onClick = { filterMode = "PENDING" },
                    label = { Text("મંજૂરી બાકી ($pendingCount)", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = filterMode == "APPROVED",
                    onClick = { filterMode = "APPROVED" },
                    label = { Text("મંજૂર", fontSize = 11.sp) }
                )
            }
        }

        if (filtered.isEmpty()) {
            item { AdminEmptyStateCard("હજુ સુધી કોઈ શિક્ષક રજીસ્ટર થયેલ નથી.") }
        } else {
            items(filtered, key = { it.id }) { t ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = t.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                                Text(text = "ID: ${t.teacherId} • ${t.role}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
                                Text(text = "${t.qualification} • ${t.experience}", fontSize = 11.sp, color = TextMuted)
                                Text(text = "વિષયો: ${t.subjects}", fontSize = 11.sp, color = TextDark)
                                Text(
                                    text = "ધોરણો: ${t.assignedStandards.ifEmpty { listOf("All") }.joinToString(", ")}",
                                    fontSize = 11.sp,
                                    color = PurpleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(text = "સંપર્ક: ${t.contact}", fontSize = 11.sp, color = TextMuted)
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (t.approvalStatus) {
                                        ApprovalStatusValues.APPROVED -> StatusSuccessContainer
                                        ApprovalStatusValues.REJECTED -> StatusErrorContainer
                                        else -> GoldYellowContainer
                                    }
                                ) {
                                    Text(
                                        text = "${t.approvalStatus} • ${if (t.isActive) "Active" else "Inactive"}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (t.approvalStatus) {
                                            ApprovalStatusValues.APPROVED -> StatusSuccess
                                            ApprovalStatusValues.REJECTED -> StatusError
                                            else -> GoldYellowDeep
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(
                                    checked = t.isActive,
                                    onCheckedChange = { onToggleTeacherActive(t, it) }
                                )
                                IconButton(onClick = { teacherToEdit = t }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit Teacher", tint = PurplePrimary)
                                }
                                IconButton(onClick = {
                                    teacherForPasswordReset = t
                                    newPasswordInput = ""
                                }) {
                                    Icon(Icons.Default.LockReset, contentDescription = "Reset Teacher Password", tint = PurplePrimary)
                                }
                                IconButton(onClick = { onDeleteTeacher(t) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Teacher", tint = StatusError)
                                }
                            }
                        }

                        if (t.approvalStatus == ApprovalStatusValues.PENDING) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { teacherToApprove = t },
                                    enabled = !isBusy,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("મંજૂર & ધોરણ સોંપો", fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { onRejectTeacher(t.id) },
                                    enabled = !isBusy,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("અસ્વીકાર", fontSize = 11.sp, color = StatusError)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddTeacherDialog) {
        var name by remember { mutableStateOf("") }
        var mobile by remember { mutableStateOf("") }
        var qualification by remember { mutableStateOf("M.Sc., B.Ed.") }
        var experience by remember { mutableStateOf("5+ વર્ષનો અનુભવ") }
        var subjects by remember { mutableStateOf("ગણિત, વિજ્ઞાન") }
        var password by remember { mutableStateOf("") }
        val selectedStds = remember { mutableStateListOf("All") }

        AlertDialog(
            onDismissRequest = { showAddTeacherDialog = false },
            title = { Text("નવા શિક્ષક ઉમેરો") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("શિક્ષકનું નામ *") }, singleLine = true)
                    OutlinedTextField(
                        value = mobile,
                        onValueChange = { if (it.length <= 10) mobile = it.filter(Char::isDigit) },
                        label = { Text("૧૦ અંકનો મોબાઇલ નંબર *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("શિક્ષકનો પાસવર્ડ (૪+ અક્ષર) *") }, singleLine = true)
                    OutlinedTextField(value = subjects, onValueChange = { subjects = it }, label = { Text("વિષયો *") }, singleLine = true)
                    OutlinedTextField(value = qualification, onValueChange = { qualification = it }, label = { Text("લાયકાત") }, singleLine = true)
                    OutlinedTextField(value = experience, onValueChange = { experience = it }, label = { Text("અનુભવ") }, singleLine = true)

                    Text("સોંપેલા ધોરણો:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        STANDARD_OPTIONS.forEach { std ->
                            val isSel = selectedStds.contains(std)
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    if (std == "All") {
                                        selectedStds.clear()
                                        selectedStds.add("All")
                                    } else {
                                        selectedStds.remove("All")
                                        if (isSel) selectedStds.remove(std) else selectedStds.add(std)
                                        if (selectedStds.isEmpty()) selectedStds.add("All")
                                    }
                                },
                                label = { Text(std, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.trim().length < 2 || mobile.length < 10 || password.trim().length < 4 || subjects.isBlank()) {
                            Toast.makeText(context, "નામ, ૧૦ અંકનો મોબાઇલ, વિષય અને ૪+ અક્ષરનો પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onAddTeacher(
                            name.trim(),
                            mobile,
                            subjects.trim(),
                            qualification.trim(),
                            experience.trim(),
                            password.trim(),
                            selectedStds.toList()
                        )
                        showAddTeacherDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("ઉમેરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTeacherDialog = false }) { Text("રદ કરો") }
            }
        )
    }

    if (teacherToApprove != null) {
        val t = teacherToApprove!!
        val selectedStds = remember(t.id) {
            mutableStateListOf<String>().apply {
                addAll(t.assignedStandards.ifEmpty { listOf("All") })
            }
        }
        AlertDialog(
            onDismissRequest = { teacherToApprove = null },
            title = { Text("શિક્ષક મંજૂર કરો (${t.name})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("આ શિક્ષક કયા ધોરણો મેનેજ કરશે તે પસંદ કરો:", fontSize = 12.sp, color = TextDark)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        STANDARD_OPTIONS.forEach { std ->
                            val isSel = selectedStds.contains(std)
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    if (std == "All") {
                                        selectedStds.clear()
                                        selectedStds.add("All")
                                    } else {
                                        selectedStds.remove("All")
                                        if (isSel) selectedStds.remove(std) else selectedStds.add(std)
                                        if (selectedStds.isEmpty()) selectedStds.add("All")
                                    }
                                },
                                label = { Text(std, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onApproveTeacher(t.id, selectedStds.toList())
                        teacherToApprove = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess)
                ) {
                    Text("મંજૂર કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { teacherToApprove = null }) { Text("રદ કરો") }
            }
        )
    }

    if (teacherToEdit != null) {
        val t = teacherToEdit!!
        var name by remember(t.id) { mutableStateOf(t.name) }
        var role by remember(t.id) { mutableStateOf(t.role) }
        var subjects by remember(t.id) { mutableStateOf(t.subjects) }
        var qualification by remember(t.id) { mutableStateOf(t.qualification) }
        var experience by remember(t.id) { mutableStateOf(t.experience) }
        val selectedStds = remember(t.id) {
            mutableStateListOf<String>().apply {
                addAll(t.assignedStandards.ifEmpty { listOf("All") })
            }
        }

        AlertDialog(
            onDismissRequest = { teacherToEdit = null },
            title = { Text("શિક્ષક વિગત સુધારો (${t.teacherId})") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("નામ") }, singleLine = true)
                    OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("હોદ્દો") }, singleLine = true)
                    OutlinedTextField(value = subjects, onValueChange = { subjects = it }, label = { Text("વિષયો") }, singleLine = true)
                    OutlinedTextField(value = qualification, onValueChange = { qualification = it }, label = { Text("લાયકાત") }, singleLine = true)
                    OutlinedTextField(value = experience, onValueChange = { experience = it }, label = { Text("અનુભવ") }, singleLine = true)
                    Text("સોંપેલા ધોરણો:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        STANDARD_OPTIONS.forEach { std ->
                            val isSel = selectedStds.contains(std)
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    if (std == "All") {
                                        selectedStds.clear()
                                        selectedStds.add("All")
                                    } else {
                                        selectedStds.remove("All")
                                        if (isSel) selectedStds.remove(std) else selectedStds.add(std)
                                        if (selectedStds.isEmpty()) selectedStds.add("All")
                                    }
                                },
                                label = { Text(std, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.trim().length < 2 || subjects.isBlank()) return@Button
                        onUpdateTeacher(
                            t.copy(
                                name = name.trim(),
                                role = role.trim().ifBlank { "Faculty" },
                                subjects = subjects.trim(),
                                qualification = qualification.trim(),
                                experience = experience.trim(),
                                assignedStandards = selectedStds.toList()
                            )
                        )
                        teacherToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("અપડેટ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { teacherToEdit = null }) { Text("રદ કરો") }
            }
        )
    }

    if (teacherForPasswordReset != null) {
        val target = teacherForPasswordReset!!
        AlertDialog(
            onDismissRequest = { teacherForPasswordReset = null },
            title = { Text("શિક્ષક પાસવર્ડ બદલો") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "શિક્ષક: ${target.name} (ID: ${target.teacherId})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    OutlinedTextField(
                        value = newPasswordInput,
                        onValueChange = { newPasswordInput = it },
                        label = { Text("નવો પાસવર્ડ (૪+ અક્ષર)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPasswordInput.trim().length < 4) {
                            Toast.makeText(context, "ઓછામાં ઓછા ૪ અક્ષરનો પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onResetPassword(target.id, newPasswordInput.trim())
                        teacherForPasswordReset = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("સેવ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { teacherForPasswordReset = null }) { Text("રદ કરો") }
            }
        )
    }
}
