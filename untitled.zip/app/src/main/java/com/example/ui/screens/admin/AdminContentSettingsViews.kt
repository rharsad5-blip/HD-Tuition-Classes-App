package com.example.ui.screens.admin

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.HDTuitionRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ========================================================
// SECTION 9: TIMETABLE MANAGEMENT
// ========================================================
@Composable
fun AdminTimetableView(
    repository: HDTuitionRepository
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val timetable by repository.timetable.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "સમયપત્રક સંચાલન (${timetable.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("નવો સ્લોટ", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (timetable.isEmpty()) {
                item { AdminEmptyStateCard("હજુ સુધી કોઈ સમયપત્રક ઉમેરાયેલ નથી.") }
            } else {
                items(timetable, key = { it.id }) { slot ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "${slot.standard} • ${slot.dayOfWeek}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                                Text(text = "${slot.subject} (${slot.teacherName})", fontSize = 12.sp, color = TextDark)
                                Text(text = "${slot.timeSlot} • ${slot.room}", fontSize = 11.sp, color = TextMuted)
                            }
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        repository.deleteTimetableSlot(slot.id)
                                            .onFailure { err ->
                                                Toast.makeText(context, err.localizedMessage ?: "Delete failed", Toast.LENGTH_SHORT).show()
                                            }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusError)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var standard by remember { mutableStateOf("Std 10") }
        var dayOfWeek by remember { mutableStateOf("સોમવાર (Monday)") }
        var timeSlot by remember { mutableStateOf("04:00 PM - 05:30 PM") }
        var subject by remember { mutableStateOf("ગણિત (Mathematics)") }
        var teacherName by remember { mutableStateOf("હર્ષદસિંહ રાઠોડ") }
        var room by remember { mutableStateOf("Room 1") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("નવું સમયપત્રક ઉમેરો") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = standard, onValueChange = { standard = it }, label = { Text("ધોરણ *") }, singleLine = true)
                    OutlinedTextField(value = dayOfWeek, onValueChange = { dayOfWeek = it }, label = { Text("વાર (Day) *") }, singleLine = true)
                    OutlinedTextField(value = timeSlot, onValueChange = { timeSlot = it }, label = { Text("સમય (Time Slot) *") }, singleLine = true)
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("વિષય *") }, singleLine = true)
                    OutlinedTextField(value = teacherName, onValueChange = { teacherName = it }, label = { Text("શિક્ષકનું નામ *") }, singleLine = true)
                    OutlinedTextField(value = room, onValueChange = { room = it }, label = { Text("રૂમ / બેચ") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (standard.trim().length < 2 || dayOfWeek.trim().length < 2 ||
                            timeSlot.trim().length < 2 || subject.trim().length < 2 || teacherName.isBlank()
                        ) {
                            Toast.makeText(context, "તમામ જરૂરી વિગતો ભરો", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        coroutineScope.launch {
                            val res = repository.addTimetableSlot(
                                TimetableSlot(
                                    standard = standard.trim(),
                                    dayOfWeek = dayOfWeek.trim(),
                                    timeSlot = timeSlot.trim(),
                                    subject = subject.trim(),
                                    teacherName = teacherName.trim(),
                                    room = room.trim().ifBlank { "Room 1" }
                                )
                            )
                            res.onSuccess {
                                showAddDialog = false
                                Toast.makeText(context, "સમયપત્રક ઉમેરાયું!", Toast.LENGTH_SHORT).show()
                            }.onFailure { err ->
                                Toast.makeText(context, err.localizedMessage ?: "Failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("સેવ કરો")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("રદ કરો") }
            }
        )
    }
}

// ========================================================
// SECTION 11: ANNOUNCEMENTS MANAGEMENT
// ========================================================
@Composable
fun AdminAnnouncementsView(
    announcements: List<AnnouncementItem>,
    onAdd: () -> Unit,
    onDelete: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "જાહેરાતો અને નોટિફિકેશન (${announcements.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PurplePrimary)
            Button(
                onClick = onAdd,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("નવી જાહેરાત", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (announcements.isEmpty()) {
                item { AdminEmptyStateCard("હજુ સુધી કોઈ જાહેરાત પ્રસિદ્ધ થયેલ નથી.") }
            } else {
                items(announcements, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary, modifier = Modifier.weight(1f))
                                IconButton(onClick = { onDelete(item.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusError)
                                }
                            }
                            Text(text = item.content, fontSize = 12.sp, color = TextDark)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "તારીખ: ${item.date} • ધોરણ: ${item.targetStandard}", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// SECTION 13: REPORTS & ACCOUNTING
// ========================================================
@Composable
fun AdminReportsView(
    students: List<Student>,
    receipts: List<FeeReceipt>
) {
    val context = LocalContext.current
    val verifiedReceipts = remember(receipts) { receipts.filter { it.paymentStatus == "SUCCESS" } }
    val totalRevenueExpected = students.sumOf { it.effectiveTotalFees }
    val totalRevenueCollected = verifiedReceipts.sumOf { it.amountPaid }
    val totalRemainingDues = students.sumOf { it.remainingFees }
    val collectionRate = if (totalRevenueExpected > 0) {
        (totalRevenueCollected.toFloat() / totalRevenueExpected.toFloat()) * 100f
    } else 0f

    val standardCounts = students.groupBy { it.standard }.mapValues { it.value.size }
    val todayStr = remember { SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date()) }
    val todayCollection = verifiedReceipts.filter { it.paymentDate == todayStr }.sumOf { it.amountPaid }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "હિસાબી રિપોર્ટ અને નાણાકીય વિશ્લેષણ",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PurpleContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "કુલ વાર્ષિક અપેક્ષિત આવક", fontSize = 12.sp, color = TextMuted)
                    Text(text = "₹$totalRevenueExpected", fontWeight = FontWeight.Black, fontSize = 24.sp, color = PurplePrimary)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "ચકાસેલ જમા (Collected):", fontSize = 11.sp, color = TextMuted)
                            Text(text = "₹$totalRevenueCollected", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = StatusSuccess)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "બાકી લેણી રકમ (Pending):", fontSize = 11.sp, color = TextMuted)
                            Text(text = "₹$totalRemainingDues", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = StatusWarning)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "વસૂલાત ટકાવારી: %.1f%%".format(collectionRate), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "આવક વિશ્લેષણ (Income Breakdown)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "આજની આવક", fontSize = 11.sp, color = TextMuted)
                            Text(text = "₹$todayCollection", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = StatusSuccess)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "કુલ પાવતી", fontSize = 11.sp, color = TextMuted)
                            Text(text = "${verifiedReceipts.size}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "વાર્ષિક અપેક્ષિત", fontSize = 11.sp, color = TextMuted)
                            Text(text = "₹$totalRevenueExpected", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextDark)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "ધોરણ વાઇઝ વિદ્યાર્થીઓ", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PurplePrimary)
                        Text(text = "કુલ વિદ્યાર્થીઓ: ${students.size}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = StatusSuccess)
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    if (standardCounts.isEmpty()) {
                        Text(text = "કોઈ વિદ્યાર્થી ડેટા નથી.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        standardCounts.forEach { (std, count) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = std, fontSize = 12.sp, color = TextDark)
                                Text(text = "$count વિદ્યાર્થી", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PurplePrimary)
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = GoldYellowContainer)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "રિપોર્ટ નિકાસ કરો (Export Reports)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextDark
                    )
                    Text(
                        text = "તમામ વિદ્યાર્થીઓ, ફી અને ચુકવણીનો સંપૂર્ણ રિપોર્ટ Excel (CSV) અથવા Text તરીકે શેર કરો.",
                        fontSize = 11.sp,
                        color = TextDark.copy(alpha = 0.8f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val csvHeader = "Student ID,Student Name,Parent Name,Mobile,Standard,Total Fees,Paid Fees,Pending Fees,Status\n"
                                val csvRows = students.joinToString("\n") { s ->
                                    "${s.id},\"${s.name}\",\"${s.parentName}\",${s.mobileNumber},\"${s.standard}\",${s.effectiveTotalFees},${s.paidFees},${s.remainingFees},${s.feeStatus}"
                                }
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_SUBJECT, "HD Tuition Classes - Student & Fees Report (CSV)")
                                    putExtra(Intent.EXTRA_TEXT, csvHeader + csvRows)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "CSV રિપોર્ટ શેર કરો"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_excel_csv_btn")
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = GoldYellow)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Excel (CSV)", fontSize = 12.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                val reportText = buildString {
                                    appendLine("==========================================")
                                    appendLine("     HD TUITION CLASSES - OFFICIAL REPORT  ")
                                    appendLine("==========================================")
                                    appendLine("તારીખ: $todayStr")
                                    appendLine("કુલ વિદ્યાર્થીઓ: ${students.size}")
                                    appendLine("કુલ અપેક્ષિત વાર્ષિક આવક: ₹$totalRevenueExpected")
                                    appendLine("જમા થયેલ રકમ: ₹$totalRevenueCollected")
                                    appendLine("બાકી રહેતી રકમ: ₹$totalRemainingDues")
                                    appendLine("વસૂલાત ટકાવારી: %.1f%%".format(collectionRate))
                                    appendLine("------------------------------------------")
                                    students.forEachIndexed { i, s ->
                                        appendLine("${i + 1}. [${s.id}] ${s.name} - ${s.standard}")
                                        appendLine("   મો: ${s.mobileNumber} | ભરેલ: ₹${s.paidFees} | બાકી: ₹${s.remainingFees} (${s.feeStatus})")
                                    }
                                    appendLine("==========================================")
                                }
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_SUBJECT, "HD Tuition Classes - Financial & Student Report")
                                    putExtra(Intent.EXTRA_TEXT, reportText)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "રિપોર્ટ શેર કરો"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_pdf_report_btn")
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = TextDark)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Summary Report", fontSize = 12.sp, color = TextDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// SECTION 14: WEBSITE / APP SETTINGS & ADMIN SECURITY
// ========================================================
@Composable
fun AdminSettingsView(
    settings: TuitionSettings,
    adminAccount: AdminAccount?,
    isBusy: Boolean,
    onSaveSettings: (TuitionSettings) -> Unit,
    onUpdateAdminCredentials: (String, String) -> Unit
) {
    val context = LocalContext.current
    var businessName by remember { mutableStateOf(settings.businessName) }
    var founderName by remember { mutableStateOf(settings.founderName) }
    var contactPhone by remember { mutableStateOf(settings.contactPhone) }
    var tickerText by remember { mutableStateOf(settings.tickerText) }
    var upiId by remember { mutableStateOf(settings.upiId) }
    var upiPayeeName by remember { mutableStateOf(settings.upiPayeeName) }
    var bookingAmountStr by remember { mutableStateOf(settings.advanceBookingAmount.toString()) }
    var admissionOpen by remember { mutableStateOf(settings.admissionOpen) }
    var address by remember { mutableStateOf(settings.address) }

    LaunchedEffect(settings) {
        businessName = settings.businessName
        founderName = settings.founderName
        contactPhone = settings.contactPhone
        tickerText = settings.tickerText
        upiId = settings.upiId
        upiPayeeName = settings.upiPayeeName
        bookingAmountStr = settings.advanceBookingAmount.toString()
        admissionOpen = settings.admissionOpen
        address = settings.address
    }

    var newAdminId by remember { mutableStateOf(adminAccount?.adminId ?: "admin") }
    LaunchedEffect(adminAccount) {
        if (adminAccount != null && adminAccount.adminId.isNotBlank()) {
            newAdminId = adminAccount.adminId
        }
    }
    var newAdminPassword by remember { mutableStateOf("") }
    var newAdminConfirmPassword by remember { mutableStateOf("") }
    var adminPasswordVisible by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PurpleContainer),
                border = ButtonDefaults.outlinedButtonBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = PurplePrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "એડમિન આઈડી અને પાસવર્ડ બદલો (Admin Security)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = PurplePrimary
                        )
                    }
                    Text(
                        text = "અહીંથી સંચાલક તરીકે તમે તમારો Admin ID અને લૉગિન Password ગમે ત્યારે બદલી શકો છો.",
                        fontSize = 11.sp,
                        color = TextDark
                    )

                    OutlinedTextField(
                        value = newAdminId,
                        onValueChange = { newAdminId = it },
                        label = { Text("નવો Admin ID / Mobile") },
                        leadingIcon = { Icon(Icons.Default.AccountCircle, contentDescription = null, tint = PurplePrimary) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newAdminPassword,
                        onValueChange = { newAdminPassword = it },
                        label = { Text("નવો પાસવર્ડ (New Password)") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                        trailingIcon = {
                            IconButton(onClick = { adminPasswordVisible = !adminPasswordVisible }) {
                                Icon(if (adminPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                            }
                        },
                        visualTransformation = if (adminPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newAdminConfirmPassword,
                        onValueChange = { newAdminConfirmPassword = it },
                        label = { Text("નવો પાસવર્ડ કન્ફર્મ કરો") },
                        leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null, tint = PurplePrimary) },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            if (newAdminId.trim().length < 2) {
                                Toast.makeText(context, "માન્ય Admin ID લખો", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (newAdminPassword.isNotBlank()) {
                                if (newAdminPassword != newAdminConfirmPassword) {
                                    Toast.makeText(context, "પાસવર્ડ મેળ ખાતા નથી!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (newAdminPassword.trim().length < 4) {
                                    Toast.makeText(context, "પાસવર્ડ ઓછામાં ઓછો ૪ અક્ષરનો રાખો", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                            }
                            onUpdateAdminCredentials(newAdminId.trim(), newAdminPassword.trim())
                            newAdminPassword = ""
                            newAdminConfirmPassword = ""
                        },
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("એડમિન આઈડી & પાસવર્ડ સેવ કરો", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(
                text = "વેબસાઇટ અને એપ્લિકેશન સેટિંગ્સ",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = PurplePrimary
            )
        }

        item {
            OutlinedTextField(
                value = businessName,
                onValueChange = { businessName = it },
                label = { Text("સંસ્થાનું નામ") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = founderName,
                onValueChange = { founderName = it },
                label = { Text("સંચાલકનું નામ") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = contactPhone,
                onValueChange = { contactPhone = it },
                label = { Text("સંપર્ક નંબર (Phone / WhatsApp)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = upiId,
                onValueChange = { upiId = it },
                label = { Text("UPI ID (ઓનલાઇન ફી અને QR માટે)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = upiPayeeName,
                onValueChange = { upiPayeeName = it },
                label = { Text("UPI Payee Name") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = bookingAmountStr,
                onValueChange = { bookingAmountStr = it },
                label = { Text("એડવાન્સ સીટ બુકિંગ રકમ (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("નવા પ્રવેશ (Admissions Open)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Switch(checked = admissionOpen, onCheckedChange = { admissionOpen = it })
            }
        }

        item {
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("સરનામું") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = tickerText,
                onValueChange = { tickerText = it },
                label = { Text("હોમપેજ જાહેરાત પટ્ટી (Ticker Marquee)") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )
        }

        item {
            Button(
                onClick = {
                    val updated = settings.copy(
                        businessName = businessName.trim(),
                        founderName = founderName.trim(),
                        contactPhone = contactPhone.trim(),
                        whatsappNumber = contactPhone.trim(),
                        upiId = upiId.trim(),
                        upiPayeeName = upiPayeeName.trim(),
                        advanceBookingAmount = bookingAmountStr.toIntOrNull()?.coerceAtLeast(0) ?: settings.advanceBookingAmount,
                        admissionOpen = admissionOpen,
                        address = address.trim(),
                        tickerText = tickerText.trim()
                    )
                    onSaveSettings(updated)
                },
                enabled = !isBusy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("સેટિંગ્સ સેવ કરો", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ========================================================
// SHARED ADMIN DIALOGS
// ========================================================
@Composable
fun AddStudentDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, parent: String, phone: String, standard: String, totalFee: Int, password: String) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var parent by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var standard by remember { mutableStateOf("Std 10") }
    var fee by remember { mutableStateOf(HDTuitionRepository.standardAnnualFee("Std 10").toString()) }
    var password by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("નવો વિદ્યાર્થી ઉમેરો") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("વિદ્યાર્થીનું નામ *") }, singleLine = true)
                OutlinedTextField(value = parent, onValueChange = { parent = it }, label = { Text("વાલીનું નામ *") }, singleLine = true)
                OutlinedTextField(
                    value = phone,
                    onValueChange = { if (it.length <= 10) phone = it.filter(Char::isDigit) },
                    label = { Text("૧૦ અંકનો મોબાઇલ નંબર *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("પાસવર્ડ (ઓછામાં ઓછા ૪ અક્ષર) *") }, singleLine = true)
                OutlinedTextField(
                    value = standard,
                    onValueChange = {
                        standard = it
                        fee = HDTuitionRepository.standardAnnualFee(it).toString()
                    },
                    label = { Text("ધોરણ (દા.ત. Std 10)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = fee,
                    onValueChange = { fee = it },
                    label = { Text("કુલ વાર્ષિક ફી ₹") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.trim().length < 2 || parent.isBlank() || phone.length < 10 || password.trim().length < 4) {
                        Toast.makeText(context, "તમામ જરૂરી વિગતો, ૧૦ અંકનો મોબાઇલ અને ૪+ અક્ષર પાસવર્ડ લખો", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onAdd(
                        name.trim(),
                        parent.trim(),
                        phone.trim(),
                        standard.trim(),
                        fee.toIntOrNull()?.coerceAtLeast(0) ?: HDTuitionRepository.standardAnnualFee(standard),
                        password.trim()
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
            ) {
                Text("ઉમેરો")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("રદ કરો") }
        }
    )
}

@Composable
fun RecordFeePaymentDialog(
    students: List<Student>,
    onDismiss: () -> Unit,
    onSubmit: (studentId: String, amount: Int, mode: String, ref: String) -> Unit
) {
    val context = LocalContext.current
    var search by remember { mutableStateOf("") }
    var selectedStudentId by remember { mutableStateOf(students.firstOrNull()?.id ?: "") }
    var amountStr by remember { mutableStateOf("2000") }
    var paymentMode by remember { mutableStateOf("UPI (GPay)") }
    var refNo by remember { mutableStateOf("") }

    val matchingStudents = remember(students, search) {
        if (search.isBlank()) students
        else students.filter {
            it.name.contains(search, ignoreCase = true) ||
                it.id.contains(search, ignoreCase = true) ||
                it.standard.contains(search, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ફી જમા લો & પાવતી બનાવો") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("વિદ્યાર્થી શોધો") },
                    singleLine = true
                )
                Text(text = "વિદ્યાર્થી પસંદ કરો:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (matchingStudents.isEmpty()) {
                    Text(text = "કોઈ વિદ્યાર્થી મળ્યો નથી.", fontSize = 12.sp, color = TextMuted)
                } else {
                    matchingStudents.forEach { std ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedStudentId = std.id }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selectedStudentId == std.id, onClick = { selectedStudentId = std.id })
                            Text(text = "${std.name} (${std.standard} • બાકી: ₹${std.remainingFees})", fontSize = 12.sp)
                        }
                    }
                }

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("ભરેલ રકમ (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                OutlinedTextField(
                    value = paymentMode,
                    onValueChange = { paymentMode = it },
                    label = { Text("પેમેન્ટ મોડ (Cash / UPI / Cheque)") },
                    singleLine = true
                )

                OutlinedTextField(
                    value = refNo,
                    onValueChange = { refNo = it },
                    label = { Text("ટ્રાન્ઝેક્શન રેફરન્સ / નોંધ") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toIntOrNull() ?: 0
                    if (amt <= 0 || selectedStudentId.isBlank()) {
                        Toast.makeText(context, "માન્ય વિદ્યાર્થી અને રકમ પસંદ કરો", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onSubmit(selectedStudentId, amt, paymentMode.ifBlank { "Cash" }, refNo)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
            ) {
                Text("જમા કરો")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("રદ કરો") }
        }
    )
}

@Composable
fun AddHomeworkDialog(
    onDismiss: () -> Unit,
    onAdd: (HomeworkItem) -> Unit
) {
    val context = LocalContext.current
    var std by remember { mutableStateOf("Std 10") }
    var subject by remember { mutableStateOf("ગણિત (Mathematics)") }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    val todayDate = remember { SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date()) }
    val shortDate = remember { SimpleDateFormat("dd-MMM", Locale.ENGLISH).format(Date()) }
    var due by remember { mutableStateOf(todayDate) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("નવું ગૃહકાર્ય (Homework) મૂકો") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = std, onValueChange = { std = it }, label = { Text("ધોરણ (Standard) *") }, singleLine = true)
                OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("વિષય (Subject) *") }, singleLine = true)
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("શીર્ષક / પ્રકરણ *") }, singleLine = true)
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("વિગત / સ્વાધ્યાય નંબર") }, maxLines = 3)
                OutlinedTextField(value = due, onValueChange = { due = it }, label = { Text("જમા તારીખ") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (std.trim().length < 2 || subject.trim().length < 2 || title.trim().length < 2) {
                        Toast.makeText(context, "ધોરણ, વિષય અને શીર્ષક લખો", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onAdd(
                        HomeworkItem(
                            standard = std.trim(),
                            subject = subject.trim(),
                            title = title.trim(),
                            description = desc.trim(),
                            assignedDate = shortDate,
                            dueDate = due.trim().ifBlank { todayDate },
                            teacherName = "હર્ષદસિંહ રાઠોડ"
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
            ) {
                Text("પોસ્ટ કરો")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("રદ કરો") }
        }
    )
}

@Composable
fun AddAnnouncementDialog(
    onDismiss: () -> Unit,
    onAdd: (AnnouncementItem) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var targetStd by remember { mutableStateOf("All") }
    var isUrgent by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("નવી જાહેરાત પ્રસિદ્ધ કરો") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("શીર્ષક *") }, singleLine = true)
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("જાહેરાત વિગત *") }, maxLines = 4)
                OutlinedTextField(value = targetStd, onValueChange = { targetStd = it }, label = { Text("લક્ષિત ધોરણ (All અથવા Std 10)") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isUrgent, onCheckedChange = { isUrgent = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("અગત્યની / તાકીદની સૂચના (Urgent)", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.trim().length < 2 || content.isBlank()) {
                        Toast.makeText(context, "શીર્ષક અને વિગત લખો", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onAdd(
                        AnnouncementItem(
                            title = title.trim(),
                            content = content.trim(),
                            date = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date()),
                            isUrgent = isUrgent,
                            targetStandard = targetStd.trim().ifBlank { "All" },
                            authorName = "હર્ષદસિંહ રાઠોડ (Admin)"
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
            ) {
                Text("પ્રસિદ્ધ કરો")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("રદ કરો") }
        }
    )
}
