package com.example.ui.components

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import java.util.UUID

enum class UpiPaymentMode {
    UPI_APP_INTENT,
    QR_UTR_SUBMIT
}

private fun parseUpiResponseString(response: String): Map<String, String> {
    if (response.isBlank()) return emptyMap()
    return response.split("&").mapNotNull { pair ->
        val idx = pair.indexOf('=')
        if (idx > 0) {
            pair.substring(0, idx).trim().lowercase() to Uri.decode(pair.substring(idx + 1).trim())
        } else {
            null
        }
    }.toMap()
}

@Composable
fun OnlinePaymentGatewayDialog(
    amount: Int,
    studentName: String,
    studentId: String,
    standard: String,
    upiId: String = "8511273911@upi",
    payeeName: String = "Harshadsinh Rathod (HD Tuition Classes)",
    onDismiss: () -> Unit,
    onPaymentResult: (transactionId: String, mode: String, amount: Int, status: String) -> Unit
) {
    val context = LocalContext.current
    var selectedMode by remember { mutableStateOf(UpiPaymentMode.UPI_APP_INTENT) }
    var isProcessing by remember { mutableStateOf(false) }
    var utrNumber by remember { mutableStateOf("") }
    var pendingTxnRef by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val upiLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        isProcessing = false
        val responseStr = activityResult.data?.getStringExtra("response").orEmpty()
        val parsed = parseUpiResponseString(responseStr)
        val rawStatus = parsed["status"]?.uppercase()
            ?: activityResult.data?.getStringExtra("Status")?.uppercase()
            ?: ""
        val txnRef = parsed["txnref"]
            ?: parsed["txnid"]
            ?: parsed["approvalrefno"]
            ?: pendingTxnRef.ifBlank { "UPI-${UUID.randomUUID().toString().take(8).uppercase()}" }

        when {
            activityResult.resultCode == Activity.RESULT_OK && rawStatus == "SUCCESS" -> {
                onPaymentResult(txnRef, "UPI Direct App", amount, "SUCCESS")
            }
            rawStatus == "FAILURE" || rawStatus == "FAILED" -> {
                onPaymentResult(txnRef, "UPI Direct App", amount, "FAILED")
            }
            else -> {
                onPaymentResult(txnRef, "UPI Direct App", amount, "CANCELLED")
            }
        }
    }

    Dialog(onDismissRequest = { if (!isProcessing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp)
                .testTag("online_payment_gateway_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Payment,
                            contentDescription = null,
                            tint = PurplePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ઓનલાઇન ફી પેમેન્ટ (UPI)",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )
                    }
                    IconButton(onClick = onDismiss, enabled = !isProcessing) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PurpleContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "વિદ્યાર્થી:", fontSize = 12.sp, color = TextDark)
                            Text(
                                text = "$studentName ($studentId)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = PurplePrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "ધોરણ:", fontSize = 12.sp, color = TextDark)
                            Text(
                                text = standard,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = TextDark
                            )
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = BorderSubtle)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ચૂકવવાની રકમ:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextDark
                            )
                            Text(
                                text = "₹$amount",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = StatusSuccess
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaymentModeCard(
                        modifier = Modifier.weight(1f),
                        title = "UPI App Direct",
                        subtitle = "GPay / PhonePe / Paytm",
                        icon = Icons.Default.PhoneAndroid,
                        isSelected = selectedMode == UpiPaymentMode.UPI_APP_INTENT,
                        onClick = {
                            statusMessage = null
                            selectedMode = UpiPaymentMode.UPI_APP_INTENT
                        }
                    )
                    PaymentModeCard(
                        modifier = Modifier.weight(1f),
                        title = "QR + UTR",
                        subtitle = "Scan QR & Verify",
                        icon = Icons.Default.QrCodeScanner,
                        isSelected = selectedMode == UpiPaymentMode.QR_UTR_SUBMIT,
                        onClick = {
                            statusMessage = null
                            selectedMode = UpiPaymentMode.QR_UTR_SUBMIT
                        }
                    )
                }

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StatusWarningContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage!!,
                            fontSize = 12.sp,
                            color = TextDark,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (selectedMode == UpiPaymentMode.UPI_APP_INTENT) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = BackgroundLight)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UpiAppBadge(name = "Google Pay", color = Color(0xFF4285F4))
                                UpiAppBadge(name = "PhonePe", color = Color(0xFF5F259F))
                                UpiAppBadge(name = "Paytm", color = Color(0xFF002E6E))
                                UpiAppBadge(name = "BHIM", color = Color(0xFF00897B))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "તમારા ફોનમાં રહેલી UPI એપ દ્વારા ₹$amount નું લાઇવ પેમેન્ટ થશે. પેમેન્ટ પૂર્ણ અથવા રદ થયાની માહિતી એપમાં તરત જ અપડેટ થશે.",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val txnRef = "HD-${UUID.randomUUID().toString().take(10).uppercase()}"
                            pendingTxnRef = txnRef
                            val uri = Uri.parse("upi://pay").buildUpon()
                                .appendQueryParameter("pa", upiId)
                                .appendQueryParameter("pn", payeeName)
                                .appendQueryParameter("tr", txnRef)
                                .appendQueryParameter("tn", "HD Tuition Fee - $studentName ($studentId)")
                                .appendQueryParameter("am", "$amount.00")
                                .appendQueryParameter("cu", "INR")
                                .build()
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            try {
                                isProcessing = true
                                upiLauncher.launch(Intent.createChooser(intent, "UPI એપ પસંદ કરો"))
                            } catch (e: ActivityNotFoundException) {
                                isProcessing = false
                                statusMessage = "કોઈ UPI એપ મળી નથી. કૃપા કરીને 'QR + UTR' વિકલ્પ પસંદ કરીને QR સ્કેન કરો."
                                selectedMode = UpiPaymentMode.QR_UTR_SUBMIT
                            } catch (e: Exception) {
                                isProcessing = false
                                Toast.makeText(context, "UPI એપ ખૂલી શકી નથી: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        enabled = !isProcessing && amount > 0,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pay_fee_submit_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(vertical = 14.dp)
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = TextDark)
                        } else {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = TextDark, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "₹$amount UPI એપથી ચૂકવો",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                color = TextDark
                            )
                        }
                    }
                } else {
                    PaymentQRCodeView(
                        amount = amount,
                        upiId = upiId,
                        payeeName = payeeName,
                        note = "Fee - $studentName ($studentId)"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = utrNumber,
                        onValueChange = { utrNumber = it },
                        label = { Text("૧૨ અંકનો UTR / Transaction ID *") },
                        placeholder = { Text("દા.ત. 412345678901") },
                        leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = PurplePrimary) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payment_utr_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "નોંધ: UTR સબમિટ કર્યા પછી એડમિન વેરિફિકેશન બાદ તમારી ફી પાકી ગણાશે (PENDING VERIFICATION).",
                        fontSize = 11.sp,
                        color = StatusWarning
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val cleanUtr = utrNumber.trim()
                            if (cleanUtr.length < 6) {
                                Toast.makeText(context, "કૃપા કરીને સાચો UTR / Transaction ID દાખલ કરો.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            onPaymentResult(cleanUtr, "UPI QR (UTR Verification)", amount, "PENDING_VERIFICATION")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_utr_payment_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(vertical = 14.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "UTR મોકલો & વેરિફિકેશન કરાવો",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentModeCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) PurplePrimary else BorderSubtle,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick),
        color = if (isSelected) PurpleContainer else Color.White
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) PurplePrimary else TextMuted,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isSelected) PurplePrimary else TextDark
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun UpiAppBadge(name: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.12f)
    ) {
        Text(
            text = name,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}
