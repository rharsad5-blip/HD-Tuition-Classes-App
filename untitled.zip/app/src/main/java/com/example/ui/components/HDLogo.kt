package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@Composable
fun HDLogo(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    showText: Boolean = false
) {
    Row(
        modifier = modifier.testTag("hd_logo"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .shadow(4.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
                .border(2.dp, PurplePrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.hd_tuition_logo),
                contentDescription = "HD Tuition Classes Logo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        if (showText) {
            Column {
                Text(
                    text = "HD TUITION CLASSES",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "હર્ષદસિંહ રાઠોડ • +91 85112 73911",
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = PurpleMedium
                )
            }
        }
    }
}

@Composable
fun HDBadgeLogo(
    modifier: Modifier = Modifier,
    size: Dp = 100.dp
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .shadow(10.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
                .border(3.dp, PurplePrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.hd_tuition_logo),
                contentDescription = "HD Tuition Classes Official Logo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "HD TUITION CLASSES",
            fontWeight = FontWeight.Black,
            fontSize = 22.sp,
            color = PurplePrimary,
            letterSpacing = 0.8.sp,
            textAlign = TextAlign.Center
        )
        Text(
            text = "સંચાલક: હર્ષદસિંહ રાઠોડ • મો. +91 85112 73911",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = TextDark,
            textAlign = TextAlign.Center
        )
        Text(
            text = "ધોરણ ૧ થી ૧૨ | તમામ વિષયો | ગુજરાતી માધ્યમ",
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            color = GoldYellowDeep,
            textAlign = TextAlign.Center
        )
    }
}
