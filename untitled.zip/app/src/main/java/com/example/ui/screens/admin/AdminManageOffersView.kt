package com.example.ui.screens.admin

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.*
import com.example.ui.components.OfferBannerCard
import com.example.ui.components.OfferBannerPreset
import com.example.ui.components.compressImageUriToBase64
import com.example.ui.components.rememberBase64ImageBitmap
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private fun formatUtcMillisToDate(utcMillis: Long): String {
    val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    return sdf.format(Date(utcMillis))
}

private fun toUtcStartOfDay(utcMillis: Long): Long {
    return (utcMillis / 86_400_000L) * 86_400_000L
}

private fun toUtcEndOfDay(utcMillis: Long): Long {
    return toUtcStartOfDay(utcMillis) + 86_399_999L
}

@Composable
fun AdminManageOffersView(
    offers: List<SpecialOffer>,
    offerHistory: List<OfferHistoryEntry>,
    students: List<Student>,
    isGu: Boolean,
    isBusy: Boolean,
    onCreateOffer: (SpecialOffer) -> Unit,
    onUpdateOffer: (SpecialOffer) -> Unit,
    onDeleteOffer: (String) -> Unit,
    onToggleStatus: (String) -> Unit,
    onApplyOfferToEligible: (String) -> Unit,
    onRevokeStudentOffer: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // 0: Active, 1: Expired / Inactive, 2: Offer History
    var selectedSubTab by remember { mutableIntStateOf(0) }
    var editingOffer by remember { mutableStateOf<SpecialOffer?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }
    var offerToDelete by remember { mutableStateOf<SpecialOffer?>(null) }

    val nowMs = System.currentTimeMillis()
    val activeOffers = remember(offers, nowMs) {
        offers.filter { it.isActive && !it.isExpired(nowMs) }
    }
    val inactiveOrExpiredOffers = remember(offers, nowMs) {
        offers.filter { !it.isActive || it.isExpired(nowMs) }
    }
    val studentsWithOffers = remember(students) {
        students.filter { it.offerDiscount > 0 || it.appliedOfferId.isNotBlank() }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header + Create Offer CTA
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isGu) "ઑફર્સ મેનેજમેન્ટ (${offers.size})" else "Manage Offers (${offers.size})",
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp,
                    color = PurplePrimary
                )
                Text(
                    text = if (isGu) "લાઇવ ફાયરસ્ટોર ઑફર્સ, ડિસ્કાઉન્ટ અને ઇતિહાસ" else "Live offers, rules, auto-discounts & history",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
            Button(
                onClick = {
                    editingOffer = null
                    showEditorDialog = true
                },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("admin_create_offer_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = GoldYellow)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isGu) "નવી ઑફર" else "New Offer",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Summary KPI Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OfferStatChip(
                label = if (isGu) "સક્રિય ઑફર્સ" else "Active",
                value = "${activeOffers.size}",
                bg = StatusSuccessContainer,
                fg = StatusSuccess,
                modifier = Modifier.weight(1f)
            )
            OfferStatChip(
                label = if (isGu) "લાભાર્થીઓ" else "Applied",
                value = "${studentsWithOffers.size}",
                bg = PurpleContainer,
                fg = PurplePrimary,
                modifier = Modifier.weight(1f)
            )
            OfferStatChip(
                label = if (isGu) "ઇતિહાસ" else "History",
                value = "${offerHistory.size}",
                bg = GoldYellowContainer,
                fg = TextDark,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sub-Tabs: Active | Expired/Off | History
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color.White,
            contentColor = PurplePrimary,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = {
                    Text(
                        text = if (isGu) "સક્રિય (${activeOffers.size})" else "Active (${activeOffers.size})",
                        fontSize = 12.sp,
                        fontWeight = if (selectedSubTab == 0) FontWeight.Bold else FontWeight.Medium
                    )
                },
                modifier = Modifier.testTag("offers_subtab_active")
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = {
                    Text(
                        text = if (isGu) "બંધ/સમાપ્ત (${inactiveOrExpiredOffers.size})" else "Off/Expired (${inactiveOrExpiredOffers.size})",
                        fontSize = 12.sp,
                        fontWeight = if (selectedSubTab == 1) FontWeight.Bold else FontWeight.Medium
                    )
                },
                modifier = Modifier.testTag("offers_subtab_inactive")
            )
            Tab(
                selected = selectedSubTab == 2,
                onClick = { selectedSubTab = 2 },
                text = {
                    Text(
                        text = if (isGu) "ઇતિહાસ (${offerHistory.size})" else "History (${offerHistory.size})",
                        fontSize = 12.sp,
                        fontWeight = if (selectedSubTab == 2) FontWeight.Bold else FontWeight.Medium
                    )
                },
                modifier = Modifier.testTag("offers_subtab_history")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedSubTab) {
                0, 1 -> {
                    val list = if (selectedSubTab == 0) activeOffers else inactiveOrExpiredOffers
                    if (list.isEmpty()) {
                        item {
                            AdminEmptyStateCard(
                                if (selectedSubTab == 0) {
                                    if (isGu) "હાલમાં કોઈ સક્રિય ઑફર નથી. 'નવી ઑફર' પર ક્લિક કરીને ઉમેરો."
                                    else "No active offers yet. Tap 'New Offer' to create one."
                                } else {
                                    if (isGu) "કોઈ નિષ્ક્રિય અથવા સમાપ્ત થયેલી ઑફર નથી."
                                    else "No inactive or expired offers."
                                }
                            )
                        }
                    } else {
                        items(list, key = { it.id }) { offer ->
                            OfferBannerCard(
                                offer = offer,
                                isGu = isGu,
                                adminHeaderControls = {
                                    Switch(
                                        checked = offer.isActive,
                                        onCheckedChange = { onToggleStatus(offer.id) },
                                        enabled = !isBusy,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = GoldYellow,
                                            checkedTrackColor = RoyalIndigoDark,
                                            uncheckedThumbColor = Color.White,
                                            uncheckedTrackColor = Color.Gray.copy(alpha = 0.6f)
                                        ),
                                        modifier = Modifier.testTag("toggle_offer_switch_${offer.id}")
                                    )
                                },
                                footerContent = {
                                    if (offer.claimedStudentIds.isNotEmpty()) {
                                        Text(
                                            text = if (isGu) {
                                                "ક્લેમ કરનાર વિદ્યાર્થી IDs (${offer.claimedCount}): ${offer.claimedStudentIds.joinToString(", ")}"
                                            } else {
                                                "Claimed by (${offer.claimedCount}): ${offer.claimedStudentIds.joinToString(", ")}"
                                            },
                                            fontSize = 11.sp,
                                            color = PurplePrimary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 2.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (offer.isWithinDateWindow() && offer.hasRemainingClaims()) {
                                            OutlinedButton(
                                                onClick = { onApplyOfferToEligible(offer.id) },
                                                enabled = !isBusy,
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("apply_offer_eligible_btn_${offer.id}")
                                            ) {
                                                Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (isGu) "લાગુ કરો" else "Auto-Apply",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                editingOffer = offer
                                                showEditorDialog = true
                                            },
                                            enabled = !isBusy,
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("edit_offer_btn_${offer.id}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Offer", modifier = Modifier.size(14.dp), tint = PurplePrimary)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isGu) "સુધારો" else "Edit",
                                                fontSize = 11.sp,
                                                color = PurplePrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        OutlinedButton(
                                            onClick = { offerToDelete = offer },
                                            enabled = !isBusy,
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, StatusError.copy(alpha = 0.5f)),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("delete_offer_btn_${offer.id}")
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Offer", modifier = Modifier.size(14.dp), tint = StatusError)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isGu) "ડિલીટ" else "Delete",
                                                fontSize = 11.sp,
                                                color = StatusError,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            )
                        }
                    }
                }

                2 -> {
                    if (studentsWithOffers.isNotEmpty()) {
                        item {
                            Text(
                                text = if (isGu) "હાલમાં ઑફર ડિસ્કાઉન્ટ ધરાવતા વિદ્યાર્થીઓ (${studentsWithOffers.size})" else "Students Currently Receiving Offer Discounts (${studentsWithOffers.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = PurplePrimary
                            )
                        }
                        items(studentsWithOffers, key = { "applied_${it.id}" }) { std ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${std.name} (${std.id}) • ${std.standard}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TextDark
                                        )
                                        Text(
                                            text = "${std.appliedOfferTitle.ifBlank { "Offer" }} • -₹${std.offerDiscount}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = StatusSuccess
                                        )
                                    }
                                    TextButton(
                                        onClick = { onRevokeStudentOffer(std.id) },
                                        enabled = !isBusy
                                    ) {
                                        Text(
                                            text = if (isGu) "રદ કરો" else "Revoke",
                                            color = StatusError,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = if (isGu) "ઑફર એક્ટિવિટી ઇતિહાસ (Audit Log)" else "Offer History & Audit Log",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PurplePrimary
                        )
                    }

                    if (offerHistory.isEmpty()) {
                        item {
                            AdminEmptyStateCard(
                                if (isGu) "હજુ સુધી કોઈ ઑફર ઇતિહાસ નોંધાયેલ નથી."
                                else "No offer history recorded yet."
                            )
                        }
                    } else {
                        items(offerHistory, key = { it.id }) { entry ->
                            OfferHistoryCard(entry = entry, isGu = isGu)
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        OfferEditorDialog(
            initialOffer = editingOffer,
            isGu = isGu,
            onDismiss = { showEditorDialog = false },
            onSave = { offer ->
                if (editingOffer == null) {
                    onCreateOffer(offer)
                } else {
                    onUpdateOffer(offer)
                }
                showEditorDialog = false
            }
        )
    }

    if (offerToDelete != null) {
        val target = offerToDelete!!
        AlertDialog(
            onDismissRequest = { offerToDelete = null },
            title = {
                Text(
                    text = if (isGu) "ઑફર ડિલીટ કરવી છે?" else "Delete Offer?",
                    fontWeight = FontWeight.Bold,
                    color = StatusError
                )
            },
            text = {
                Text(
                    text = if (isGu) {
                        "\"${target.title}\" ઑફર કાયમી ડિલીટ થઈ જશે. ઇતિહાસ સુરક્ષિત રહેશે."
                    } else {
                        "Delete \"${target.title}\" permanently? Its history log will be preserved."
                    }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteOffer(target.id)
                        offerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                    modifier = Modifier.testTag("confirm_delete_offer_btn")
                ) {
                    Text(if (isGu) "ડિલીટ કરો" else "Delete", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { offerToDelete = null }) {
                    Text(if (isGu) "રદ કરો" else "Cancel")
                }
            }
        )
    }
}

@Composable
private fun OfferStatChip(
    label: String,
    value: String,
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, fontWeight = FontWeight.Black, fontSize = 18.sp, color = fg)
            Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = fg.copy(alpha = 0.9f))
        }
    }
}

@Composable
private fun OfferHistoryCard(
    entry: OfferHistoryEntry,
    isGu: Boolean
) {
    val badgeBg = when (entry.action) {
        OfferHistoryAction.CREATED, OfferHistoryAction.ACTIVATED, OfferHistoryAction.CLAIMED -> StatusSuccessContainer
        OfferHistoryAction.DELETED, OfferHistoryAction.REVOKED, OfferHistoryAction.DEACTIVATED -> StatusErrorContainer
        else -> PurpleContainer
    }
    val badgeFg = when (entry.action) {
        OfferHistoryAction.CREATED, OfferHistoryAction.ACTIVATED, OfferHistoryAction.CLAIMED -> StatusSuccess
        OfferHistoryAction.DELETED, OfferHistoryAction.REVOKED, OfferHistoryAction.DEACTIVATED -> StatusError
        else -> PurplePrimary
    }
    val formattedTime = remember(entry.createdAt) {
        entry.createdAt?.toDate()?.let {
            SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.ENGLISH).format(it)
        } ?: if (isGu) "હમણાં" else "Just now"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("offer_history_card_${entry.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = entry.offerTitle,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = PurplePrimary,
                    modifier = Modifier.weight(1f)
                )
                Surface(shape = RoundedCornerShape(6.dp), color = badgeBg) {
                    Text(
                        text = entry.action,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = badgeFg,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Text(text = entry.summary, fontSize = 12.sp, color = TextDark)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${entry.actorRole}${if (entry.studentId.isNotBlank()) " • ${entry.studentId}" else ""}",
                    fontSize = 10.sp,
                    color = TextMuted
                )
                Text(text = formattedTime, fontSize = 10.sp, color = TextMuted)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun OfferEditorDialog(
    initialOffer: SpecialOffer?,
    isGu: Boolean,
    onDismiss: () -> Unit,
    onSave: (SpecialOffer) -> Unit
) {
    val context = LocalContext.current
    val nowMs = System.currentTimeMillis()
    val defaultStartMs = toUtcStartOfDay(nowMs)
    val defaultEndMs = toUtcEndOfDay(nowMs + 30L * 86_400_000L)

    var title by remember { mutableStateOf(initialOffer?.title ?: "") }
    var subtitle by remember { mutableStateOf(initialOffer?.subtitle ?: "") }
    var description by remember { mutableStateOf(initialOffer?.discountDescription ?: "") }
    var discountType by remember { mutableStateOf(initialOffer?.discountType ?: OfferDiscountType.PERCENTAGE) }
    var discountValueText by remember { mutableStateOf(if ((initialOffer?.discountValue ?: 0) > 0) initialOffer!!.discountValue.toString() else "10") }
    var badge by remember { mutableStateOf(initialOffer?.badge ?: "") }

    var startDateEpochMs by remember {
        mutableLongStateOf(initialOffer?.startDateEpochMs?.takeIf { it > 0L } ?: defaultStartMs)
    }
    var endDateEpochMs by remember {
        mutableLongStateOf(initialOffer?.endDateEpochMs?.takeIf { it > 0L } ?: defaultEndMs)
    }
    var showStartDatePicker by remember { mutableStateOf(false) }
    var showEndDatePicker by remember { mutableStateOf(false) }

    val initialStds = initialOffer?.applicableStandards?.map { normalizeToCanonicalStandard(it) }?.toSet() ?: setOf("All")
    var selectedStandards by remember { mutableStateOf(initialStds) }
    var targetAudience by remember { mutableStateOf(initialOffer?.targetAudience ?: OfferAudience.ALL) }
    var maxClaimsText by remember {
        mutableStateOf(if ((initialOffer?.maxClaims ?: 0) > 0) initialOffer!!.maxClaims.toString() else "")
    }
    var isUnlimitedClaims by remember { mutableStateOf((initialOffer?.maxClaims ?: 0) == 0) }
    var isActive by remember { mutableStateOf(initialOffer?.isActive ?: true) }

    var bannerImageBase64 by remember { mutableStateOf(initialOffer?.bannerImageBase64 ?: "") }
    var bannerPresetKey by remember { mutableStateOf(initialOffer?.bannerPresetKey ?: OfferBannerPreset.PURPLE_GOLD.key) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val encoded = compressImageUriToBase64(context, uri)
            if (encoded != null && encoded.length <= 195_000) {
                bannerImageBase64 = encoded
                Toast.makeText(
                    context,
                    if (isGu) "બેનર ફોટો પસંદ થયો ✓" else "Banner image attached ✓",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    context,
                    if (isGu) "આ ફોટો માન્ય સાઇઝથી મોટો છે, બીજો ફોટો પસંદ કરો." else "Selected image could not fit size limit.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    val startDateFormatted = remember(startDateEpochMs) { formatUtcMillisToDate(startDateEpochMs) }
    val endDateFormatted = remember(endDateEpochMs) { formatUtcMillisToDate(endDateEpochMs) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = Color.White
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PurplePrimary)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (initialOffer == null) {
                            if (isGu) "નવી ઑફર બનાવો" else "Create New Offer"
                        } else {
                            if (isGu) "ઑફર સંપાદિત કરો" else "Edit Offer"
                        },
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                // Scrollable Form
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(if (isGu) "ઑફરનું શીર્ષક (Title) *" else "Offer Title *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("offer_title_input")
                    )

                    OutlinedTextField(
                        value = subtitle,
                        onValueChange = { subtitle = it },
                        label = { Text(if (isGu) "પેટા શીર્ષક (Subtitle)" else "Subtitle (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text(if (isGu) "ઑફરની વિગત (Description) *" else "Offer Description *") },
                        maxLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("offer_description_input")
                    )

                    // Discount Type + Value
                    Text(
                        text = if (isGu) "ડિસ્કાઉન્ટ પ્રકાર અને મૂલ્ય *" else "Discount Type & Value *",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = discountType == OfferDiscountType.PERCENTAGE,
                            onClick = { discountType = OfferDiscountType.PERCENTAGE },
                            label = { Text(if (isGu) "ટકાવારી (%)" else "Percentage (%)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("discount_type_percentage_chip")
                        )
                        FilterChip(
                            selected = discountType == OfferDiscountType.FIXED,
                            onClick = { discountType = OfferDiscountType.FIXED },
                            label = { Text(if (isGu) "ચોક્કસ રકમ (₹)" else "Fixed Amount (₹)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("discount_type_fixed_chip")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = discountValueText,
                            onValueChange = { discountValueText = it.filter { ch -> ch.isDigit() } },
                            label = {
                                Text(
                                    if (discountType == OfferDiscountType.PERCENTAGE) {
                                        if (isGu) "ટકા (1-100) *" else "Percent (1-100) *"
                                    } else {
                                        if (isGu) "રકમ (₹) *" else "Amount (₹) *"
                                    }
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("offer_discount_value_input")
                        )
                        OutlinedTextField(
                            value = badge,
                            onValueChange = { badge = it },
                            label = { Text(if (isGu) "બેજ લેબલ (દા.ત. MEGA)" else "Badge Label") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Start Date & End Date
                    Text(
                        text = if (isGu) "ઑફર સમયગાળો (Start & End Date)" else "Offer Validity Dates",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedCard(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showStartDatePicker = true }
                                .testTag("offer_start_date_btn")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(if (isGu) "શરૂઆત તારીખ" else "Start Date", fontSize = 10.sp, color = TextMuted)
                                Text(startDateFormatted, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PurplePrimary)
                            }
                        }
                        OutlinedCard(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showEndDatePicker = true }
                                .testTag("offer_end_date_btn")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(if (isGu) "અંતિમ તારીખ" else "End Date", fontSize = 10.sp, color = TextMuted)
                                Text(endDateFormatted, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StatusWarning)
                            }
                        }
                    }

                    // Applicable Standards Multi-Select
                    Text(
                        text = if (isGu) "લાગુ પડતા ધોરણ (Standards)" else "Applicable Standards",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        FilterChip(
                            selected = "All" in selectedStandards,
                            onClick = { selectedStandards = setOf("All") },
                            label = { Text(if (isGu) "તમામ (All)" else "All", fontSize = 11.sp) },
                            modifier = Modifier.testTag("offer_std_chip_all")
                        )
                        for (stdNum in 1..12) {
                            val key = "Std $stdNum"
                            val isSelected = key in selectedStandards && "All" !in selectedStandards
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    val base = selectedStandards - "All"
                                    val next = if (key in base) base - key else base + key
                                    selectedStandards = next.ifEmpty { setOf("All") }
                                },
                                label = { Text(key, fontSize = 11.sp) },
                                modifier = Modifier.testTag("offer_std_chip_$stdNum")
                            )
                        }
                    }

                    // Student Type (All / New / Existing)
                    Text(
                        text = if (isGu) "વિદ્યાર્થી વર્ગ (Target Audience)" else "Target Audience",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val audiences = listOf(
                            Triple(OfferAudience.ALL, if (isGu) "બધા" else "All", "audience_all"),
                            Triple(OfferAudience.NEW, if (isGu) "નવા" else "New", "audience_new"),
                            Triple(OfferAudience.EXISTING, if (isGu) "જૂના" else "Existing", "audience_existing")
                        )
                        audiences.forEach { (code, label, tag) ->
                            FilterChip(
                                selected = targetAudience == code,
                                onClick = { targetAudience = code },
                                label = { Text(label, fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag(tag)
                            )
                        }
                    }

                    // Limited Student Offer (First 3, First 5, Custom N, Unlimited)
                    Text(
                        text = if (isGu) "મર્યાદિત વિદ્યાર્થી સંખ્યા (Limited Offer)" else "Limited Student Claims",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        FilterChip(
                            selected = isUnlimitedClaims,
                            onClick = {
                                isUnlimitedClaims = true
                                maxClaimsText = ""
                            },
                            label = { Text(if (isGu) "અમર્યાદિત" else "Unlimited", fontSize = 11.sp) }
                        )
                        listOf(3, 5, 10, 20).forEach { count ->
                            FilterChip(
                                selected = !isUnlimitedClaims && maxClaimsText == count.toString(),
                                onClick = {
                                    isUnlimitedClaims = false
                                    maxClaimsText = count.toString()
                                },
                                label = { Text(if (isGu) "પ્રથમ $count" else "First $count", fontSize = 11.sp) },
                                modifier = Modifier.testTag("offer_limit_chip_$count")
                            )
                        }
                    }
                    if (!isUnlimitedClaims) {
                        OutlinedTextField(
                            value = maxClaimsText,
                            onValueChange = { maxClaimsText = it.filter { ch -> ch.isDigit() } },
                            label = { Text(if (isGu) "પ્રથમ કેટલા વિદ્યાર્થીઓ (N)?" else "Max Student Claims (N)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("offer_max_claims_input")
                        )
                    }

                    // Banner Image (Zero-Permission Photo Picker + Presets)
                    Text(
                        text = if (isGu) "ઑફર બેનર ફોટો / થીમ (Banner)" else "Offer Banner Image / Theme",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    val previewBitmap = rememberBase64ImageBitmap(bannerImageBase64)
                    if (previewBitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .clip(RoundedCornerShape(12.dp))
                        ) {
                            Image(
                                bitmap = previewBitmap,
                                contentDescription = "Selected offer banner",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            IconButton(
                                onClick = { bannerImageBase64 = "" },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(6.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove image", tint = Color.White)
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pick_offer_banner_btn")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (bannerImageBase64.isNotBlank()) {
                                if (isGu) "બેનર ફોટો બદલો" else "Change Banner Image"
                            } else {
                                if (isGu) "ગેલેરીમાંથી બેનર ફોટો પસંદ કરો" else "Pick Banner Image from Gallery"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Preset Theme Swatches
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OfferBannerPreset.entries.forEach { preset ->
                            val isSelected = bannerPresetKey == preset.key
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clickable { bannerPresetKey = preset.key },
                                shape = RoundedCornerShape(10.dp),
                                border = if (isSelected) BorderStroke(2.dp, GoldYellow) else null
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.horizontalGradient(listOf(preset.startColor, preset.endColor))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = GoldYellow, modifier = Modifier.size(18.dp))
                                    } else {
                                        Icon(preset.icon, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Active Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isGu) "ઑફર તરત સક્રિય રાખો (Active)" else "Activate Offer Immediately",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }

                // Bottom Action Bar
                HorizontalDivider(color = BorderSubtle)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isGu) "રદ કરો" else "Cancel")
                    }
                    Button(
                        onClick = {
                            val cleanTitle = title.trim()
                            val numericVal = discountValueText.toIntOrNull() ?: 0
                            val maxVal = if (discountType == OfferDiscountType.PERCENTAGE) 100 else 500000
                            val claimsLimit = if (isUnlimitedClaims) 0 else (maxClaimsText.toIntOrNull() ?: 0)

                            if (cleanTitle.length < 2) {
                                Toast.makeText(context, if (isGu) "ઑફરનું શીર્ષક લખો" else "Enter offer title", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (numericVal <= 0 || numericVal > maxVal) {
                                Toast.makeText(
                                    context,
                                    if (isGu) "માન્ય ડિસ્કાઉન્ટ મૂલ્ય લખો (1 થી $maxVal)" else "Enter valid discount (1 to $maxVal)",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@Button
                            }
                            if (endDateEpochMs < startDateEpochMs) {
                                Toast.makeText(
                                    context,
                                    if (isGu) "અંતિમ તારીખ શરૂઆતની તારીખ કરતાં મોટી હોવી જોઈએ" else "End date must be on or after start date",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@Button
                            }
                            if (!isUnlimitedClaims && claimsLimit <= 0) {
                                Toast.makeText(
                                    context,
                                    if (isGu) "મર્યાદિત વિદ્યાર્થી સંખ્યા (N > 0) લખો" else "Enter valid student claim limit (N > 0)",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@Button
                            }

                            val resultOffer = SpecialOffer(
                                id = initialOffer?.id ?: "",
                                title = cleanTitle,
                                subtitle = subtitle.trim(),
                                badge = badge.trim().ifBlank {
                                    if (discountType == OfferDiscountType.PERCENTAGE) "$numericVal% OFF" else "₹$numericVal OFF"
                                },
                                discountDescription = description.trim().ifBlank { cleanTitle },
                                discountType = discountType,
                                discountValue = numericVal,
                                applicableStandards = selectedStandards.toList(),
                                targetAudience = targetAudience,
                                startDate = startDateFormatted,
                                endDate = endDateFormatted,
                                startDateEpochMs = startDateEpochMs,
                                endDateEpochMs = endDateEpochMs,
                                validTill = endDateFormatted,
                                maxClaims = claimsLimit,
                                claimedCount = initialOffer?.claimedCount ?: 0,
                                claimedStudentIds = initialOffer?.claimedStudentIds ?: emptyList(),
                                bannerImageBase64 = bannerImageBase64,
                                bannerImageUrl = initialOffer?.bannerImageUrl ?: "",
                                bannerPresetKey = bannerPresetKey,
                                isActive = isActive
                            )
                            onSave(resultOffer)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("save_offer_btn")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = GoldYellow, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isGu) "ઑફર સેવ કરો" else "Save Offer",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }

    if (showStartDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = startDateEpochMs)
        DatePickerDialog(
            onDismissRequest = { showStartDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { picked ->
                            startDateEpochMs = toUtcStartOfDay(picked)
                            if (endDateEpochMs < startDateEpochMs) {
                                endDateEpochMs = toUtcEndOfDay(picked)
                            }
                        }
                        showStartDatePicker = false
                    }
                ) { Text(if (isGu) "પસંદ કરો" else "Select") }
            },
            dismissButton = {
                TextButton(onClick = { showStartDatePicker = false }) { Text(if (isGu) "રદ" else "Cancel") }
            }
        ) {
            DatePicker(state = state)
        }
    }

    if (showEndDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = endDateEpochMs)
        DatePickerDialog(
            onDismissRequest = { showEndDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { picked ->
                            endDateEpochMs = toUtcEndOfDay(picked)
                        }
                        showEndDatePicker = false
                    }
                ) { Text(if (isGu) "પસંદ કરો" else "Select") }
            },
            dismissButton = {
                TextButton(onClick = { showEndDatePicker = false }) { Text(if (isGu) "રદ" else "Cancel") }
            }
        ) {
            DatePicker(state = state)
        }
    }
}
