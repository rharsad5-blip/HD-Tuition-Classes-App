package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// HD Tuition Classes Brand Colors (Refreshed Premium Palette)
// Theme: Deep Royal Midnight Indigo, Radiant Sun Gold, Crisp Porcelain White

val RoyalIndigoDark = Color(0xFF130E30)
val RoyalIndigo = Color(0xFF1E174C)
val PurplePrimary = Color(0xFF2B1F70)
val PurpleVariant = Color(0xFF3B2D8A)
val PurpleMedium = Color(0xFF4C3AA8)
val PurpleLight = Color(0xFF6352C5)
val PurpleContainer = Color(0xFFEDE9FE)
val PurpleSurface = Color(0xFFF5F3FF)

val GoldYellow = Color(0xFFFFB800)
val GoldYellowDark = Color(0xFFE69500)
val GoldYellowLight = Color(0xFFFFD54F)
val GoldYellowContainer = Color(0xFFFFF7DB)
val GoldYellowDeep = Color(0xFFD97706)

val NeonCyanAccent = Color(0xFF06B6D4)
val NeonMagentaAccent = Color(0xFFEC4899)

val SurfaceWhite = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8F9FE)
val TextDark = Color(0xFF111827)
val TextMuted = Color(0xFF6B7280)
val BorderSubtle = Color(0xFFE5E7EB)

val StatusSuccess = Color(0xFF10B981)
val StatusSuccessContainer = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusError = Color(0xFFEF4444)
val StatusErrorContainer = Color(0xFFFEE2E2)

// Dark Theme
val DarkBackground = Color(0xFF0F0B24)
val DarkSurface = Color(0xFF181339)
val DarkSurfaceVariant = Color(0xFF231C4E)
val DarkTextPrimary = Color(0xFFF3F4F6)
val DarkTextMuted = Color(0xFF9CA3AF)
