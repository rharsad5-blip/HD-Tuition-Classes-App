package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OfferAudience
import com.example.data.model.SpecialOffer
import com.example.ui.theme.*
import java.io.ByteArrayOutputStream
import kotlin.math.max

enum class OfferBannerPreset(
    val key: String,
    val labelGu: String,
    val labelEn: String,
    val startColor: Color,
    val endColor: Color,
    val icon: ImageVector
) {
    PURPLE_GOLD(
        key = "PURPLE_GOLD",
        labelGu = "રોયલ પર્પલ & ગોલ્ડ",
        labelEn = "Royal Purple & Gold",
        startColor = Color(0xFF4A148C),
        endColor = Color(0xFF8E24AA),
        icon = Icons.Default.WorkspacePremium
    ),
    FESTIVAL_GLOW(
        key = "FESTIVAL_GLOW",
        labelGu = "તહેવાર સ્પેશિયલ",
        labelEn = "Festival Glow",
        startColor = Color(0xFF6A1B9A),
        endColor = Color(0xFFFF8F00),
        icon = Icons.Default.Celebration
    ),
    SCHOLARSHIP_CROWN(
        key = "SCHOLARSHIP_CROWN",
        labelGu = "સ્કોલરશીપ સ્ટાર",
        labelEn = "Scholarship Star",
        startColor = Color(0xFF311B92),
        endColor = Color(0xFF512DA8),
        icon = Icons.Default.School
    ),
    EARLY_BIRD(
        key = "EARLY_BIRD",
        labelGu = "અર્લી બર્ડ સ્પેશિયલ",
        labelEn = "Early Bird Gold",
        startColor = Color(0xFF5E35B1),
        endColor = Color(0xFFAD1457),
        icon = Icons.Default.AutoAwesome
    );

    companion object {
        fun fromKey(key: String): OfferBannerPreset {
            return entries.firstOrNull { it.key == key } ?: PURPLE_GOLD
        }
    }
}

fun compressImageUriToBase64(context: Context, uri: Uri): String? {
    return runCatching {
        val resolver = context.contentResolver
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
        }
        val maxSide = max(boundsOpts.outWidth, boundsOpts.outHeight)
        var sampleSize = 1
        while (maxSide / sampleSize > 640) {
            sampleSize *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded = resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: return null

        val maxTargetDim = 640f
        val scale = minOf(maxTargetDim / decoded.width, maxTargetDim / decoded.height, 1f)
        val scaledBitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                decoded,
                (decoded.width * scale).toInt().coerceAtLeast(1),
                (decoded.height * scale).toInt().coerceAtLeast(1),
                true
            ).also { if (it != decoded) decoded.recycle() }
        } else {
            decoded
        }

        val out = ByteArrayOutputStream()
        var quality = 78
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        while (out.size() > 110_000 && quality > 30) {
            out.reset()
            quality -= 12
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        }
        scaledBitmap.recycle()
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }.getOrNull()
}

@Composable
fun rememberBase64ImageBitmap(base64: String): ImageBitmap? {
    return remember(base64) {
        if (base64.isBlank()) return@remember null
        runCatching {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }.getOrNull()
    }
}

@Composable
fun OfferBannerCard(
    offer: SpecialOffer,
    isGu: Boolean,
    modifier: Modifier = Modifier,
    isAppliedToStudent: Boolean = false,
    calculatedStudentDiscount: Int? = null,
    adminHeaderControls: (@Composable RowScope.() -> Unit)? = null,
    footerContent: (@Composable ColumnScope.() -> Unit)? = null
) {
    val bannerBitmap = rememberBase64ImageBitmap(offer.bannerImageBase64)
    val preset = OfferBannerPreset.fromKey(offer.bannerPresetKey)
    val isExpired = offer.isExpired()
    val isUpcoming = offer.isUpcoming()
    val remainingSlots = offer.remainingClaimsCount()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("offer_card_${offer.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column {
            // Top Visual Banner (Uploaded Photo OR Styled Gradient Artwork)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (bannerBitmap != null) 144.dp else 88.dp)
                    .background(
                        Brush.horizontalGradient(listOf(preset.startColor, preset.endColor))
                    )
            ) {
                if (bannerBitmap != null) {
                    Image(
                        bitmap = bannerBitmap,
                        contentDescription = offer.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.25f),
                                        Color.Black.copy(alpha = 0.65f)
                                    )
                                )
                            )
                    )
                } else {
                    // Decorative circles for visual richness
                    Box(
                        modifier = Modifier
                            .size(96.dp)
                            .align(Alignment.TopEnd)
                            .offset(x = 24.dp, y = (-24).dp)
                            .clip(CircleShape)
                            .background(GoldYellow.copy(alpha = 0.18f))
                    )
                    Icon(
                        imageVector = preset.icon,
                        contentDescription = null,
                        tint = GoldYellow.copy(alpha = 0.30f),
                        modifier = Modifier
                            .size(56.dp)
                            .align(Alignment.BottomEnd)
                            .padding(end = 12.dp, bottom = 6.dp)
                    )
                }

                // Top Row: Discount Pill + Applied/Status Pill + Optional Admin Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .align(Alignment.TopStart),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GoldYellow
                        ) {
                            Text(
                                text = offer.discountBadgeLabel(),
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = TextDark,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        if (isAppliedToStudent) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusSuccess
                            ) {
                                Text(
                                    text = if (isGu) "લાગુ થયેલ ✓" else "APPLIED ✓",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        } else if (!offer.isActive) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusError
                            ) {
                                Text(
                                    text = if (isGu) "નિષ્ક્રિય" else "INACTIVE",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        } else if (isExpired) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusError
                            ) {
                                Text(
                                    text = if (isGu) "સમાપ્ત" else "EXPIRED",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        } else if (isUpcoming) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.9f)
                            ) {
                                Text(
                                    text = if (isGu) "આગામી" else "UPCOMING",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = PurplePrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    if (adminHeaderControls != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            content = adminHeaderControls
                        )
                    }
                }

                // Bottom Overlay Title inside banner
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = offer.title,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (offer.subtitle.isNotBlank()) {
                        Text(
                            text = offer.subtitle,
                            fontSize = 11.sp,
                            color = GoldYellowLight,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Body Details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (offer.discountDescription.isNotBlank()) {
                    Text(
                        text = offer.discountDescription,
                        fontSize = 12.sp,
                        color = TextDark
                    )
                }

                // Metadata Chips Row (Standards, Audience, Limited Cap)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OfferInfoPill(
                            icon = Icons.Default.MenuBook,
                            text = offer.standardsSummaryLabel(isGu),
                            bgColor = PurpleContainer,
                            fgColor = PurplePrimary,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        OfferInfoPill(
                            icon = when (offer.targetAudience) {
                                OfferAudience.NEW -> Icons.Default.PersonAdd
                                OfferAudience.EXISTING -> Icons.Default.VerifiedUser
                                else -> Icons.Default.Groups
                            },
                            text = offer.audienceLabel(isGu),
                            bgColor = GoldYellowContainer,
                            fgColor = TextDark
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OfferInfoPill(
                            icon = Icons.Default.Schedule,
                            text = offer.remainingValidityLabel(isGu),
                            bgColor = if (isExpired) StatusErrorContainer else StatusSuccessContainer,
                            fgColor = if (isExpired) StatusError else StatusSuccess
                        )
                        if (offer.maxClaims > 0) {
                            OfferInfoPill(
                                icon = Icons.Default.Bolt,
                                text = if (isGu) {
                                    "પ્રથમ ${offer.maxClaims} • બાકી ${remainingSlots ?: 0}"
                                } else {
                                    "First ${offer.maxClaims} • ${remainingSlots ?: 0} left"
                                },
                                bgColor = if ((remainingSlots ?: 0) > 0) GoldYellowContainer else StatusErrorContainer,
                                fgColor = if ((remainingSlots ?: 0) > 0) GoldYellowDeep else StatusError
                            )
                        }
                    }
                }

                // Expiry date line
                if (offer.startDate.isNotBlank() || offer.endDate.isNotBlank() || offer.validTill.isNotBlank()) {
                    val dateLine = when {
                        offer.startDate.isNotBlank() && offer.endDate.isNotBlank() ->
                            if (isGu) "સમયગાળો: ${offer.startDate} થી ${offer.endDate}" else "Valid: ${offer.startDate} to ${offer.endDate}"
                        else ->
                            if (isGu) "માન્યતા: ${offer.validTill}" else "Valid till: ${offer.validTill}"
                    }
                    Text(
                        text = dateLine,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextMuted
                    )
                }

                if (calculatedStudentDiscount != null && calculatedStudentDiscount > 0) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isAppliedToStudent) StatusSuccessContainer else PurpleContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isAppliedToStudent) {
                                    if (isGu) "તમારી ફીમાં ₹$calculatedStudentDiscount બચત લાગુ થઈ ગઈ ✓" else "₹$calculatedStudentDiscount discount applied to your fees ✓"
                                } else {
                                    if (isGu) "તમારા માટે મળવાપાત્ર બચત: ₹$calculatedStudentDiscount" else "Eligible savings for you: ₹$calculatedStudentDiscount"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAppliedToStudent) StatusSuccess else PurplePrimary
                            )
                        }
                    }
                }

                if (footerContent != null) {
                    footerContent()
                }
            }
        }
    }
}

@Composable
private fun OfferInfoPill(
    icon: ImageVector,
    text: String,
    bgColor: Color,
    fgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = fgColor, modifier = Modifier.size(13.dp))
            Text(
                text = text,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = fgColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
