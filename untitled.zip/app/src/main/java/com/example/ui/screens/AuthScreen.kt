package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.ApprovalStatusValues
import com.example.data.model.Student
import com.example.data.model.TeacherProfile
import com.example.data.repository.HDTuitionRepository
import com.example.ui.components.HDLogo
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class AuthSubScreen {
    OPENING,
    STUDENT_AUTH,
    TEACHER_AUTH,
    ADMIN_AUTH
}

enum class AuthMode {
    LOGIN, REGISTER
}

@Composable
fun AuthScreen(
    repository: HDTuitionRepository,
    onLoginSuccessStudent: (Student) -> Unit,
    onLoginSuccessTeacher: (TeacherProfile) -> Unit,
    onLoginSuccessAdmin: () -> Unit,
    onExploreWebsite: () -> Unit,
    onGoogleSignOut: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val currentLang by repository.currentLanguage.collectAsState()
    val isGu = currentLang == AppLanguage.GUJARATI

    var subScreen by remember { mutableStateOf(AuthSubScreen.OPENING) }

    AnimatedContent(
        targetState = subScreen,
        label = "AuthFlowTransition",
        modifier = modifier.fillMaxSize()
    ) { activeScreen ->
        when (activeScreen) {
            AuthSubScreen.OPENING -> OpeningPortalScreen(
                repository = repository,
                isGu = isGu,
                onToggleLanguage = { repository.toggleLanguage() },
                onSelectStudent = { subScreen = AuthSubScreen.STUDENT_AUTH },
                onSelectTeacher = { subScreen = AuthSubScreen.TEACHER_AUTH },
                onSelectAdmin = { subScreen = AuthSubScreen.ADMIN_AUTH },
                onExploreWebsite = onExploreWebsite,
                onGoogleSignOut = onGoogleSignOut
            )

            AuthSubScreen.STUDENT_AUTH -> StudentAuthView(
                repository = repository,
                isGu = isGu,
                onBack = { subScreen = AuthSubScreen.OPENING },
                onToggleLanguage = { repository.toggleLanguage() },
                onLoginSuccess = onLoginSuccessStudent
            )

            AuthSubScreen.TEACHER_AUTH -> TeacherAuthView(
                repository = repository,
                isGu = isGu,
                onBack = { subScreen = AuthSubScreen.OPENING },
                onToggleLanguage = { repository.toggleLanguage() },
                onLoginSuccess = onLoginSuccessTeacher
            )

            AuthSubScreen.ADMIN_AUTH -> AdminAuthView(
                repository = repository,
                isGu = isGu,
                onBack = { subScreen = AuthSubScreen.OPENING },
                onToggleLanguage = { repository.toggleLanguage() },
                onLoginSuccess = onLoginSuccessAdmin,
                onGoogleSignOut = onGoogleSignOut
            )
        }
    }
}

@Composable
private fun OpeningPortalScreen(
    repository: HDTuitionRepository,
    isGu: Boolean,
    onToggleLanguage: () -> Unit,
    onSelectStudent: () -> Unit,
    onSelectTeacher: () -> Unit,
    onSelectAdmin: () -> Unit,
    onExploreWebsite: () -> Unit,
    onGoogleSignOut: () -> Unit
) {
    val settings by repository.settings.collectAsState()
    val googleEmail = repository.currentAuthEmail() ?: ""

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(RoyalIndigoDark, RoyalIndigo, PurplePrimary)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar with Signed-in Google Badge & Language Switcher
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (googleEmail.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .clickable(onClick = onGoogleSignOut)
                            .testTag("opening_google_signout_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Google Account",
                                tint = GoldYellow,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = googleEmail,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 175.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Switch Google Account",
                                tint = GoldYellowLight,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, GoldYellow.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .clickable(onClick = onToggleLanguage)
                        .testTag("opening_lang_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language",
                            tint = GoldYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isGu) "ENG" else "ગુજરાતી",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Top Center Original Circular Logo
            Box(
                modifier = Modifier
                    .size(116.dp)
                    .shadow(16.dp, CircleShape, ambientColor = GoldYellow, spotColor = GoldYellow)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(3.5.dp, GoldYellow, CircleShape)
                    .padding(3.dp)
                    .testTag("opening_logo"),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hd_tuition_logo),
                    contentDescription = "HD Tuition Classes Official Logo",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = settings.businessName.ifBlank { "HD TUITION CLASSES" },
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = Color.White,
                letterSpacing = 1.2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("opening_app_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = RoundedCornerShape(50.dp),
                color = GoldYellow.copy(alpha = 0.18f),
                border = BorderStroke(1.dp, GoldYellow.copy(alpha = 0.65f))
            ) {
                Text(
                    text = if (isGu) "ધોરણ ૧ થી ૧૨ | તમામ વિષયો | ગુજરાતી માધ્યમ" else "Std 1 to 12 | All Subjects | Gujarati Medium",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldYellowLight,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isGu) {
                    "સંચાલક: ${settings.founderName.ifBlank { "Harshadsinh Rathod" }} • ${settings.contactPhone.ifBlank { "+91 85112 73911" }}"
                } else {
                    "Founder: ${settings.founderName.ifBlank { "Harshadsinh Rathod" }} • ${settings.contactPhone.ifBlank { "+91 85112 73911" }}"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Lower Crisp White / Gold Sheet containing the 3 Large Buttons
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                color = Color.White,
                shadowElevation = 12.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 22.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(44.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(GoldYellow)
                    )

                    Text(
                        text = if (isGu) "તમારું પોર્ટલ પસંદ કરો" else "Choose Your Portal",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = PurplePrimary
                    )

                    OpeningPortalActionCard(
                        title = "Student Login / Registration",
                        subtitle = if (isGu) "વિદ્યાર્થી લૉગિન અને નવું રજીસ્ટ્રેશન" else "New student sign up & student dashboard",
                        icon = Icons.Default.School,
                        containerBrush = Brush.horizontalGradient(listOf(PurplePrimary, PurpleVariant)),
                        borderColor = GoldYellow,
                        titleColor = Color.White,
                        subtitleColor = GoldYellowLight,
                        iconBgColor = GoldYellow,
                        iconTint = RoyalIndigoDark,
                        chevronTint = GoldYellow,
                        testTag = "opening_student_btn",
                        onClick = onSelectStudent
                    )

                    OpeningPortalActionCard(
                        title = "Teacher Login / Registration",
                        subtitle = if (isGu) "શિક્ષક લૉગિન અને ફેકલ્ટી રજીસ્ટ્રેશન" else "Faculty sign up, attendance & homework portal",
                        icon = Icons.Default.CoPresent,
                        containerBrush = Brush.horizontalGradient(listOf(PurpleSurface, Color.White)),
                        borderColor = PurpleMedium,
                        titleColor = PurplePrimary,
                        subtitleColor = TextMuted,
                        iconBgColor = PurplePrimary,
                        iconTint = GoldYellow,
                        chevronTint = PurplePrimary,
                        testTag = "opening_teacher_btn",
                        onClick = onSelectTeacher
                    )

                    OpeningPortalActionCard(
                        title = "Admin Login",
                        subtitle = if (isGu) "સંચાલક લૉગિન (માત્ર એડમિન માટે)" else "Owner & Administrator login only",
                        icon = Icons.Default.AdminPanelSettings,
                        containerBrush = Brush.horizontalGradient(listOf(GoldYellowContainer, Color.White)),
                        borderColor = GoldYellowDark,
                        titleColor = RoyalIndigoDark,
                        subtitleColor = GoldYellowDeep,
                        iconBgColor = RoyalIndigoDark,
                        iconTint = GoldYellow,
                        chevronTint = RoyalIndigoDark,
                        testTag = "opening_admin_btn",
                        onClick = onSelectAdmin
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedButton(
                        onClick = onExploreWebsite,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 50.dp)
                            .testTag("explore_website_btn"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            1.2.dp,
                            Brush.horizontalGradient(listOf(PurplePrimary, GoldYellowDark))
                        )
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGu) {
                                "વેબસાઇટ હોમપેજ જુઓ (કોર્સ & ₹${settings.advanceBookingAmount} સીટ બુકિંગ)"
                            } else {
                                "Explore Website (Courses & ₹${settings.advanceBookingAmount} Seat Booking)"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PurplePrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OpeningPortalActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    containerBrush: Brush,
    borderColor: Color,
    titleColor: Color,
    subtitleColor: Color,
    iconBgColor: Color,
    iconTint: Color,
    chevronTint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 84.dp)
            .shadow(6.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .border(1.5.dp, borderColor, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(containerBrush)
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = titleColor
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = subtitleColor
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = chevronTint,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

// ====================================================================
// STUDENT LOGIN / REGISTRATION VIEW
// ====================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudentAuthView(
    repository: HDTuitionRepository,
    isGu: Boolean,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onLoginSuccess: (Student) -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf(AuthMode.LOGIN) }
    var isLoading by remember { mutableStateOf(false) }

    // Login state
    var loginIdOrMobile by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginPasswordVisible by remember { mutableStateOf(false) }
    var showPasswordHelpDialog by remember { mutableStateOf(false) }

    // Registration state
    var regName by remember { mutableStateOf("") }
    var regParentName by remember { mutableStateOf("") }
    var regMobile by remember { mutableStateOf("") }
    var regStandard by remember { mutableStateOf("ધોરણ ૧૦ (Std 10)") }
    var regPassword by remember { mutableStateOf("") }
    var regConfirmPassword by remember { mutableStateOf("") }
    var regPasswordVisible by remember { mutableStateOf(false) }
    var regAddress by remember { mutableStateOf("") }
    var standardDropdownExpanded by remember { mutableStateOf(false) }
    var pendingRegisteredStudent by remember { mutableStateOf<Student?>(null) }

    val standardOptions = listOf(
        "ધોરણ ૧ (Std 1)", "ધોરણ ૨ (Std 2)", "ધોરણ ૩ (Std 3)",
        "ધોરણ ૪ (Std 4)", "ધોરણ ૫ (Std 5)", "ધોરણ ૬ (Std 6)",
        "ધોરણ ૭ (Std 7)", "ધોરણ ૮ (Std 8)", "ધોરણ ૯ (Std 9)",
        "ધોરણ ૧૦ (Std 10 GSEB)", "ધોરણ ૧૧ કોમર્સ (Std 11)",
        "ધોરણ ૧૨ કોમર્સ (Std 12)", "ધોરણ ૧૧ આર્ટસ (Std 11)",
        "ધોરણ ૧૨ આર્ટસ (Std 12)"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isGu) "વિદ્યાર્થી પોર્ટલ (Student)" else "Student Portal",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("student_auth_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    TextButton(onClick = onToggleLanguage) {
                        Text(if (isGu) "ENG" else "ગુજ", color = GoldYellow, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PurplePrimary)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HDLogo(size = 70.dp, showText = true)
            Spacer(modifier = Modifier.height(16.dp))

            AuthModeSwitcher(
                currentMode = mode,
                loginLabel = if (isGu) "વિદ્યાર્થી લૉગિન" else "Student Login",
                registerLabel = if (isGu) "નવું રજીસ્ટ્રેશન" else "Registration",
                onModeSelected = {
                    mode = it
                    pendingRegisteredStudent = null
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (mode == AuthMode.LOGIN) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (isGu) "હાલના વિદ્યાર્થી લૉગિન" else "Existing Student Login",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )

                        OutlinedTextField(
                            value = loginIdOrMobile,
                            onValueChange = { loginIdOrMobile = it },
                            label = { Text(if (isGu) "સ્ટુડન્ટ ID અથવા મોબાઇલ નંબર *" else "Student ID or Mobile *") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("student_auth_id_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            label = { Text(if (isGu) "પાસવર્ડ (Password) *" else "Password *") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                            trailingIcon = {
                                IconButton(onClick = { loginPasswordVisible = !loginPasswordVisible }) {
                                    Icon(
                                        if (loginPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (loginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("student_auth_password_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Text(
                                text = if (isGu) "પાસવર્ડ ભૂલી ગયા છો?" else "Forgot Password?",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PurplePrimary,
                                modifier = Modifier
                                    .clickable { showPasswordHelpDialog = true }
                                    .padding(4.dp)
                            )
                        }

                        Button(
                            onClick = {
                                if (loginIdOrMobile.isBlank() || loginPassword.isBlank()) {
                                    Toast.makeText(context, if (isGu) "કૃપા કરીને ID અને પાસવર્ડ લખો" else "Enter ID and password", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                scope.launch {
                                    isLoading = true
                                    val result = repository.authenticateStudent(loginIdOrMobile, loginPassword)
                                    isLoading = false
                                    result.onSuccess { student ->
                                        Toast.makeText(context, "સ્વાગત છે, ${student.name}!", Toast.LENGTH_SHORT).show()
                                        onLoginSuccess(student)
                                    }.onFailure { err ->
                                        Toast.makeText(
                                            context,
                                            err.message ?: if (isGu) "લૉગિન નિષ્ફળ!" else "Login failed",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 50.dp)
                                .testTag("student_auth_login_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isGu) "લૉગિન કરો (Login)" else "Login", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            } else if (pendingRegisteredStudent != null) {
                val created = pendingRegisteredStudent!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_pending_approval_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = GoldYellowDark,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = if (isGu) "રજીસ્ટ્રેશન સફળ! એડમિન મંજૂરી બાકી છે" else "Registration Submitted — Pending Approval",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = PurplePrimary,
                            textAlign = TextAlign.Center
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GoldYellowContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = if (isGu) "તમારો યુનિક સ્ટુડન્ટ ID (સાચવીને રાખો):" else "Your Unique Student ID (Save this):",
                                    fontSize = 11.sp,
                                    color = GoldYellowDeep
                                )
                                Text(
                                    text = created.id,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 22.sp,
                                    color = PurplePrimary
                                )
                            }
                        }
                        Text(
                            text = if (isGu) {
                                "વિદ્યાર્થી: ${created.name}\nધોરણ: ${created.standard}\nમોબાઇલ: ${created.mobileNumber}\n\nસંચાલક (Admin) તમારું એકાઉન્ટ મંજૂર (Approve) કરશે ત્યારબાદ તમે તમારા ID અને પાસવર્ડથી લૉગિન કરી શકશો."
                            } else {
                                "Student: ${created.name}\nStandard: ${created.standard}\nMobile: ${created.mobileNumber}\n\nOnce Admin approves your registration, you can log in using your Student ID and Password."
                            },
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = {
                                loginIdOrMobile = created.id
                                pendingRegisteredStudent = null
                                mode = AuthMode.LOGIN
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isGu) "લૉગિન પેજ પર જાઓ" else "Go to Login", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isGu) "નવું વિદ્યાર્થી રજીસ્ટ્રેશન" else "New Student Registration",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )

                        OutlinedTextField(
                            value = regName,
                            onValueChange = { regName = it },
                            label = { Text(if (isGu) "વિદ્યાર્થીનું પૂરું નામ *" else "Student Full Name *") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regParentName,
                            onValueChange = { regParentName = it },
                            label = { Text(if (isGu) "વાલીનું નામ *" else "Parent Name *") },
                            leadingIcon = { Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regMobile,
                            onValueChange = { if (it.length <= 10) regMobile = it.filter { ch -> ch.isDigit() } },
                            label = { Text(if (isGu) "મોબાઇલ નંબર *" else "Mobile Number *") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PurplePrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        ExposedDropdownMenuBox(
                            expanded = standardDropdownExpanded,
                            onExpandedChange = { standardDropdownExpanded = !standardDropdownExpanded },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = regStandard,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text(if (isGu) "ધોરણ (Standard) *" else "Standard *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = standardDropdownExpanded) },
                                leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = PurplePrimary) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = standardDropdownExpanded,
                                onDismissRequest = { standardDropdownExpanded = false }
                            ) {
                                standardOptions.forEach { std ->
                                    DropdownMenuItem(
                                        text = { Text(std) },
                                        onClick = {
                                            regStandard = std
                                            standardDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = regPassword,
                            onValueChange = { regPassword = it },
                            label = { Text(if (isGu) "તમારો પાસવર્ડ બનાવો *" else "Create Password *") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                            trailingIcon = {
                                IconButton(onClick = { regPasswordVisible = !regPasswordVisible }) {
                                    Icon(if (regPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                                }
                            },
                            visualTransformation = if (regPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regConfirmPassword,
                            onValueChange = { regConfirmPassword = it },
                            label = { Text(if (isGu) "પાસવર્ડ ફરી લખો *" else "Confirm Password *") },
                            leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null, tint = PurplePrimary) },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regAddress,
                            onValueChange = { regAddress = it },
                            label = { Text(if (isGu) "ગામ / સરનામું" else "Village / Address") },
                            leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = {
                                if (regName.isBlank() || regParentName.isBlank() || regMobile.length < 10 || regPassword.isBlank()) {
                                    Toast.makeText(context, if (isGu) "બધી જરૂરી વિગતો અને ૧૦ અંકનો મોબાઇલ લખો (*)" else "Fill all required fields and 10-digit mobile", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (regPassword != regConfirmPassword) {
                                    Toast.makeText(context, if (isGu) "પાસવર્ડ મેળ ખાતા નથી!" else "Passwords do not match", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (regPassword.length < 4) {
                                    Toast.makeText(context, if (isGu) "પાસવર્ડ ઓછામાં ઓછો ૪ અક્ષરનો રાખો" else "Password must be at least 4 characters", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                scope.launch {
                                    isLoading = true
                                    val result = repository.registerStudent(
                                        name = regName,
                                        parentName = regParentName,
                                        mobileNumber = regMobile,
                                        standard = regStandard,
                                        password = regPassword,
                                        address = regAddress.ifBlank { "કવિથા / બદરખા" }
                                    )
                                    isLoading = false
                                    result.onSuccess { newStudent ->
                                        if (newStudent.approvalStatus == ApprovalStatusValues.APPROVED) {
                                            Toast.makeText(context, "રજીસ્ટ્રેશન સફળ! ID: ${newStudent.id}", Toast.LENGTH_LONG).show()
                                            onLoginSuccess(newStudent)
                                        } else {
                                            pendingRegisteredStudent = newStudent
                                        }
                                    }.onFailure { err ->
                                        Toast.makeText(
                                            context,
                                            err.message ?: "Registration failed",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 50.dp)
                                .testTag("student_auth_register_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = RoyalIndigoDark, strokeWidth = 2.dp)
                            } else {
                                Text(
                                    text = if (isGu) "રજીસ્ટ્રેશન સબમિટ કરો" else "Submit Registration",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = RoyalIndigoDark
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPasswordHelpDialog) {
        AlertDialog(
            onDismissRequest = { showPasswordHelpDialog = false },
            title = {
                Text(
                    text = if (isGu) "પાસવર્ડ બદલવા / મદદ માટે" else "Password Help",
                    fontWeight = FontWeight.Bold,
                    color = PurplePrimary
                )
            },
            text = {
                Text(
                    text = if (isGu) {
                        "• જો તમારી પાસે હાલનો પાસવર્ડ છે, તો લૉગિન કર્યા પછી ડેશબોર્ડની 'પાસવર્ડ બદલો' સુવિધાનો ઉપયોગ કરો.\n• જો તમે પાસવર્ડ ભૂલી ગયા હોવ, તો કૃપા કરીને સંચાલક હર્ષદસિંહ સર (+91 85112 73911) નો સંપર્ક કરો જેથી એડમિન પેનલમાંથી પાસવર્ડ રિસેટ થઈ શકે."
                    } else {
                        "• If you know your password, log in and change it from your Student Dashboard.\n• If you forgot your password, please contact Admin (+91 85112 73911) to reset it securely."
                    },
                    fontSize = 13.sp,
                    color = TextDark
                )
            },
            confirmButton = {
                Button(
                    onClick = { showPasswordHelpDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text(if (isGu) "સમજાઈ ગયું" else "OK")
                }
            }
        )
    }
}

// ====================================================================
// TEACHER LOGIN / REGISTRATION VIEW
// ====================================================================
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun TeacherAuthView(
    repository: HDTuitionRepository,
    isGu: Boolean,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onLoginSuccess: (TeacherProfile) -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf(AuthMode.LOGIN) }
    var isLoading by remember { mutableStateOf(false) }

    // Teacher Login
    var loginIdOrMobile by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginPasswordVisible by remember { mutableStateOf(false) }

    // Teacher Registration
    var regName by remember { mutableStateOf("") }
    var regMobile by remember { mutableStateOf("") }
    var regSubjects by remember { mutableStateOf("") }
    var regQualification by remember { mutableStateOf("") }
    var regExperience by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regConfirmPassword by remember { mutableStateOf("") }
    var regPasswordVisible by remember { mutableStateOf(false) }
    var selectedStandards by remember { mutableStateOf(setOf("All")) }
    var pendingRegisteredTeacher by remember { mutableStateOf<TeacherProfile?>(null) }

    val availableStandards = listOf(
        "All", "Std 1", "Std 2", "Std 3", "Std 4", "Std 5", "Std 6",
        "Std 7", "Std 8", "Std 9", "Std 10", "Std 11", "Std 12"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isGu) "શિક્ષક પોર્ટલ (Teacher)" else "Teacher Portal",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("teacher_auth_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    TextButton(onClick = onToggleLanguage) {
                        Text(if (isGu) "ENG" else "ગુજ", color = GoldYellow, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PurpleMedium)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HDLogo(size = 70.dp, showText = true)
            Spacer(modifier = Modifier.height(16.dp))

            AuthModeSwitcher(
                currentMode = mode,
                loginLabel = if (isGu) "શિક્ષક લૉગિન" else "Teacher Login",
                registerLabel = if (isGu) "શિક્ષક રજીસ્ટ્રેશન" else "Registration",
                onModeSelected = {
                    mode = it
                    pendingRegisteredTeacher = null
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (mode == AuthMode.LOGIN) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (isGu) "શિક્ષક / ફેકલ્ટી લૉગિન" else "Existing Teacher Login",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )

                        OutlinedTextField(
                            value = loginIdOrMobile,
                            onValueChange = { loginIdOrMobile = it },
                            label = { Text(if (isGu) "શિક્ષક ID અથવા મોબાઇલ નંબર *" else "Teacher ID or Mobile *") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("teacher_auth_id_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            label = { Text(if (isGu) "પાસવર્ડ (Password) *" else "Password *") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                            trailingIcon = {
                                IconButton(onClick = { loginPasswordVisible = !loginPasswordVisible }) {
                                    Icon(
                                        if (loginPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (loginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("teacher_auth_password_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (loginIdOrMobile.isBlank() || loginPassword.isBlank()) {
                                    Toast.makeText(context, if (isGu) "કૃપા કરીને ID અને પાસવર્ડ લખો" else "Enter ID and password", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                scope.launch {
                                    isLoading = true
                                    val result = repository.authenticateTeacher(loginIdOrMobile, loginPassword)
                                    isLoading = false
                                    result.onSuccess { teacher ->
                                        Toast.makeText(context, "સ્વાગત છે, ${teacher.name}!", Toast.LENGTH_SHORT).show()
                                        onLoginSuccess(teacher)
                                    }.onFailure { err ->
                                        Toast.makeText(
                                            context,
                                            err.message ?: if (isGu) "લૉગિન નિષ્ફળ!" else "Login failed",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 50.dp)
                                .testTag("teacher_auth_login_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isGu) "લૉગિન કરો (Login)" else "Login", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            } else if (pendingRegisteredTeacher != null) {
                val created = pendingRegisteredTeacher!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("teacher_pending_approval_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = GoldYellowDark,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = if (isGu) "શિક્ષક રજીસ્ટ્રેશન સફળ! એડમિન મંજૂરી બાકી" else "Teacher Registered — Pending Admin Approval",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = PurplePrimary,
                            textAlign = TextAlign.Center
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PurpleContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = if (isGu) "તમારો યુનિક ટીચર ID (સાચવીને રાખો):" else "Your Unique Teacher ID:",
                                    fontSize = 11.sp,
                                    color = PurplePrimary
                                )
                                Text(
                                    text = created.teacherId,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 22.sp,
                                    color = PurplePrimary
                                )
                            }
                        }
                        Text(
                            text = if (isGu) {
                                "નામ: ${created.name}\nવિષયો: ${created.subjects}\nધોરણ: ${created.assignedStandards.joinToString(", ")}\n\nસંચાલક (Admin) તમારું એકાઉન્ટ મંજૂર (Approve) કરશે ત્યારબાદ તમે લૉગિન કરી શકશો."
                            } else {
                                "Name: ${created.name}\nSubjects: ${created.subjects}\nStandards: ${created.assignedStandards.joinToString(", ")}\n\nYou can log in as soon as Admin approves your profile."
                            },
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = {
                                loginIdOrMobile = created.teacherId
                                pendingRegisteredTeacher = null
                                mode = AuthMode.LOGIN
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleMedium),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isGu) "લૉગિન પેજ પર જાઓ" else "Go to Login", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isGu) "નવું શિક્ષક રજીસ્ટ્રેશન" else "New Teacher Registration",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )

                        OutlinedTextField(
                            value = regName,
                            onValueChange = { regName = it },
                            label = { Text(if (isGu) "શિક્ષકનું પૂરું નામ *" else "Teacher Full Name *") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regMobile,
                            onValueChange = { if (it.length <= 10) regMobile = it.filter { ch -> ch.isDigit() } },
                            label = { Text(if (isGu) "મોબાઇલ નંબર *" else "Mobile Number *") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PurplePrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regSubjects,
                            onValueChange = { regSubjects = it },
                            label = { Text(if (isGu) "ભણાવવાના વિષયો *" else "Subjects Taught *") },
                            leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Text(
                            text = if (isGu) "ભણાવવાના ધોરણ પસંદ કરો:" else "Select Standards Taught:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = PurplePrimary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableStandards.forEach { std ->
                                val isSelected = std in selectedStandards
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedStandards = if (std == "All") {
                                            setOf("All")
                                        } else {
                                            val withoutAll = selectedStandards - "All"
                                            val next = if (std in withoutAll) withoutAll - std else withoutAll + std
                                            if (next.isEmpty()) setOf("All") else next
                                        }
                                    },
                                    label = { Text(std, fontSize = 11.sp) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = regQualification,
                            onValueChange = { regQualification = it },
                            label = { Text(if (isGu) "લાયકાત (દા.ત. M.Sc, B.Ed)" else "Qualification") },
                            leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regExperience,
                            onValueChange = { regExperience = it },
                            label = { Text(if (isGu) "અનુભવ (દા.ત. ૫ વર્ષ)" else "Experience") },
                            leadingIcon = { Icon(Icons.Default.WorkHistory, contentDescription = null, tint = PurplePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regPassword,
                            onValueChange = { regPassword = it },
                            label = { Text(if (isGu) "તમારો પાસવર્ડ બનાવો *" else "Create Password *") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                            trailingIcon = {
                                IconButton(onClick = { regPasswordVisible = !regPasswordVisible }) {
                                    Icon(if (regPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                                }
                            },
                            visualTransformation = if (regPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = regConfirmPassword,
                            onValueChange = { regConfirmPassword = it },
                            label = { Text(if (isGu) "પાસવર્ડ ફરી લખો *" else "Confirm Password *") },
                            leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null, tint = PurplePrimary) },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = {
                                if (regName.isBlank() || regMobile.length < 10 || regSubjects.isBlank() || regPassword.isBlank()) {
                                    Toast.makeText(context, if (isGu) "નામ, ૧૦ અંકનો મોબાઇલ, વિષય અને પાસવર્ડ લખો (*)" else "Fill name, 10-digit mobile, subjects and password", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (regPassword != regConfirmPassword) {
                                    Toast.makeText(context, if (isGu) "પાસવર્ડ મેળ ખાતા નથી!" else "Passwords do not match", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (regPassword.length < 4) {
                                    Toast.makeText(context, if (isGu) "પાસવર્ડ ઓછામાં ઓછો ૪ અક્ષરનો રાખો" else "Password must be at least 4 characters", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                scope.launch {
                                    isLoading = true
                                    val result = repository.registerTeacher(
                                        name = regName,
                                        mobileNumber = regMobile,
                                        subjects = regSubjects,
                                        qualification = regQualification,
                                        experience = regExperience,
                                        password = regPassword,
                                        assignedStandards = selectedStandards.toList()
                                    )
                                    isLoading = false
                                    result.onSuccess { newTeacher ->
                                        if (newTeacher.approvalStatus == ApprovalStatusValues.APPROVED) {
                                            Toast.makeText(context, "શિક્ષક રજીસ્ટ્રેશન સફળ! ID: ${newTeacher.teacherId}", Toast.LENGTH_LONG).show()
                                            onLoginSuccess(newTeacher)
                                        } else {
                                            pendingRegisteredTeacher = newTeacher
                                        }
                                    }.onFailure { err ->
                                        Toast.makeText(context, err.message ?: "Registration failed", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 50.dp)
                                .testTag("teacher_auth_register_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldYellow),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = RoyalIndigoDark, strokeWidth = 2.dp)
                            } else {
                                Text(
                                    text = if (isGu) "શિક્ષક રજીસ્ટ્રેશન સબમિટ કરો" else "Submit Teacher Registration",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = RoyalIndigoDark
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ====================================================================
// ADMIN LOGIN & SECURE ONE-TIME OWNER ADMIN SETUP
// ====================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminAuthView(
    repository: HDTuitionRepository,
    isGu: Boolean,
    onBack: () -> Unit,
    onToggleLanguage: () -> Unit,
    onLoginSuccess: () -> Unit,
    onGoogleSignOut: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isAdminSetupComplete by repository.isAdminSetupComplete.collectAsState()
    val isOwnerGoogleUser = repository.isCurrentUserOwner()
    val signedInEmail = repository.currentAuthEmail().orEmpty()

    LaunchedEffect(Unit) {
        repository.refreshAdminSetupState()
    }

    var adminIdentifier by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    var showOwnerSetupDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isGu) "એડમિન લૉગિન (Admin Only)" else "Admin Login",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_auth_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    TextButton(onClick = onToggleLanguage) {
                        Text(if (isGu) "ENG" else "ગુજ", color = GoldYellow, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = RoyalIndigoDark)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(84.dp)
                    .clip(CircleShape)
                    .background(RoyalIndigoDark)
                    .border(2.5.dp, GoldYellow, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Login",
                    tint = GoldYellow,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "HD TUITION CLASSES",
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                color = PurplePrimary
            )
            Text(
                text = if (isGu) "સંચાલક નિયંત્રણ પેનલ — માત્ર ઓનર લૉગિન" else "Owner & Administrator Login Only",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (!isOwnerGoogleUser) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_owner_required_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = StatusErrorContainer),
                    border = BorderStroke(1.dp, StatusError.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = StatusError)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGu) "માત્ર ઓનર ગૂગલ એકાઉન્ટ જ માન્ય છે" else "Authorized Owner Google Account Required",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = StatusError
                            )
                        }
                        Text(
                            text = if (isGu) {
                                "હાલમાં સાઇન ઇન કરેલ Google એકાઉન્ટ: ${signedInEmail.ifBlank { "Unknown" }}\n\nએડમિન પેનલ ખોલવા માટે માત્ર સંસ્થાના માલિકના વેરિફાઇડ Google એકાઉન્ટ (${HDTuitionRepository.OWNER_EMAIL}) થી સાઇન ઇન કરવું ફરજિયાત છે."
                            } else {
                                "Signed in as: ${signedInEmail.ifBlank { "Unknown" }}\n\nOnly verified owner Google account (${HDTuitionRepository.OWNER_EMAIL}) can initialize or log into Admin Panel."
                            },
                            fontSize = 12.sp,
                            color = TextDark
                        )
                        Button(
                            onClick = onGoogleSignOut,
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalIndigoDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_switch_google_btn")
                        ) {
                            Icon(Icons.Default.SwitchAccount, contentDescription = null, tint = GoldYellow)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGu) "Google એકાઉન્ટ બદલો (Switch Account)" else "Switch Google Account",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGu) "સુરક્ષિત એડમિન લૉગિન" else "Secure Admin Login",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = PurplePrimary
                        )
                    }

                    OutlinedTextField(
                        value = adminIdentifier,
                        onValueChange = { adminIdentifier = it },
                        label = { Text(if (isGu) "એડમિન ID અથવા મોબાઇલ નંબર *" else "Admin ID or Mobile Number *") },
                        leadingIcon = { Icon(Icons.Default.AccountCircle, contentDescription = null, tint = PurplePrimary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_auth_id_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = adminPassword,
                        onValueChange = { adminPassword = it },
                        label = { Text(if (isGu) "પાસવર્ડ (Password) *" else "Password *") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_auth_password_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            if (!isOwnerGoogleUser) {
                                Toast.makeText(context, "કૃપા કરીને પહેલા ઓનર Google એકાઉન્ટથી સાઇન ઇન કરો.", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            if (!isAdminSetupComplete) {
                                Toast.makeText(
                                    context,
                                    if (isGu) "સૌપ્રથમ નીચે આપેલ ઓનર સેટઅપ દ્વારા પ્રથમ એડમિન એકાઉન્ટ બનાવો." else "Complete the one-time Owner Admin setup first.",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@Button
                            }
                            scope.launch {
                                isLoading = true
                                val result = repository.authenticateAdmin(adminIdentifier, adminPassword)
                                isLoading = false
                                result.onSuccess {
                                    Toast.makeText(context, "સ્વાગત છે! એડમિન પેનલ સક્રિય છે.", Toast.LENGTH_SHORT).show()
                                    onLoginSuccess()
                                }.onFailure { err ->
                                    Toast.makeText(context, err.message ?: "Invalid Admin ID or Password", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        enabled = !isLoading && isOwnerGoogleUser,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 50.dp)
                            .testTag("admin_auth_login_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalIndigoDark),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = GoldYellow, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null, tint = GoldYellow)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGu) "એડમિન ડેશબોર્ડ ખોલો (Login)" else "Access Admin Dashboard",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            if (isOwnerGoogleUser && !isAdminSetupComplete) {
                Spacer(modifier = Modifier.height(18.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("owner_one_time_setup_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldYellowContainer),
                    border = BorderStroke(1.2.dp, GoldYellowDark)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = RoyalIndigoDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGu) "ઓનર વન-ટાઇમ એડમિન સેટઅપ" else "Owner One-Time Admin Setup",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = RoyalIndigoDark
                            )
                        }
                        Text(
                            text = if (isGu) {
                                "હજુ સુધી કોઈ એડમિન એકાઉન્ટ સેટ કરેલ નથી. માત્ર અધિકૃત સંસ્થા માલિક જ પ્રથમ એડમિન એકાઉન્ટ બનાવી શકે છે. એકવાર એકાઉન્ટ બન્યા પછી આ વિકલ્પ કાયમ માટે બંધ થઈ જશે."
                            } else {
                                "No Admin account has been initialized yet. Only the authorized owner can create the first Admin account. Once created, this setup is permanently disabled."
                            },
                            fontSize = 12.sp,
                            color = TextDark
                        )
                        Button(
                            onClick = { showOwnerSetupDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("open_owner_setup_btn")
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, tint = GoldYellow, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGu) "અધિકૃત માલિક સેટઅપ શરૂ કરો" else "Start Owner Admin Setup",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else if (isAdminSetupComplete) {
                Spacer(modifier = Modifier.height(16.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PurpleContainer.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = PurplePrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGu) "સુરક્ષા નોંધ: જાહેર એડમિન રજીસ્ટ્રેશન કાયમ માટે બંધ છે. માત્ર સંચાલક લૉગિન ઉપલબ્ધ છે."
                            else "Security Notice: Public Admin registration is permanently disabled. Admin Login only.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PurplePrimary
                        )
                    }
                }
            }
        }
    }

    if (showOwnerSetupDialog && isOwnerGoogleUser && !isAdminSetupComplete) {
        var ownerVerification by remember { mutableStateOf("") }
        var ownerName by remember { mutableStateOf("Harshadsinh Rathod") }
        var newAdminIdOrMobile by remember { mutableStateOf("") }
        var newAdminPassword by remember { mutableStateOf("") }
        var confirmAdminPassword by remember { mutableStateOf("") }
        var setupPasswordVisible by remember { mutableStateOf(false) }
        var setupBusy by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!setupBusy) showOwnerSetupDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = PurplePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isGu) "ઓનર એડમિન સેટઅપ (One-Time)" else "One-Time Owner Setup",
                        fontWeight = FontWeight.Bold,
                        color = PurplePrimary,
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (isGu) "આગળ વધવા માટે સંસ્થાના માલિકનો અધિકૃત મોબાઇલ નંબર અથવા ઈમેલ ચકાસો:" else "Verify authorized owner mobile number or email:",
                        fontSize = 12.sp,
                        color = TextMuted
                    )

                    OutlinedTextField(
                        value = ownerVerification,
                        onValueChange = { ownerVerification = it },
                        label = { Text(if (isGu) "અધિકૃત માલિક મોબાઇલ / ઈમેલ *" else "Authorized Owner Mobile / Email *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_verify_input")
                    )

                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text(if (isGu) "સંચાલકનું નામ *" else "Owner Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newAdminIdOrMobile,
                        onValueChange = { newAdminIdOrMobile = it },
                        label = { Text(if (isGu) "એડમિન લૉગિન મોબાઇલ અથવા ID *" else "Admin Login Mobile or ID *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_setup_admin_id_input")
                    )

                    OutlinedTextField(
                        value = newAdminPassword,
                        onValueChange = { newAdminPassword = it },
                        label = { Text(if (isGu) "એડમિન પાસવર્ડ બનાવો (ઓછામાં ઓછા ૪ અક્ષર) *" else "Create Admin Password *") },
                        trailingIcon = {
                            IconButton(onClick = { setupPasswordVisible = !setupPasswordVisible }) {
                                Icon(if (setupPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                            }
                        },
                        visualTransformation = if (setupPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_setup_password_input")
                    )

                    OutlinedTextField(
                        value = confirmAdminPassword,
                        onValueChange = { confirmAdminPassword = it },
                        label = { Text(if (isGu) "પાસવર્ડ કન્ફર્મ કરો *" else "Confirm Password *") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!repository.verifyAuthorizedOwner(ownerVerification)) {
                            Toast.makeText(
                                context,
                                if (isGu) "અધિકૃત માલિક ચકાસણી નિષ્ફળ! માત્ર માલિક જ એડમિન બનાવી શકે છે." else "Owner verification failed! Only authorized owner can initialize Admin.",
                                Toast.LENGTH_LONG
                            ).show()
                            return@Button
                        }
                        if (newAdminIdOrMobile.isBlank() || newAdminPassword.length < 4) {
                            Toast.makeText(context, if (isGu) "માન્ય ID અને ઓછામાં ઓછો ૪ અક્ષરનો પાસવર્ડ લખો" else "Enter valid ID and 4+ char password", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (newAdminPassword != confirmAdminPassword) {
                            Toast.makeText(context, if (isGu) "પાસવર્ડ મેળ ખાતા નથી!" else "Passwords do not match!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        scope.launch {
                            setupBusy = true
                            val result = repository.completeOneTimeOwnerAdminSetup(
                                ownerVerification = ownerVerification,
                                adminMobileOrId = newAdminIdOrMobile,
                                pass = newAdminPassword,
                                founderName = ownerName
                            )
                            setupBusy = false
                            result.onSuccess {
                                showOwnerSetupDialog = false
                                Toast.makeText(context, "પ્રથમ એડમિન એકાઉન્ટ સફળતાપૂર્વક બની ગયું! પબ્લિક રજીસ્ટ્રેશન હવે કાયમ બંધ છે.", Toast.LENGTH_LONG).show()
                                onLoginSuccess()
                            }.onFailure { err ->
                                Toast.makeText(context, err.message ?: "Setup failed", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !setupBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    modifier = Modifier.testTag("owner_setup_confirm_btn")
                ) {
                    if (setupBusy) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Text(if (isGu) "એડમિન એકાઉન્ટ બનાવો" else "Create Admin Account")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showOwnerSetupDialog = false }, enabled = !setupBusy) {
                    Text(if (isGu) "રદ કરો" else "Cancel")
                }
            }
        )
    }
}

@Composable
private fun AuthModeSwitcher(
    currentMode: AuthMode,
    loginLabel: String,
    registerLabel: String,
    onModeSelected: (AuthMode) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(30.dp),
        color = PurpleContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(26.dp))
                    .background(if (currentMode == AuthMode.LOGIN) PurplePrimary else Color.Transparent)
                    .clickable { onModeSelected(AuthMode.LOGIN) }
                    .padding(vertical = 11.dp)
                    .testTag("tab_auth_login"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = loginLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (currentMode == AuthMode.LOGIN) Color.White else PurplePrimary
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(26.dp))
                    .background(if (currentMode == AuthMode.REGISTER) PurplePrimary else Color.Transparent)
                    .clickable { onModeSelected(AuthMode.REGISTER) }
                    .padding(vertical = 11.dp)
                    .testTag("tab_auth_register"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = registerLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (currentMode == AuthMode.REGISTER) Color.White else PurplePrimary
                )
            }
        }
    }
}
