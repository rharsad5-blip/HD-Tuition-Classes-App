package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FeeReceipt
import com.example.ui.theme.*

@Composable
fun OfficialReceiptCard(
    receipt: FeeReceipt,
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val isSuccess = receipt.paymentStatus == "SUCCESS"
    val isPending = receipt.paymentStatus == "PENDING_VERIFICATION"

    val statusBg = when {
        isSuccess -> StatusSuccessContainer
        isPending -> StatusWarningContainer
        else -> StatusErrorContainer
    }
    val statusColor = when {
        isSuccess -> StatusSuccess
        isPending -> StatusWarning
        else -> StatusError
    }
    val statusIcon = when {
        isSuccess -> Icons.Default.CheckCircle
        isPending -> Icons.Default.HourglassTop
        else -> Icons.Default.Cancel
    }
    val statusLabel = when (receipt.paymentStatus) {
        "SUCCESS" -> "FEES PAID & VERIFIED"
        "PENDING_VERIFICATION" -> "PENDING ADMIN VERIFICATION"
        else -> "PAYMENT ${receipt.paymentStatus}"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("official_receipt_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HDLogo(size = 42.dp)
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "HD TUITION CLASSES",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = PurplePrimary
                    )
                    Text(
                        text = "સત્તાવાર ફી પાવતી (Fee Receipt)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldYellowDark
                    )
                    Text(
                        text = "મો. +91 85112 73911",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = BorderSubtle,
                thickness = 1.dp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "પાવતી નંબર / Receipt No", fontSize = 10.sp, color = TextMuted)
                    Text(
                        text = receipt.receiptNo,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "તારીખ / Date", fontSize = 10.sp, color = TextMuted)
                    Text(
                        text = receipt.paymentDate,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = BackgroundLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    ReceiptRow(label = "વિદ્યાર્થીનું નામ (Student):", value = receipt.studentName)
                    ReceiptRow(label = "વિદ્યાર્થી આઈડી (ID):", value = receipt.studentId)
                    ReceiptRow(label = "ધોરણ (Standard):", value = receipt.standard)
                    ReceiptRow(label = "ચૂકવણી પદ્ધતિ (Mode):", value = receipt.paymentMode)
                    ReceiptRow(label = "ટ્રાન્ઝેક્શન સંદર્ભ (Ref):", value = receipt.transactionRef)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PurpleContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "કુલ વાર્ષિક ફી (Total Fee):",
                            fontSize = 13.sp,
                            color = PurplePrimary
                        )
                        Text(
                            text = "₹${receipt.totalFees}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PurplePrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSuccess) "ભરેલ રકમ (Amount Paid):" else "રકમ (Submitted Amount):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = statusColor
                        )
                        Text(
                            text = "₹${receipt.amountPaid}",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = statusColor
                        )
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = PurplePrimary.copy(alpha = 0.2f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "બાકી રહેતી ફી (Remaining Balance):",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (receipt.remainingBalance > 0) StatusWarning else StatusSuccess
                        )
                        Text(
                            text = "₹${receipt.remainingBalance}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (receipt.remainingBalance > 0) StatusWarning else StatusSuccess
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(statusBg)
                        .border(1.dp, statusColor, RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = statusIcon,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = statusLabel,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = statusColor
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = receipt.issuedBy.ifBlank { "Harshadsinh Rathod" },
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic,
                        fontSize = 13.sp,
                        color = PurplePrimary
                    )
                    Text(
                        text = "સત્તાવાર સહી / Authorized Signatory",
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val shareText = """
                            *HD TUITION CLASSES - FEE RECEIPT*
                            Receipt No: ${receipt.receiptNo}
                            Status: $statusLabel
                            Student: ${receipt.studentName} (${receipt.studentId})
                            Standard: ${receipt.standard}
                            Amount: ₹${receipt.amountPaid}
                            Date: ${receipt.paymentDate}
                            Payment Mode: ${receipt.paymentMode}
                            Ref: ${receipt.transactionRef}
                            Remaining Balance: ₹${receipt.remainingBalance}
                            Issued By: ${receipt.issuedBy.ifBlank { "Harshadsinh Rathod" }}
                        """.trimIndent()

                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, shareText)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "શેર કરો ફી પાવતી"))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("share_receipt_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("પાવતી શેર કરો (Share)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                if (onDismiss != null) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("close_receipt_btn")
                    ) {
                        Text("બંધ કરો", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = TextMuted)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
    }
}
