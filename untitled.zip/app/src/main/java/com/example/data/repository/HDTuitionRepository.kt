package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.*
import com.example.data.remote.OperationType
import com.example.data.remote.PasswordHasher
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HDTuitionRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    companion object {
        private const val TAG = "HDTuitionRepository"
        const val OWNER_EMAIL = "rharsad5@gmail.com"
        const val OWNER_PHONE_10 = "8511273911"
        const val SETTINGS_DOC_ID = "public"

        fun standardAnnualFee(standard: String): Int {
            val stdNum = standard.filter { it.isDigit() }.toIntOrNull() ?: 10
            return when (stdNum) {
                in 1..3 -> 3599
                in 4..5 -> 5999
                in 6..8 -> 9599
                9 -> 10799
                10 -> 11999
                11 -> 14399
                12 -> 15999
                else -> 11999
            }
        }

        fun extractStandardNumber(standard: String): String {
            return extractNormalizedStandardNumber(standard)
        }
    }

    private val activeListeners = mutableListOf<ListenerRegistration>()
    private var activeBaseUid: String? = null

    private val _currentLanguage = MutableStateFlow(AppLanguage.GUJARATI)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.GUJARATI) {
            AppLanguage.ENGLISH
        } else {
            AppLanguage.GUJARATI
        }
    }

    // ==========================================
    // LIVE STATE FLOWS (BACKED BY FIRESTORE)
    // ==========================================
    private val _adminAccount = MutableStateFlow<AdminAccount?>(null)
    val adminAccount: StateFlow<AdminAccount?> = _adminAccount.asStateFlow()

    private val _isAdminSetupComplete = MutableStateFlow(false)
    val isAdminSetupComplete: StateFlow<Boolean> = _isAdminSetupComplete.asStateFlow()

    private val _students = MutableStateFlow<List<Student>>(emptyList())
    val students: StateFlow<List<Student>> = _students.asStateFlow()

    private val _admissions = MutableStateFlow<List<AdmissionInquiry>>(emptyList())
    val admissions: StateFlow<List<AdmissionInquiry>> = _admissions.asStateFlow()

    private val _advanceBookings = MutableStateFlow<List<AdvanceBooking>>(emptyList())
    val advanceBookings: StateFlow<List<AdvanceBooking>> = _advanceBookings.asStateFlow()

    private val _attendance = MutableStateFlow<List<AttendanceRecord>>(emptyList())
    val attendance: StateFlow<List<AttendanceRecord>> = _attendance.asStateFlow()

    private val _homework = MutableStateFlow<List<HomeworkItem>>(emptyList())
    val homework: StateFlow<List<HomeworkItem>> = _homework.asStateFlow()

    private val _homeworkSubmissions = MutableStateFlow<List<HomeworkSubmission>>(emptyList())
    val homeworkSubmissions: StateFlow<List<HomeworkSubmission>> = _homeworkSubmissions.asStateFlow()

    private val _examResults = MutableStateFlow<List<ExamResult>>(emptyList())
    val examResults: StateFlow<List<ExamResult>> = _examResults.asStateFlow()

    private val _receipts = MutableStateFlow<List<FeeReceipt>>(emptyList())
    val receipts: StateFlow<List<FeeReceipt>> = _receipts.asStateFlow()

    private val _timetable = MutableStateFlow<List<TimetableSlot>>(emptyList())
    val timetable: StateFlow<List<TimetableSlot>> = _timetable.asStateFlow()

    private val _announcements = MutableStateFlow<List<AnnouncementItem>>(emptyList())
    val announcements: StateFlow<List<AnnouncementItem>> = _announcements.asStateFlow()

    private val _offers = MutableStateFlow<List<SpecialOffer>>(emptyList())
    val offers: StateFlow<List<SpecialOffer>> = _offers.asStateFlow()

    private val _offerHistory = MutableStateFlow<List<OfferHistoryEntry>>(emptyList())
    val offerHistory: StateFlow<List<OfferHistoryEntry>> = _offerHistory.asStateFlow()

    private val _teachers = MutableStateFlow<List<TeacherProfile>>(emptyList())
    val teachers: StateFlow<List<TeacherProfile>> = _teachers.asStateFlow()

    private val _publicFaculty = MutableStateFlow<List<PublicFaculty>>(emptyList())
    val publicFaculty: StateFlow<List<PublicFaculty>> = _publicFaculty.asStateFlow()

    private val _toppers = MutableStateFlow<List<TopperResult>>(emptyList())
    val toppers: StateFlow<List<TopperResult>> = _toppers.asStateFlow()

    private val _settings = MutableStateFlow(TuitionSettings(id = SETTINGS_DOC_ID))
    val settings: StateFlow<TuitionSettings> = _settings.asStateFlow()

    // Official fee catalog (static institutional curriculum & pricing, not user records)
    val courses = listOf(
        CourseCardInfo(
            standardRange = "ધોરણ ૧ થી ૩ (Std 1 to 3)",
            titleGujarati = "પ્રાથમિક પાયો (Primary Foundation)",
            titleEnglish = "Primary Foundation (Std 1 to 3)",
            subjects = listOf("ગુજરાતી", "ગણિત", "પર્યાવરણ", "અંગ્રેજી પાયો", "સુંદર અક્ષરો"),
            feeMonthly = 350,
            feeAnnual = 3599,
            descriptionGujarati = "બાળકોમાં વાંચન, ગણન અને લેખનનો મજબૂત પાયો તૈયાર કરવો.",
            descriptionEnglish = "Solid foundation in Reading, Writing and Arithmetic with personal care.",
            features = listOf("મર્યાદિત ૧૫ બાળકોની બેચ", "સુંદર અક્ષર સુધારણા", "દૈનિક હોમવર્ક સહાય")
        ),
        CourseCardInfo(
            standardRange = "ધોરણ ૪ થી ૫ (Std 4 to 5)",
            titleGujarati = "અપર પ્રાથમિક બેચ (Upper Primary)",
            titleEnglish = "Upper Primary (Std 4 to 5)",
            subjects = listOf("ગુજરાતી", "ગણિત", "પર્યાવરણ", "અંગ્રેજી ગ્રામર", "હિન્દી"),
            feeMonthly = 550,
            feeAnnual = 5999,
            descriptionGujarati = "નવોદય અને સ્કોલરશીપ પરીક્ષાઓની પાયાની તૈયારી સાથે તમામ વિષયો.",
            descriptionEnglish = "Complete syllabus with Navodaya and scholarship basics.",
            features = listOf("દર શનિવારે ટેસ્ટ", "વ્યક્તિગત ધ્યાન", "વાલી મીટિંગ")
        ),
        CourseCardInfo(
            standardRange = "ધોરણ ૬ થી ૮ (Std 6 to 8)",
            titleGujarati = "મિડલ સ્કૂલ એક્સિલન્સ (Middle School)",
            titleEnglish = "Middle School Excellence (Std 6 to 8)",
            subjects = listOf("ગણિત", "વિજ્ઞાન", "સામાજિક વિજ્ઞાન", "અંગ્રેજી ગ્રામર", "ગુજરાતી"),
            feeMonthly = 900,
            feeAnnual = 9599,
            descriptionGujarati = "ધોરણ ૧૦ બોર્ડ માટેનો પૂર્વ પાયો. વિજ્ઞાન અને ગણિતના કોન્સેપ્ટ્સ સરળ પદ્ધતિથી.",
            descriptionEnglish = "Pre-board foundation preparing students with deep conceptual science and maths.",
            features = listOf("સાપ્તાહિક યુનિટ ટેસ્ટ", "અંગ્રેજી ગ્રામર વિશેષ ધ્યાન", "વાલી મીટિંગ")
        ),
        CourseCardInfo(
            standardRange = "ધોરણ ૯ અને ૧૦ (Std 9 & 10 GSEB)",
            titleGujarati = "બોર્ડ સ્પેશિયલ બેચ (Board Topper Batch)",
            titleEnglish = "GSEB Board Special Batch (Std 9 ₹10,799 / Std 10 ₹11,999)",
            subjects = listOf("ગણિત (Maths)", "વિજ્ઞાન (Science)", "સામાજિક વિજ્ઞાન (SS)", "અંગ્રેજી (English)", "ગુજરાતી/સંસ્કૃત"),
            feeMonthly = 1100,
            feeAnnual = 11999,
            descriptionGujarati = "ધોરણ ૯: ₹10,799/વર્ષ • ધોરણ ૧૦: ₹11,999/વર્ષ. GSEB બોર્ડ પરીક્ષાની સંપૂર્ણ તૈયારી.",
            descriptionEnglish = "Std 9: ₹10,799/yr • Std 10: ₹11,999/yr. Complete GSEB Board preparation & paper solutions.",
            features = listOf("૧૦ વર્ષના બોર્ડ પેપર સોલ્વિંગ", "દર રવિવારે OMR & લેખિત ટેસ્ટ", "હર્ષદસિંહ સરનું સીધું માર્ગદર્શન")
        ),
        CourseCardInfo(
            standardRange = "ધોરણ ૧૧ અને ૧૨ (Std 11 & 12)",
            titleGujarati = "કોમર્સ & આર્ટ્સ માસ્ટર્સ (Higher Secondary)",
            titleEnglish = "Std 11 (₹14,399) & Std 12 (₹15,999)",
            subjects = listOf("નામાના મૂળતત્વો (Accounts)", "આંકડાશાસ્ત્ર (Statistics)", "અર્થશાસ્ત્ર (Economics)", "વાણિજ્ય વ્યવસ્થા (B.A.)", "અંગ્રેજી"),
            feeMonthly = 1500,
            feeAnnual = 15999,
            descriptionGujarati = "ધોરણ ૧૧: ₹14,399/વર્ષ • ધોરણ ૧૨: ₹15,999/વર્ષ. નામાના મૂળતત્વો અને આંકડાશાસ્ત્રમાં વિશેષ તૈયારી.",
            descriptionEnglish = "Std 11: ₹14,399/yr • Std 12: ₹15,999/yr. Accounts & Statistics board mastery.",
            features = listOf("પ્રેક્ટિકલ એકાઉન્ટિંગ જ્ઞાન", "બોર્ડ ટોપર્સ સ્પેશિયલ રિવિઝન", "પર્સનલ ડાઉટ સેશન")
        )
    )

    // ==========================================
    // AUTH HELPERS & ROLE-SCOPED LISTENERS
    // ==========================================
    fun currentAuthUid(): String? = auth.currentUser?.uid
    fun currentAuthEmail(): String? = auth.currentUser?.email

    fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Google Sign-In is required before accessing Firestore.")
    }

    fun isCurrentUserOwner(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified && user.email?.equals(OWNER_EMAIL, ignoreCase = true) == true
    }

    fun startBaseListeners() {
        val uid = auth.currentUser?.uid ?: return
        if (activeBaseUid == uid && activeListeners.isNotEmpty()) return
        stopListeners()
        activeBaseUid = uid
        val isOwner = isCurrentUserOwner()

        // 1. Public Institute Settings
        activeListeners += db.collection("institute_settings").document(SETTINGS_DOC_ID)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(error, OperationType.GET, "institute_settings/$SETTINGS_DOC_ID", auth)
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    snapshot.toObject(TuitionSettings::class.java, ServerTimestampBehavior.ESTIMATE)
                        ?.let { _settings.value = it }
                }
            }

        // 2. Owner Admin Account (ONLY if current Google user is verified owner)
        if (isOwner) {
            activeListeners += db.collection("admins").document(uid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        if (auth.currentUser?.uid == uid) {
                            handleFirestoreError(error, OperationType.GET, "admins/$uid", auth)
                        }
                        return@addSnapshotListener
                    }
                    val admin = snapshot?.toObject(AdminAccount::class.java, ServerTimestampBehavior.ESTIMATE)
                    _adminAccount.value = admin
                    _isAdminSetupComplete.value = admin?.isSetupComplete == true
                }
        } else {
            _adminAccount.value = null
            _isAdminSetupComplete.value = false
        }

        // 3. Public Faculty
        val facultyQuery = if (isOwner) {
            db.collection("public_faculty")
        } else {
            db.collection("public_faculty").whereEqualTo("isActive", true)
        }
        activeListeners += facultyQuery.addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.LIST, "public_faculty", auth)
                }
                return@addSnapshotListener
            }
            if (snap != null) {
                _publicFaculty.value = snap.toObjects(PublicFaculty::class.java, ServerTimestampBehavior.ESTIMATE)
            }
        }

        // 4. Public Toppers
        val toppersQuery = if (isOwner) {
            db.collection("public_toppers")
        } else {
            db.collection("public_toppers").whereEqualTo("isActive", true)
        }
        activeListeners += toppersQuery.addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.LIST, "public_toppers", auth)
                }
                return@addSnapshotListener
            }
            if (snap != null) {
                _toppers.value = snap.toObjects(TopperResult::class.java, ServerTimestampBehavior.ESTIMATE)
            }
        }

        // 5. Offers
        val offersQuery = if (isOwner) {
            db.collection("offers")
        } else {
            db.collection("offers").whereEqualTo("isActive", true)
        }
        activeListeners += offersQuery.addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.LIST, "offers", auth)
                }
                return@addSnapshotListener
            }
            if (snap != null) {
                _offers.value = snap.toObjects(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
            }
        }

        // 6. Announcements
        val announcementsQuery = if (isOwner) {
            db.collection("announcements")
        } else {
            db.collection("announcements").whereEqualTo("isPublished", true)
        }
        activeListeners += announcementsQuery.addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.LIST, "announcements", auth)
                }
                return@addSnapshotListener
            }
            if (snap != null) {
                _announcements.value = snap.toObjects(AnnouncementItem::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        // 7. Timetable
        val timetableQuery = if (isOwner) {
            db.collection("timetable")
        } else {
            db.collection("timetable").whereEqualTo("isActive", true)
        }
        activeListeners += timetableQuery.addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.LIST, "timetable", auth)
                }
                return@addSnapshotListener
            }
            if (snap != null) {
                _timetable.value = snap.toObjects(TimetableSlot::class.java, ServerTimestampBehavior.ESTIMATE)
            }
        }

        // 8. Homework
        val homeworkQuery = if (isOwner) {
            db.collection("homework")
        } else {
            db.collection("homework").whereEqualTo("isPublished", true)
        }
        activeListeners += homeworkQuery.addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(error, OperationType.LIST, "homework", auth)
                }
                return@addSnapshotListener
            }
            if (snap != null) {
                _homework.value = snap.toObjects(HomeworkItem::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        // 9. Admissions & Advance Bookings (Scoped to current user unless owner)
        if (!isOwner) {
            activeListeners += db.collection("admissions").whereEqualTo("authUid", uid)
                .addSnapshotListener { snap, error ->
                    if (error != null) {
                        if (auth.currentUser?.uid == uid) {
                            handleFirestoreError(error, OperationType.LIST, "admissions", auth)
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        _admissions.value = snap.toObjects(AdmissionInquiry::class.java, ServerTimestampBehavior.ESTIMATE)
                            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                    }
                }

            activeListeners += db.collection("advance_bookings").whereEqualTo("authUid", uid)
                .addSnapshotListener { snap, error ->
                    if (error != null) {
                        if (auth.currentUser?.uid == uid) {
                            handleFirestoreError(error, OperationType.LIST, "advance_bookings", auth)
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        _advanceBookings.value = snap.toObjects(AdvanceBooking::class.java, ServerTimestampBehavior.ESTIMATE)
                            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                    }
                }
        }
    }

    fun startAdminListeners() {
        val uid = requireUserId()
        if (!isCurrentUserOwner()) return
        startBaseListeners()

        activeListeners += db.collection("students").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "students", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _students.value = snap.toObjects(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("teachers").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "teachers", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _teachers.value = snap.toObjects(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("admissions").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "admissions", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _admissions.value = snap.toObjects(AdmissionInquiry::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("advance_bookings").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "advance_bookings", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _advanceBookings.value = snap.toObjects(AdvanceBooking::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("receipts").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "receipts", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _receipts.value = snap.toObjects(FeeReceipt::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("attendance").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "attendance", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _attendance.value = snap.toObjects(AttendanceRecord::class.java, ServerTimestampBehavior.ESTIMATE)
            }
        }

        activeListeners += db.collection("homework_submissions").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "homework_submissions", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _homeworkSubmissions.value = snap.toObjects(HomeworkSubmission::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("exam_results").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "exam_results", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _examResults.value = snap.toObjects(ExamResult::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        activeListeners += db.collection("offer_history").addSnapshotListener { snap, error ->
            if (error != null) {
                if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "offer_history", auth)
                return@addSnapshotListener
            }
            if (snap != null) {
                _offerHistory.value = snap.toObjects(OfferHistoryEntry::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }
    }

    fun startStudentListeners(studentId: String) {
        val uid = requireUserId()
        startBaseListeners()

        activeListeners += db.collection("students").document(studentId)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.GET, "students/$studentId", auth)
                    return@addSnapshotListener
                }
                val std = snap?.toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                if (std != null) {
                    _students.value = listOf(std)
                }
            }

        activeListeners += db.collection("receipts").whereEqualTo("studentAuthUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "receipts", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _receipts.value = snap.toObjects(FeeReceipt::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
            }

        activeListeners += db.collection("attendance").whereEqualTo("studentAuthUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "attendance", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _attendance.value = snap.toObjects(AttendanceRecord::class.java, ServerTimestampBehavior.ESTIMATE)
                }
            }

        activeListeners += db.collection("exam_results").whereEqualTo("studentAuthUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "exam_results", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _examResults.value = snap.toObjects(ExamResult::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
            }

        activeListeners += db.collection("homework_submissions").whereEqualTo("studentAuthUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "homework_submissions", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _homeworkSubmissions.value = snap.toObjects(HomeworkSubmission::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
            }
    }

    fun startTeacherListeners(teacherDocId: String) {
        val uid = requireUserId()
        startBaseListeners()

        activeListeners += db.collection("teachers").document(teacherDocId)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.GET, "teachers/$teacherDocId", auth)
                    return@addSnapshotListener
                }
                val teacher = snap?.toObject(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                if (teacher != null) {
                    _teachers.value = listOf(teacher)
                }
            }

        activeListeners += db.collection("students").whereArrayContains("teacherUids", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "students", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _students.value = snap.toObjects(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.name }
                }
            }

        activeListeners += db.collection("attendance").whereEqualTo("teacherUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "attendance", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _attendance.value = snap.toObjects(AttendanceRecord::class.java, ServerTimestampBehavior.ESTIMATE)
                }
            }

        activeListeners += db.collection("exam_results").whereEqualTo("teacherUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "exam_results", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _examResults.value = snap.toObjects(ExamResult::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
            }

        activeListeners += db.collection("homework_submissions").whereEqualTo("teacherUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    if (auth.currentUser?.uid == uid) handleFirestoreError(error, OperationType.LIST, "homework_submissions", auth)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    _homeworkSubmissions.value = snap.toObjects(HomeworkSubmission::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
            }
    }

    fun clearPortalSession() {
        stopListeners()
        _students.value = emptyList()
        _teachers.value = emptyList()
        _receipts.value = emptyList()
        _attendance.value = emptyList()
        _examResults.value = emptyList()
        _homeworkSubmissions.value = emptyList()
        _offerHistory.value = emptyList()
        if (auth.currentUser != null) {
            startBaseListeners()
        }
    }

    fun stopListeners() {
        activeListeners.forEach { runCatching { it.remove() } }
        activeListeners.clear()
        activeBaseUid = null
    }

    // ==========================================
    // 1. OWNER ADMIN SETUP & AUTHENTICATION
    // ==========================================
    fun verifyAuthorizedOwner(ownerCredential: String): Boolean {
        if (!isCurrentUserOwner()) return false
        val trimmed = ownerCredential.trim()
        if (trimmed.isBlank()) return false
        val cleanDigits = trimmed.filter { it.isDigit() }
        val isAuthorizedPhone = cleanDigits == OWNER_PHONE_10 ||
            cleanDigits == "91$OWNER_PHONE_10" ||
            (cleanDigits.length >= 10 && cleanDigits.endsWith(OWNER_PHONE_10))
        val isAuthorizedEmail = trimmed.equals(OWNER_EMAIL, ignoreCase = true)
        return isAuthorizedPhone || isAuthorizedEmail
    }

    suspend fun refreshAdminSetupState(): Boolean {
        val uid = auth.currentUser?.uid ?: return false
        if (!isCurrentUserOwner()) return false
        return try {
            val doc = db.collection("admins").document(uid).get().await()
            val account = doc.toObject(AdminAccount::class.java, ServerTimestampBehavior.ESTIMATE)
            _adminAccount.value = account
            val setupDone = account?.isSetupComplete == true
            _isAdminSetupComplete.value = setupDone
            setupDone
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "admins/$uid", auth)
            false
        }
    }

    suspend fun completeOneTimeOwnerAdminSetup(
        ownerVerification: String,
        adminMobileOrId: String,
        pass: String,
        founderName: String = "Harshadsinh Rathod"
    ): Result<AdminAccount> {
        val uid = requireUserId()
        if (!isCurrentUserOwner() || !verifyAuthorizedOwner(ownerVerification)) {
            return Result.failure(SecurityException("Only verified owner ($OWNER_EMAIL) can initialize Admin."))
        }

        val cleanPass = pass.trim()
        val cleanId = adminMobileOrId.trim().replace(" ", "").replace("-", "")
        val cleanDigits = cleanId.filter { it.isDigit() }
        if (cleanId.length < 2 || cleanPass.length < 4) {
            return Result.failure(IllegalArgumentException("Enter valid Admin ID and at least 4-char password."))
        }
        val resolvedMobile = if (cleanDigits.length >= 10) cleanDigits.takeLast(10) else OWNER_PHONE_10
        val passwordHash = PasswordHasher.hashPassword(cleanPass, "ADMIN")
        val resolvedFounder = founderName.trim().ifBlank { "Harshadsinh Rathod" }

        val adminRef = db.collection("admins").document(uid)
        val settingsRef = db.collection("institute_settings").document(SETTINGS_DOC_ID)

        return try {
            val existingAdmin = adminRef.get().await()
            if (existingAdmin.exists() && existingAdmin.getBoolean("isSetupComplete") == true) {
                return Result.failure(IllegalStateException("One-time Owner Admin setup is already completed and permanently locked."))
            }
            val existingSettings = settingsRef.get().await()

            val adminPayload = mapOf(
                "ownerUid" to uid,
                "ownerEmail" to (auth.currentUser?.email ?: OWNER_EMAIL),
                "adminId" to cleanId,
                "adminMobile" to resolvedMobile,
                "founderName" to resolvedFounder,
                "passwordHash" to passwordHash,
                "isSetupComplete" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(adminRef, adminPayload)
            if (!existingSettings.exists()) {
                val curSettings = _settings.value
                val settingsPayload = mapOf(
                    "businessName" to curSettings.businessName,
                    "founderName" to resolvedFounder,
                    "contactPhone" to curSettings.contactPhone,
                    "whatsappNumber" to curSettings.whatsappNumber,
                    "upiId" to curSettings.upiId,
                    "upiPayeeName" to curSettings.upiPayeeName,
                    "advanceBookingAmount" to curSettings.advanceBookingAmount,
                    "address" to curSettings.address,
                    "admissionOpen" to curSettings.admissionOpen,
                    "tickerText" to curSettings.tickerText,
                    "ownerUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                batch.set(settingsRef, settingsPayload)
            }
            batch.commit().await()

            val loaded = adminRef.get().await()
                .toObject(AdminAccount::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: AdminAccount(
                    id = uid,
                    ownerUid = uid,
                    ownerEmail = auth.currentUser?.email ?: OWNER_EMAIL,
                    adminId = cleanId,
                    adminMobile = resolvedMobile,
                    founderName = resolvedFounder,
                    passwordHash = passwordHash,
                    isSetupComplete = true
                )
            _adminAccount.value = loaded
            _isAdminSetupComplete.value = true
            startAdminListeners()
            Result.success(loaded)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, adminRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun authenticateAdmin(idOrMobile: String, pass: String): Result<AdminAccount> {
        val uid = requireUserId()
        if (!isCurrentUserOwner()) {
            return Result.failure(SecurityException("Signed-in Google account is not the authorized owner ($OWNER_EMAIL)."))
        }
        val adminRef = db.collection("admins").document(uid)
        return try {
            val snap = adminRef.get().await()
            val account = snap.toObject(AdminAccount::class.java, ServerTimestampBehavior.ESTIMATE)
            if (account == null || !account.isSetupComplete) {
                return Result.failure(IllegalStateException("Admin setup has not been completed yet."))
            }
            _adminAccount.value = account
            _isAdminSetupComplete.value = true

            val inputId = idOrMobile.trim().replace(" ", "").replace("-", "")
            val inputDigits = inputId.filter { it.isDigit() }
            val idMatches = inputId.equals(account.adminId, ignoreCase = true) ||
                inputId == account.adminMobile ||
                (inputDigits.length >= 10 && inputDigits.endsWith(account.adminMobile))
            val passMatches = PasswordHasher.verifyPassword(pass.trim(), account.passwordHash, "ADMIN")

            if (!idMatches || !passMatches) {
                return Result.failure(IllegalArgumentException("Invalid Admin ID or Password."))
            }
            startAdminListeners()
            Result.success(account)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, adminRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun changeAdminPassword(oldPass: String, newPass: String): Result<Unit> {
        val uid = requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Unauthorized"))
        val cleanNew = newPass.trim()
        if (cleanNew.length < 4) return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        val adminRef = db.collection("admins").document(uid)
        return try {
            val account = _adminAccount.value
                ?: adminRef.get().await().toObject(AdminAccount::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Admin account not found"))

            if (!PasswordHasher.verifyPassword(oldPass.trim(), account.passwordHash, "ADMIN")) {
                return Result.failure(IllegalArgumentException("Existing password is incorrect."))
            }
            val newHash = PasswordHasher.hashPassword(cleanNew, "ADMIN")
            adminRef.update(
                mapOf(
                    "passwordHash" to newHash,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            _adminAccount.value = account.copy(passwordHash = newHash)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, adminRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateAdminCredentials(newId: String, newPass: String): Result<Unit> {
        val uid = requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Unauthorized"))
        val adminRef = db.collection("admins").document(uid)
        return try {
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (newId.isNotBlank()) {
                val cleanId = newId.trim().replace(" ", "").replace("-", "")
                updates["adminId"] = cleanId
                val digits = cleanId.filter { it.isDigit() }
                if (digits.length >= 10) {
                    updates["adminMobile"] = digits.takeLast(10)
                }
            }
            if (newPass.isNotBlank()) {
                val cleanPass = newPass.trim()
                if (cleanPass.length < 4) {
                    return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
                }
                updates["passwordHash"] = PasswordHasher.hashPassword(cleanPass, "ADMIN")
            }
            if (updates.size > 1) {
                adminRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, adminRef.path, auth)
            Result.failure(e)
        }
    }

    // ==========================================
    // 2. STUDENTS (REGISTRATION, LOGIN, ADMIN MANAGEMENT)
    // ==========================================
    private suspend fun isPhoneRegisteredInFirestore(mobileNumber: String): Boolean {
        val clean = PasswordHasher.normalizePhone10(mobileNumber)
        if (clean.length < 10) return false
        val phoneHash = PasswordHasher.hashPhone(clean)
        return try {
            db.collection("phone_registry").document(phoneHash).get().await().exists()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "phone_registry/$phoneHash", auth)
            false
        }
    }

    suspend fun registerStudent(
        name: String,
        parentName: String,
        mobileNumber: String,
        standard: String,
        password: String,
        address: String = "કવિથા / બદરખા",
        medium: String = "ગુજરાતી માધ્યમ",
        school: String = "GSEB School"
    ): Result<Student> {
        val uid = requireUserId()
        val cleanMobile = PasswordHasher.normalizePhone10(mobileNumber)
        if (name.trim().length < 2 || parentName.isBlank() || cleanMobile.length < 10 || password.trim().length < 4) {
            return Result.failure(IllegalArgumentException("Please enter valid student details, 10-digit mobile, and 4+ char password."))
        }
        val phoneHash = PasswordHasher.hashPhone(cleanMobile)
        if (isPhoneRegisteredInFirestore(cleanMobile)) {
            return Result.failure(IllegalStateException("આ મોબાઇલ નંબર પર એકાઉન્ટ પહેલેથી જ છે!"))
        }

        val studentId = generateSafeDocId("HD")
        val passHash = PasswordHasher.hashPassword(password, studentId)
        val totalFee = standardAnnualFee(standard)
        val joinDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
        val rollNo = "${extractStandardNumber(standard)}${studentId.takeLast(3)}"

        val phoneRegRef = db.collection("phone_registry").document(phoneHash)
        val credRef = db.collection("student_credentials").document(studentId)
        val studentRef = db.collection("students").document(studentId)

        val approval = if (isCurrentUserOwner()) ApprovalStatusValues.APPROVED else ApprovalStatusValues.PENDING
        val teacherUids = if (isCurrentUserOwner()) matchingTeacherUidsForStandard(standard) else emptyList()

        val studentMap = mapOf(
            "authUid" to uid,
            "teacherUids" to teacherUids,
            "name" to name.trim(),
            "parentName" to parentName.trim(),
            "mobileNumber" to cleanMobile,
            "standard" to standard.trim(),
            "rollNo" to rollNo,
            "passwordHash" to passHash,
            "address" to address.trim().ifBlank { "કવિથા / બદરખા" },
            "joinDate" to joinDate,
            "totalFees" to totalFee,
            "paidFees" to 0,
            "medium" to medium.trim(),
            "school" to school.trim(),
            "dob" to "",
            "spinPlayed" to false,
            "spinDiscount" to 0,
            "specialDiscount" to 0,
            "discountReason" to "",
            "appliedOfferId" to "",
            "appliedOfferTitle" to "",
            "offerDiscount" to 0,
            "approvalStatus" to approval,
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val credMap = mapOf(
            "studentId" to studentId,
            "authUid" to uid,
            "passwordHash" to passHash,
            "approvalStatus" to approval,
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val regMap = mapOf(
            "ownerUid" to uid,
            "role" to "STUDENT",
            "entityId" to studentId,
            "createdAt" to FieldValue.serverTimestamp()
        )

        return try {
            val batch = db.batch()
            batch.set(phoneRegRef, regMap)
            batch.set(credRef, credMap)
            batch.set(studentRef, studentMap)
            batch.commit().await()

            val created = Student(
                id = studentId,
                authUid = uid,
                teacherUids = teacherUids,
                name = name.trim(),
                parentName = parentName.trim(),
                mobileNumber = cleanMobile,
                standard = standard.trim(),
                rollNo = rollNo,
                passwordHash = passHash,
                address = address.trim().ifBlank { "કવિથા / બદરખા" },
                joinDate = joinDate,
                totalFees = totalFee,
                paidFees = 0,
                medium = medium.trim(),
                school = school.trim(),
                approvalStatus = approval,
                isActive = true
            )
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminCreateStudent(
        name: String,
        parentName: String,
        mobileNumber: String,
        standard: String,
        password: String,
        totalFees: Int = standardAnnualFee(standard),
        paidFees: Int = 0,
        address: String = "કવિથા / બદરખા",
        medium: String = "ગુજરાતી માધ્યમ",
        school: String = "GSEB School",
        dob: String = "",
        customStudentId: String = ""
    ): Result<Student> {
        val uid = requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))

        val cleanMobile = PasswordHasher.normalizePhone10(mobileNumber)
        if (name.trim().length < 2 || parentName.isBlank() || cleanMobile.length < 10 || password.trim().length < 4) {
            return Result.failure(IllegalArgumentException("Enter valid student details, 10-digit mobile, and 4+ char password."))
        }
        val phoneHash = PasswordHasher.hashPhone(cleanMobile)
        if (isPhoneRegisteredInFirestore(cleanMobile)) {
            return Result.failure(IllegalStateException("A student account with this mobile number already exists."))
        }

        val studentId = customStudentId.trim().replace(Regex("[^a-zA-Z0-9_-]"), "").ifBlank {
            generateSafeDocId("HD")
        }
        val passHash = PasswordHasher.hashPassword(password, studentId)
        val joinDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
        val rollNo = "${extractStandardNumber(standard)}${studentId.takeLast(3)}"
        val teacherUids = matchingTeacherUidsForStandard(standard)

        val phoneRegRef = db.collection("phone_registry").document(phoneHash)
        val credRef = db.collection("student_credentials").document(studentId)
        val studentRef = db.collection("students").document(studentId)

        val studentMap = mapOf(
            "authUid" to "",
            "teacherUids" to teacherUids,
            "name" to name.trim(),
            "parentName" to parentName.trim(),
            "mobileNumber" to cleanMobile,
            "standard" to standard.trim(),
            "rollNo" to rollNo,
            "passwordHash" to passHash,
            "address" to address.trim(),
            "joinDate" to joinDate,
            "totalFees" to totalFees.coerceAtLeast(0),
            "paidFees" to paidFees.coerceAtLeast(0),
            "medium" to medium.trim(),
            "school" to school.trim(),
            "dob" to dob.trim(),
            "spinPlayed" to false,
            "spinDiscount" to 0,
            "specialDiscount" to 0,
            "discountReason" to "",
            "appliedOfferId" to "",
            "appliedOfferTitle" to "",
            "offerDiscount" to 0,
            "approvalStatus" to ApprovalStatusValues.APPROVED,
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val credMap = mapOf(
            "studentId" to studentId,
            "authUid" to "",
            "passwordHash" to passHash,
            "approvalStatus" to ApprovalStatusValues.APPROVED,
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val regMap = mapOf(
            "ownerUid" to uid,
            "role" to "STUDENT",
            "entityId" to studentId,
            "createdAt" to FieldValue.serverTimestamp()
        )

        return try {
            val batch = db.batch()
            batch.set(phoneRegRef, regMap)
            batch.set(credRef, credMap)
            batch.set(studentRef, studentMap)
            batch.commit().await()

            val loaded = studentRef.get().await()
                .toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: Student(
                    id = studentId,
                    name = name.trim(),
                    parentName = parentName.trim(),
                    mobileNumber = cleanMobile,
                    standard = standard.trim(),
                    rollNo = rollNo,
                    passwordHash = passHash,
                    address = address.trim(),
                    joinDate = joinDate,
                    totalFees = totalFees.coerceAtLeast(0),
                    paidFees = paidFees.coerceAtLeast(0),
                    medium = medium.trim(),
                    school = school.trim(),
                    dob = dob.trim(),
                    approvalStatus = ApprovalStatusValues.APPROVED,
                    isActive = true
                )
            Result.success(loaded)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun authenticateStudent(idOrMobile: String, pass: String): Result<Student> {
        val uid = requireUserId()
        val rawInput = idOrMobile.trim()
        val cleanPass = pass.trim()
        if (rawInput.isBlank() || cleanPass.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter Student ID/Mobile and password."))
        }

        return try {
            val digits = rawInput.filter { it.isDigit() }
            val resolvedId = if (digits.length >= 10 && !rawInput.uppercase().startsWith("HD")) {
                val phoneHash = PasswordHasher.hashPhone(digits)
                val regDoc = db.collection("phone_registry").document(phoneHash).get().await()
                if (!regDoc.exists() || regDoc.getString("role") != "STUDENT") {
                    return Result.failure(IllegalArgumentException("No student found for this mobile number."))
                }
                regDoc.getString("entityId").orEmpty()
            } else {
                rawInput.uppercase()
            }

            if (resolvedId.isBlank()) {
                return Result.failure(IllegalArgumentException("Invalid Student ID."))
            }

            val credRef = db.collection("student_credentials").document(resolvedId)
            val credSnap = credRef.get().await()
            if (!credSnap.exists()) {
                return Result.failure(IllegalArgumentException("Invalid Student ID or Password."))
            }
            val cred = credSnap.toObject(StudentCredential::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Invalid credential record."))

            if (!PasswordHasher.verifyPassword(cleanPass, cred.passwordHash, resolvedId)) {
                return Result.failure(IllegalArgumentException("Invalid Student ID or Password."))
            }
            if (!cred.isActive) {
                return Result.failure(IllegalStateException("Your student account has been deactivated by Admin."))
            }
            if (cred.approvalStatus == ApprovalStatusValues.PENDING) {
                return Result.failure(IllegalStateException("તમારું એકાઉન્ટ હજુ એડમિન મંજૂરી (Approval) માટે બાકી છે."))
            }
            if (cred.approvalStatus == ApprovalStatusValues.REJECTED) {
                return Result.failure(IllegalStateException("Your student registration was not approved. Please contact Admin."))
            }

            val studentRef = db.collection("students").document(resolvedId)
            if (cred.authUid.isBlank()) {
                val batch = db.batch()
                batch.update(credRef, mapOf("authUid" to uid, "updatedAt" to FieldValue.serverTimestamp()))
                batch.update(studentRef, mapOf("authUid" to uid, "updatedAt" to FieldValue.serverTimestamp()))
                batch.commit().await()
            } else if (cred.authUid != uid && !isCurrentUserOwner()) {
                return Result.failure(SecurityException("This Student ID is linked to another Google account. Ask Admin to reset link or switch Google account."))
            }

            val studentSnap = studentRef.get().await()
            val student = studentSnap.toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Student profile not found."))

            startStudentListeners(student.id)
            Result.success(student)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "students/$rawInput", auth)
            Result.failure(e)
        }
    }

    suspend fun changeStudentPassword(studentId: String, oldPass: String, newPass: String): Result<Unit> {
        requireUserId()
        val cleanNew = newPass.trim()
        if (cleanNew.length < 4) return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        val studentRef = db.collection("students").document(studentId)
        val credRef = db.collection("student_credentials").document(studentId)
        return try {
            val credSnap = credRef.get().await()
            val cred = credSnap.toObject(StudentCredential::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Student record not found."))
            if (!PasswordHasher.verifyPassword(oldPass.trim(), cred.passwordHash, studentId)) {
                return Result.failure(IllegalArgumentException("Current password is incorrect."))
            }
            val newHash = PasswordHasher.hashPassword(cleanNew, studentId)
            val batch = db.batch()
            batch.update(credRef, mapOf("passwordHash" to newHash, "updatedAt" to FieldValue.serverTimestamp()))
            batch.update(studentRef, mapOf("passwordHash" to newHash, "updatedAt" to FieldValue.serverTimestamp()))
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminSetStudentPassword(studentId: String, newPass: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val cleanNew = newPass.trim()
        if (cleanNew.length < 4) return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        val newHash = PasswordHasher.hashPassword(cleanNew, studentId)
        val studentRef = db.collection("students").document(studentId)
        val credRef = db.collection("student_credentials").document(studentId)
        return try {
            val batch = db.batch()
            batch.update(studentRef, mapOf("passwordHash" to newHash, "updatedAt" to FieldValue.serverTimestamp()))
            batch.update(credRef, mapOf("passwordHash" to newHash, "updatedAt" to FieldValue.serverTimestamp()))
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminApproveStudent(studentId: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val studentRef = db.collection("students").document(studentId)
        val credRef = db.collection("student_credentials").document(studentId)
        return try {
            val snap = studentRef.get().await()
            val std = snap.toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Student not found"))
            val teacherUids = matchingTeacherUidsForStandard(std.standard)

            val batch = db.batch()
            batch.update(
                studentRef,
                mapOf(
                    "approvalStatus" to ApprovalStatusValues.APPROVED,
                    "isActive" to true,
                    "teacherUids" to teacherUids,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                credRef,
                mapOf(
                    "approvalStatus" to ApprovalStatusValues.APPROVED,
                    "isActive" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminRejectStudent(studentId: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val studentRef = db.collection("students").document(studentId)
        val credRef = db.collection("student_credentials").document(studentId)
        return try {
            val batch = db.batch()
            batch.update(
                studentRef,
                mapOf("approvalStatus" to ApprovalStatusValues.REJECTED, "isActive" to false, "updatedAt" to FieldValue.serverTimestamp())
            )
            batch.update(
                credRef,
                mapOf("approvalStatus" to ApprovalStatusValues.REJECTED, "isActive" to false, "updatedAt" to FieldValue.serverTimestamp())
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminToggleStudentActive(studentId: String, active: Boolean): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val studentRef = db.collection("students").document(studentId)
        val credRef = db.collection("student_credentials").document(studentId)
        return try {
            val batch = db.batch()
            batch.update(studentRef, mapOf("isActive" to active, "updatedAt" to FieldValue.serverTimestamp()))
            batch.update(credRef, mapOf("isActive" to active, "updatedAt" to FieldValue.serverTimestamp()))
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateStudent(student: Student): Result<Unit> {
        requireUserId()
        require(student.id.isNotBlank()) { "Student ID must not be blank" }
        val studentRef = db.collection("students").document(student.id)
        val credRef = db.collection("student_credentials").document(student.id)
        return try {
            val teacherUids = if (isCurrentUserOwner()) matchingTeacherUidsForStandard(student.standard) else student.teacherUids
            val existingCreatedAt = student.createdAt ?: studentRef.get().await().getTimestamp("createdAt")
            requireNotNull(existingCreatedAt) { "Student createdAt must not be null for update" }
            val updatedStudent = student.copy(
                teacherUids = teacherUids,
                createdAt = existingCreatedAt,
                updatedAt = null
            )
            val batch = db.batch()
            batch.set(studentRef, updatedStudent)
            batch.update(
                credRef,
                mapOf(
                    "approvalStatus" to student.approvalStatus,
                    "isActive" to student.isActive,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteStudent(student: Student): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val studentRef = db.collection("students").document(student.id)
        val credRef = db.collection("student_credentials").document(student.id)
        return try {
            val batch = db.batch()
            batch.delete(studentRef)
            batch.delete(credRef)
            val digits = PasswordHasher.normalizePhone10(student.mobileNumber)
            if (digits.length >= 10) {
                val phoneHash = PasswordHasher.hashPhone(digits)
                batch.delete(db.collection("phone_registry").document(phoneHash))
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    // ==========================================
    // 3. TEACHERS (REGISTRATION, LOGIN, ADMIN APPROVAL & SCOPING)
    // ==========================================
    private suspend fun matchingTeacherUidsForStandard(standard: String): List<String> {
        val targetNum = extractStandardNumber(standard)
        val teachersList = if (_teachers.value.isNotEmpty()) {
            _teachers.value
        } else {
            runCatching {
                db.collection("teachers").get().await()
                    .toObjects(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
            }.getOrDefault(emptyList())
        }
        return teachersList
            .filter { t ->
                t.approvalStatus == ApprovalStatusValues.APPROVED &&
                    t.isActive &&
                    t.authUid.isNotBlank() &&
                    (t.assignedStandards.isEmpty() ||
                        t.assignedStandards.any { s ->
                            s.equals("All", ignoreCase = true) ||
                                extractStandardNumber(s) == targetNum ||
                                s.equals(standard, ignoreCase = true)
                        })
            }
            .map { it.authUid }
            .distinct()
    }

    private suspend fun syncTeacherUidsAcrossStudents() {
        if (!isCurrentUserOwner()) return
        val teachersList = db.collection("teachers").get().await()
            .toObjects(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
        val studentsList = db.collection("students").get().await()
            .toObjects(Student::class.java, ServerTimestampBehavior.ESTIMATE)

        val batch = db.batch()
        var pendingOps = 0
        for (std in studentsList) {
            val targetNum = extractStandardNumber(std.standard)
            val uids = teachersList
                .filter { t ->
                    t.approvalStatus == ApprovalStatusValues.APPROVED &&
                        t.isActive &&
                        t.authUid.isNotBlank() &&
                        (t.assignedStandards.isEmpty() ||
                            t.assignedStandards.any { s ->
                                s.equals("All", ignoreCase = true) ||
                                    extractStandardNumber(s) == targetNum ||
                                    s.equals(std.standard, ignoreCase = true)
                            })
                }
                .map { it.authUid }
                .distinct()
            if (uids != std.teacherUids) {
                batch.update(
                    db.collection("students").document(std.id),
                    mapOf("teacherUids" to uids, "updatedAt" to FieldValue.serverTimestamp())
                )
                pendingOps++
            }
        }
        if (pendingOps > 0) {
            batch.commit().await()
        }
    }

    suspend fun registerTeacher(
        name: String,
        mobileNumber: String,
        subjects: String,
        qualification: String,
        experience: String,
        password: String,
        assignedStandards: List<String> = listOf("All")
    ): Result<TeacherProfile> {
        val uid = requireUserId()
        val cleanMobile = PasswordHasher.normalizePhone10(mobileNumber)
        if (name.trim().length < 2 || cleanMobile.length < 10 || subjects.isBlank() || password.trim().length < 4) {
            return Result.failure(IllegalArgumentException("Enter valid teacher name, 10-digit mobile, subjects, and 4+ char password."))
        }
        val phoneHash = PasswordHasher.hashPhone(cleanMobile)
        if (isPhoneRegisteredInFirestore(cleanMobile)) {
            return Result.failure(IllegalStateException("આ મોબાઇલ નંબર પર શિક્ષક પહેલેથી રજીસ્ટર છે!"))
        }

        val teacherId = generateSafeDocId("TCH")
        val passHash = PasswordHasher.hashPassword(password, teacherId)
        val formattedContact = "+91 $cleanMobile"
        val approval = if (isCurrentUserOwner()) ApprovalStatusValues.APPROVED else ApprovalStatusValues.PENDING
        val cleanStandards = assignedStandards.ifEmpty { listOf("All") }

        val phoneRegRef = db.collection("phone_registry").document(phoneHash)
        val teacherRef = db.collection("teachers").document(teacherId)

        val teacherMap = mapOf(
            "teacherId" to teacherId,
            "authUid" to uid,
            "name" to name.trim(),
            "role" to "વિષય શિક્ષક (Faculty)",
            "qualification" to qualification.trim().ifBlank { "Graduate / B.Ed" },
            "experience" to experience.trim().ifBlank { "શિક્ષણ અનુભવ" },
            "subjects" to subjects.trim(),
            "assignedStandards" to cleanStandards,
            "contact" to formattedContact,
            "passwordHash" to passHash,
            "approvalStatus" to approval,
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val regMap = mapOf(
            "ownerUid" to uid,
            "role" to "TEACHER",
            "entityId" to teacherId,
            "createdAt" to FieldValue.serverTimestamp()
        )

        return try {
            val batch = db.batch()
            batch.set(phoneRegRef, regMap)
            batch.set(teacherRef, teacherMap)
            if (isCurrentUserOwner()) {
                val dirRef = db.collection("teacher_directory").document(uid)
                val pubRef = db.collection("public_faculty").document(teacherId)
                batch.set(
                    dirRef,
                    mapOf(
                        "teacherId" to teacherId,
                        "name" to name.trim(),
                        "approvalStatus" to ApprovalStatusValues.APPROVED,
                        "isActive" to true,
                        "assignedStandards" to cleanStandards,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(
                    pubRef,
                    mapOf(
                        "teacherId" to teacherId,
                        "name" to name.trim(),
                        "role" to "વિષય શિક્ષક (Faculty)",
                        "qualification" to qualification.trim().ifBlank { "Graduate / B.Ed" },
                        "experience" to experience.trim().ifBlank { "શિક્ષણ અનુભવ" },
                        "subjects" to subjects.trim(),
                        "assignedStandards" to cleanStandards,
                        "isActive" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()

            if (isCurrentUserOwner()) {
                syncTeacherUidsAcrossStudents()
            }

            Result.success(
                TeacherProfile(
                    id = teacherId,
                    teacherId = teacherId,
                    authUid = uid,
                    name = name.trim(),
                    role = "વિષય શિક્ષક (Faculty)",
                    qualification = qualification.trim().ifBlank { "Graduate / B.Ed" },
                    experience = experience.trim().ifBlank { "શિક્ષણ અનુભવ" },
                    subjects = subjects.trim(),
                    assignedStandards = cleanStandards,
                    contact = formattedContact,
                    passwordHash = passHash,
                    approvalStatus = approval,
                    isActive = true
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun authenticateTeacher(idOrContact: String, pass: String): Result<TeacherProfile> {
        val uid = requireUserId()
        val input = idOrContact.trim()
        val cleanPass = pass.trim()
        if (input.isBlank() || cleanPass.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter Teacher ID/Mobile and Password."))
        }

        return try {
            val digits = input.filter { it.isDigit() }
            val candidates = if (isCurrentUserOwner()) {
                db.collection("teachers").get().await()
                    .toObjects(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
            } else {
                db.collection("teachers").whereEqualTo("authUid", uid).get().await()
                    .toObjects(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
            }

            val teacher = candidates.firstOrNull { t ->
                val contactDigits = t.contact.filter { it.isDigit() }
                t.teacherId.equals(input, ignoreCase = true) ||
                    t.id.equals(input, ignoreCase = true) ||
                    t.name.equals(input, ignoreCase = true) ||
                    (digits.length >= 10 && contactDigits.endsWith(digits.takeLast(10)))
            } ?: return Result.failure(IllegalArgumentException("Teacher account not found for this Google user."))

            if (!PasswordHasher.verifyPassword(cleanPass, teacher.passwordHash, teacher.teacherId)) {
                return Result.failure(IllegalArgumentException("Invalid Teacher ID or Password."))
            }
            if (!teacher.isActive) {
                return Result.failure(IllegalStateException("Your teacher account has been deactivated by Admin."))
            }
            if (teacher.approvalStatus == ApprovalStatusValues.PENDING) {
                return Result.failure(IllegalStateException("તમારું શિક્ષક રજીસ્ટ્રેશન હજુ એડમિન મંજૂરી (Approval) માટે બાકી છે."))
            }
            if (teacher.approvalStatus == ApprovalStatusValues.REJECTED) {
                return Result.failure(IllegalStateException("Your teacher registration was rejected by Admin."))
            }

            startTeacherListeners(teacher.id)
            Result.success(teacher)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "teachers/$input", auth)
            Result.failure(e)
        }
    }

    suspend fun changeTeacherPassword(teacherDocId: String, teacherId: String, oldPass: String, newPass: String): Result<Unit> {
        requireUserId()
        val cleanNew = newPass.trim()
        if (cleanNew.length < 4) return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        val teacherRef = db.collection("teachers").document(teacherDocId)
        return try {
            val snap = teacherRef.get().await()
            val teacher = snap.toObject(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Teacher record not found."))
            if (!PasswordHasher.verifyPassword(oldPass.trim(), teacher.passwordHash, teacher.teacherId)) {
                return Result.failure(IllegalArgumentException("Current password is incorrect."))
            }
            val newHash = PasswordHasher.hashPassword(cleanNew, teacher.teacherId)
            teacherRef.update(mapOf("passwordHash" to newHash, "updatedAt" to FieldValue.serverTimestamp())).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminApproveTeacher(
        teacherDocId: String,
        assignedStandards: List<String>
    ): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val teacherRef = db.collection("teachers").document(teacherDocId)
        return try {
            val snap = teacherRef.get().await()
            val teacher = snap.toObject(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Teacher not found"))
            val cleanStandards = assignedStandards.ifEmpty { listOf("All") }

            val batch = db.batch()
            batch.update(
                teacherRef,
                mapOf(
                    "approvalStatus" to ApprovalStatusValues.APPROVED,
                    "isActive" to true,
                    "assignedStandards" to cleanStandards,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (teacher.authUid.isNotBlank()) {
                val dirRef = db.collection("teacher_directory").document(teacher.authUid)
                val existingDir = dirRef.get().await()
                if (existingDir.exists()) {
                    batch.update(
                        dirRef,
                        mapOf(
                            "teacherId" to teacher.teacherId,
                            "name" to teacher.name,
                            "approvalStatus" to ApprovalStatusValues.APPROVED,
                            "isActive" to true,
                            "assignedStandards" to cleanStandards,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    batch.set(
                        dirRef,
                        mapOf(
                            "teacherId" to teacher.teacherId,
                            "name" to teacher.name,
                            "approvalStatus" to ApprovalStatusValues.APPROVED,
                            "isActive" to true,
                            "assignedStandards" to cleanStandards,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            val pubRef = db.collection("public_faculty").document(teacher.id)
            val existingPub = pubRef.get().await()
            if (existingPub.exists()) {
                batch.update(
                    pubRef,
                    mapOf(
                        "teacherId" to teacher.teacherId,
                        "name" to teacher.name,
                        "role" to teacher.role,
                        "qualification" to teacher.qualification,
                        "experience" to teacher.experience,
                        "subjects" to teacher.subjects,
                        "assignedStandards" to cleanStandards,
                        "isActive" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    pubRef,
                    mapOf(
                        "teacherId" to teacher.teacherId,
                        "name" to teacher.name,
                        "role" to teacher.role,
                        "qualification" to teacher.qualification,
                        "experience" to teacher.experience,
                        "subjects" to teacher.subjects,
                        "assignedStandards" to cleanStandards,
                        "isActive" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            syncTeacherUidsAcrossStudents()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminRejectTeacher(teacherDocId: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val teacherRef = db.collection("teachers").document(teacherDocId)
        return try {
            val snap = teacherRef.get().await()
            val teacher = snap.toObject(TeacherProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Teacher not found"))
            val batch = db.batch()
            batch.update(
                teacherRef,
                mapOf(
                    "approvalStatus" to ApprovalStatusValues.REJECTED,
                    "isActive" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (teacher.authUid.isNotBlank()) {
                val dirRef = db.collection("teacher_directory").document(teacher.authUid)
                if (dirRef.get().await().exists()) {
                    batch.update(
                        dirRef,
                        mapOf(
                            "approvalStatus" to ApprovalStatusValues.REJECTED,
                            "isActive" to false,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            val pubRef = db.collection("public_faculty").document(teacher.id)
            if (pubRef.get().await().exists()) {
                batch.update(pubRef, mapOf("isActive" to false, "updatedAt" to FieldValue.serverTimestamp()))
            }
            batch.commit().await()
            syncTeacherUidsAcrossStudents()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminToggleTeacherActive(teacher: TeacherProfile, active: Boolean): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val teacherRef = db.collection("teachers").document(teacher.id)
        return try {
            val batch = db.batch()
            batch.update(teacherRef, mapOf("isActive" to active, "updatedAt" to FieldValue.serverTimestamp()))
            if (teacher.authUid.isNotBlank()) {
                val dirRef = db.collection("teacher_directory").document(teacher.authUid)
                if (dirRef.get().await().exists()) {
                    batch.update(dirRef, mapOf("isActive" to active, "updatedAt" to FieldValue.serverTimestamp()))
                }
            }
            val pubRef = db.collection("public_faculty").document(teacher.id)
            if (pubRef.get().await().exists()) {
                batch.update(pubRef, mapOf("isActive" to (active && teacher.approvalStatus == ApprovalStatusValues.APPROVED), "updatedAt" to FieldValue.serverTimestamp()))
            }
            batch.commit().await()
            syncTeacherUidsAcrossStudents()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminSetTeacherPassword(teacherIdOrDocId: String, newPass: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val cleanNew = newPass.trim()
        if (cleanNew.length < 4) return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        val teacher = _teachers.value.firstOrNull {
            it.id == teacherIdOrDocId || it.teacherId.equals(teacherIdOrDocId, ignoreCase = true)
        } ?: return Result.failure(IllegalStateException("Teacher not found"))
        val newHash = PasswordHasher.hashPassword(cleanNew, teacher.teacherId)
        val ref = db.collection("teachers").document(teacher.id)
        return try {
            ref.update(mapOf("passwordHash" to newHash, "updatedAt" to FieldValue.serverTimestamp())).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateTeacher(teacher: TeacherProfile): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val teacherRef = db.collection("teachers").document(teacher.id)
        return try {
            val existingCreatedAt = teacher.createdAt ?: teacherRef.get().await().getTimestamp("createdAt")
            requireNotNull(existingCreatedAt) { "Teacher createdAt must not be null for update" }
            val batch = db.batch()
            batch.set(teacherRef, teacher.copy(createdAt = existingCreatedAt, updatedAt = null))
            if (teacher.authUid.isNotBlank()) {
                val dirRef = db.collection("teacher_directory").document(teacher.authUid)
                if (dirRef.get().await().exists()) {
                    batch.update(
                        dirRef,
                        mapOf(
                            "teacherId" to teacher.teacherId,
                            "name" to teacher.name,
                            "approvalStatus" to teacher.approvalStatus,
                            "isActive" to teacher.isActive,
                            "assignedStandards" to teacher.assignedStandards,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            val pubRef = db.collection("public_faculty").document(teacher.id)
            if (pubRef.get().await().exists()) {
                batch.update(
                    pubRef,
                    mapOf(
                        "teacherId" to teacher.teacherId,
                        "name" to teacher.name,
                        "role" to teacher.role,
                        "qualification" to teacher.qualification,
                        "experience" to teacher.experience,
                        "subjects" to teacher.subjects,
                        "assignedStandards" to teacher.assignedStandards,
                        "isActive" to (teacher.isActive && teacher.approvalStatus == ApprovalStatusValues.APPROVED),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            syncTeacherUidsAcrossStudents()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteTeacher(teacher: TeacherProfile): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val teacherRef = db.collection("teachers").document(teacher.id)
        return try {
            val batch = db.batch()
            batch.delete(teacherRef)
            if (teacher.authUid.isNotBlank()) {
                batch.delete(db.collection("teacher_directory").document(teacher.authUid))
            }
            batch.delete(db.collection("public_faculty").document(teacher.id))
            val digits = PasswordHasher.normalizePhone10(teacher.contact)
            if (digits.length >= 10) {
                batch.delete(db.collection("phone_registry").document(PasswordHasher.hashPhone(digits)))
            }
            batch.commit().await()
            syncTeacherUidsAcrossStudents()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, teacherRef.path, auth)
            Result.failure(e)
        }
    }

    // ==========================================
    // 4. ADMISSIONS & ADVANCE BOOKINGS
    // ==========================================
    suspend fun submitAdmission(inquiry: AdmissionInquiry): Result<AdmissionInquiry> {
        val uid = requireUserId()
        val id = generateSafeDocId("INQ")
        val ref = db.collection("admissions").document(id)
        val payload = mapOf(
            "authUid" to uid,
            "studentName" to inquiry.studentName.trim(),
            "parentName" to inquiry.parentName.trim(),
            "mobileNumber" to PasswordHasher.normalizePhone10(inquiry.mobileNumber),
            "whatsappNumber" to inquiry.whatsappNumber.trim(),
            "address" to inquiry.address.trim(),
            "dateOfBirth" to inquiry.dateOfBirth.trim(),
            "standard" to inquiry.standard.trim(),
            "medium" to inquiry.medium.trim(),
            "previousSchool" to inquiry.previousSchool.trim(),
            "submissionDate" to inquiry.submissionDate.ifBlank {
                SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
            },
            "status" to InquiryStatus.PENDING.name,
            "notes" to inquiry.notes.trim(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(inquiry.copy(id = id, authUid = uid, status = InquiryStatus.PENDING))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateInquiryStatus(inquiryId: String, newStatus: InquiryStatus): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("admissions").document(inquiryId)
        return try {
            ref.update(mapOf("status" to newStatus.name, "updatedAt" to FieldValue.serverTimestamp())).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun convertInquiryToStudent(inquiryId: String, initialPassword: String): Result<Student> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val inquiry = _admissions.value.firstOrNull { it.id == inquiryId }
            ?: return Result.failure(IllegalStateException("Admission inquiry not found"))
        val result = adminCreateStudent(
            name = inquiry.studentName,
            parentName = inquiry.parentName,
            mobileNumber = inquiry.mobileNumber,
            standard = inquiry.standard,
            password = initialPassword,
            totalFees = standardAnnualFee(inquiry.standard),
            paidFees = 0,
            address = inquiry.address,
            medium = inquiry.medium,
            school = inquiry.previousSchool,
            dob = inquiry.dateOfBirth
        )
        if (result.isSuccess) {
            updateInquiryStatus(inquiryId, InquiryStatus.APPROVED)
        }
        return result
    }

    suspend fun submitAdvanceBooking(booking: AdvanceBooking): Result<AdvanceBooking> {
        val uid = requireUserId()
        val id = generateSafeDocId("BK")
        val ref = db.collection("advance_bookings").document(id)
        val payload = mapOf(
            "authUid" to uid,
            "studentName" to booking.studentName.trim(),
            "standard" to booking.standard.trim(),
            "parentName" to booking.parentName.trim(),
            "mobileNumber" to PasswordHasher.normalizePhone10(booking.mobileNumber),
            "whatsappNumber" to booking.whatsappNumber.trim(),
            "amount" to booking.amount,
            "upiTransactionId" to booking.upiTransactionId.trim(),
            "paymentStatus" to BookingPaymentStatus.PENDING_VERIFICATION.name,
            "bookingDate" to booking.bookingDate.ifBlank {
                SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
            },
            "hasScreenshot" to booking.hasScreenshot,
            "academicYear" to booking.academicYear,
            "notes" to booking.notes.trim(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(booking.copy(id = id, authUid = uid, paymentStatus = BookingPaymentStatus.PENDING_VERIFICATION))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateBookingStatus(bookingId: String, status: BookingPaymentStatus): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("advance_bookings").document(bookingId)
        return try {
            ref.update(mapOf("paymentStatus" to status.name, "updatedAt" to FieldValue.serverTimestamp())).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun approveBookingWithReceipt(bookingId: String): Result<FeeReceipt> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val bk = _advanceBookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalStateException("Booking not found"))
        val recId = generateSafeDocId("REC")
        val recNumber = "HD-REC-ADV-${SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())}-${recId.takeLast(4)}"
        val paymentDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
        val txnRef = bk.upiTransactionId.ifBlank { "UPI-ADV-${recId.takeLast(6)}" }

        val bkRef = db.collection("advance_bookings").document(bookingId)
        val recRef = db.collection("receipts").document(recId)
        val recMap = mapOf(
            "receiptNo" to recNumber,
            "studentId" to bk.id,
            "studentAuthUid" to bk.authUid,
            "studentName" to bk.studentName,
            "standard" to bk.standard,
            "amountPaid" to bk.amount,
            "paymentDate" to paymentDate,
            "paymentMode" to "Advance Booking UPI (₹${bk.amount})",
            "transactionRef" to txnRef,
            "totalFees" to bk.amount,
            "remainingBalance" to 0,
            "paymentStatus" to "SUCCESS",
            "issuedBy" to (_settings.value.founderName.ifBlank { "Harshadsinh Rathod" }),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            val batch = db.batch()
            batch.update(bkRef, mapOf("paymentStatus" to BookingPaymentStatus.CONFIRMED.name, "updatedAt" to FieldValue.serverTimestamp()))
            batch.set(recRef, recMap)
            batch.commit().await()
            Result.success(
                FeeReceipt(
                    id = recId,
                    receiptNo = recNumber,
                    studentId = bk.id,
                    studentAuthUid = bk.authUid,
                    studentName = bk.studentName,
                    standard = bk.standard,
                    amountPaid = bk.amount,
                    paymentDate = paymentDate,
                    paymentMode = "Advance Booking UPI (₹${bk.amount})",
                    transactionRef = txnRef,
                    totalFees = bk.amount,
                    remainingBalance = 0,
                    paymentStatus = "SUCCESS",
                    issuedBy = _settings.value.founderName.ifBlank { "Harshadsinh Rathod" }
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, recRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun addBookingRemainingFees(bookingId: String, remainingAmount: Int, initialPassword: String): Result<Student> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val bk = _advanceBookings.value.firstOrNull { it.id == bookingId }
            ?: return Result.failure(IllegalStateException("Booking not found"))
        val totalFees = bk.amount + remainingAmount.coerceAtLeast(0)
        val res = adminCreateStudent(
            name = bk.studentName,
            parentName = bk.parentName,
            mobileNumber = bk.mobileNumber,
            standard = bk.standard,
            password = initialPassword,
            totalFees = totalFees,
            paidFees = bk.amount
        )
        if (res.isSuccess) {
            updateBookingStatus(bookingId, BookingPaymentStatus.CONFIRMED)
        }
        return res
    }

    // ==========================================
    // 5. FEES, PAYMENTS & SPIN-AND-WIN
    // ==========================================
    fun getStudentReceipts(studentId: String): List<FeeReceipt> {
        return _receipts.value.filter { it.studentId == studentId }
    }

    suspend fun recordFeePayment(
        studentId: String,
        amount: Int,
        paymentMode: String,
        transactionRef: String
    ): Result<FeeReceipt> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        if (amount <= 0) return Result.failure(IllegalArgumentException("Amount must be positive."))
        val studentRef = db.collection("students").document(studentId)
        val recId = generateSafeDocId("REC")
        val recRef = db.collection("receipts").document(recId)

        return try {
            val current = studentRef.get().await().toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Student not found"))
            val newPaid = current.paidFees + amount
            val recNumber = "HD-REC-${SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())}-${recId.takeLast(4)}"
            val paymentDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
            val txn = transactionRef.trim().ifBlank { "TXN-${recId.takeLast(6)}" }
            val remaining = (current.effectiveTotalFees - newPaid).coerceAtLeast(0)

            val recMap = mapOf(
                "receiptNo" to recNumber,
                "studentId" to current.id,
                "studentAuthUid" to current.authUid,
                "studentName" to current.name,
                "standard" to current.standard,
                "amountPaid" to amount,
                "paymentDate" to paymentDate,
                "paymentMode" to paymentMode,
                "transactionRef" to txn,
                "totalFees" to current.effectiveTotalFees,
                "remainingBalance" to remaining,
                "paymentStatus" to "SUCCESS",
                "issuedBy" to (_settings.value.founderName.ifBlank { "Harshadsinh Rathod" }),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val batch = db.batch()
            batch.update(studentRef, mapOf("paidFees" to newPaid, "updatedAt" to FieldValue.serverTimestamp()))
            batch.set(recRef, recMap)
            batch.commit().await()

            Result.success(
                FeeReceipt(
                    id = recId,
                    receiptNo = recNumber,
                    studentId = current.id,
                    studentAuthUid = current.authUid,
                    studentName = current.name,
                    standard = current.standard,
                    amountPaid = amount,
                    paymentDate = paymentDate,
                    paymentMode = paymentMode,
                    transactionRef = txn,
                    totalFees = current.effectiveTotalFees,
                    remainingBalance = remaining,
                    paymentStatus = "SUCCESS",
                    issuedBy = _settings.value.founderName.ifBlank { "Harshadsinh Rathod" }
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, recRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun recordOnlinePayment(
        studentId: String,
        amount: Int,
        paymentMode: String,
        transactionRef: String,
        status: String
    ): Result<FeeReceipt> {
        val uid = requireUserId()
        if (amount <= 0) return Result.failure(IllegalArgumentException("Amount must be positive."))
        val studentRef = db.collection("students").document(studentId)
        val recId = generateSafeDocId("REC")
        val recRef = db.collection("receipts").document(recId)

        return try {
            val current = studentRef.get().await().toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Student not found"))
            val isSuccess = status == "SUCCESS"
            val newPaid = if (isSuccess) current.paidFees + amount else current.paidFees
            val remaining = (current.effectiveTotalFees - newPaid).coerceAtLeast(0)
            val recNumber = "HD-REC-${SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())}-${recId.takeLast(4)}"
            val paymentDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())
            val txn = transactionRef.trim().ifBlank { "TXN-${recId.takeLast(6)}" }
            val studentUid = current.authUid.ifBlank { uid }

            val recMap = mapOf(
                "receiptNo" to recNumber,
                "studentId" to current.id,
                "studentAuthUid" to studentUid,
                "studentName" to current.name,
                "standard" to current.standard,
                "amountPaid" to amount,
                "paymentDate" to paymentDate,
                "paymentMode" to paymentMode,
                "transactionRef" to txn,
                "totalFees" to current.effectiveTotalFees,
                "remainingBalance" to remaining,
                "paymentStatus" to status,
                "issuedBy" to "HD Tuition Classes UPI Verification",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val batch = db.batch()
            if (isSuccess) {
                batch.update(studentRef, mapOf("paidFees" to newPaid, "updatedAt" to FieldValue.serverTimestamp()))
            }
            batch.set(recRef, recMap)
            batch.commit().await()

            Result.success(
                FeeReceipt(
                    id = recId,
                    receiptNo = recNumber,
                    studentId = current.id,
                    studentAuthUid = studentUid,
                    studentName = current.name,
                    standard = current.standard,
                    amountPaid = amount,
                    paymentDate = paymentDate,
                    paymentMode = paymentMode,
                    transactionRef = txn,
                    totalFees = current.effectiveTotalFees,
                    remainingBalance = remaining,
                    paymentStatus = status,
                    issuedBy = "HD Tuition Classes UPI Verification"
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, recRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun adminVerifyPendingReceipt(receiptId: String, approve: Boolean): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val recRef = db.collection("receipts").document(receiptId)
        return try {
            val recSnap = recRef.get().await()
            val receipt = recSnap.toObject(FeeReceipt::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Receipt not found"))
            if (receipt.paymentStatus != "PENDING_VERIFICATION") {
                return Result.failure(IllegalStateException("Receipt is already processed."))
            }
            val studentRef = db.collection("students").document(receipt.studentId)
            val studentSnap = studentRef.get().await()
            val student = studentSnap.toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)

            val batch = db.batch()
            if (approve && student != null) {
                val newPaid = student.paidFees + receipt.amountPaid
                val remaining = (student.effectiveTotalFees - newPaid).coerceAtLeast(0)
                batch.update(studentRef, mapOf("paidFees" to newPaid, "updatedAt" to FieldValue.serverTimestamp()))
                batch.update(
                    recRef,
                    mapOf(
                        "paymentStatus" to "SUCCESS",
                        "remainingBalance" to remaining,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.update(recRef, mapOf("paymentStatus" to "REJECTED", "updatedAt" to FieldValue.serverTimestamp()))
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, recRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun recordSpinWin(studentId: String, discountAmount: Int, prizeLabel: String): Result<Unit> {
        requireUserId()
        val studentRef = db.collection("students").document(studentId)
        return try {
            db.runTransaction { txn ->
                val snap = txn.get(studentRef)
                val alreadyPlayed = snap.getBoolean("spinPlayed") ?: false
                if (alreadyPlayed) {
                    throw IllegalStateException("Spin & Win already played for this account.")
                }
                txn.update(
                    studentRef,
                    mapOf(
                        "spinPlayed" to true,
                        "spinDiscount" to discountAmount.coerceAtLeast(0),
                        "discountReason" to prizeLabel,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun applySpecialDiscount(studentId: String, discountAmount: Int, reason: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val studentRef = db.collection("students").document(studentId)
        return try {
            studentRef.update(
                mapOf(
                    "specialDiscount" to discountAmount.coerceAtLeast(0),
                    "discountReason" to reason.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    // ==========================================
    // 6. ATTENDANCE, HOMEWORK, SUBMISSIONS & RESULTS
    // ==========================================
    fun getStudentAttendance(studentId: String): List<AttendanceRecord> {
        return _attendance.value.filter { it.studentId == studentId }
    }

    suspend fun markBatchAttendance(records: List<AttendanceRecord>): Result<Unit> {
        val uid = requireUserId()
        if (records.isEmpty()) return Result.success(Unit)
        return try {
            val batch = db.batch()
            for (r in records) {
                val safeDate = r.date.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                val docId = "${r.studentId}_$safeDate"
                val ref = db.collection("attendance").document(docId)
                val existing = _attendance.value.firstOrNull { it.id == docId }
                val payload = mapOf(
                    "studentId" to r.studentId,
                    "studentAuthUid" to r.studentAuthUid,
                    "teacherUid" to uid,
                    "standard" to r.standard.ifBlank { "Std" },
                    "date" to r.date,
                    "status" to r.status.name,
                    "notes" to r.notes,
                    "createdAt" to (existing?.createdAt ?: FieldValue.serverTimestamp()),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                batch.set(ref, payload)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "attendance", auth)
            Result.failure(e)
        }
    }

    suspend fun addHomework(item: HomeworkItem): Result<HomeworkItem> {
        val uid = requireUserId()
        val id = generateSafeDocId("HW")
        val ref = db.collection("homework").document(id)
        val payload = mapOf(
            "standard" to item.standard.trim(),
            "subject" to item.subject.trim(),
            "title" to item.title.trim(),
            "description" to item.description.trim(),
            "assignedDate" to item.assignedDate,
            "dueDate" to item.dueDate.trim(),
            "teacherName" to item.teacherName.trim(),
            "teacherUid" to uid,
            "isPublished" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(item.copy(id = id, teacherUid = uid, isPublished = true))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteHomework(id: String): Result<Unit> {
        requireUserId()
        val ref = db.collection("homework").document(id)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            Result.failure(e)
        }
    }

    fun getSubmissionsForHomework(homeworkId: String): List<HomeworkSubmission> {
        return _homeworkSubmissions.value.filter { it.homeworkId == homeworkId }
    }

    fun getStudentSubmissions(studentId: String): List<HomeworkSubmission> {
        return _homeworkSubmissions.value.filter { it.studentId == studentId }
    }

    suspend fun submitHomework(submission: HomeworkSubmission): Result<HomeworkSubmission> {
        val uid = requireUserId()
        val id = generateSafeDocId("SUB")
        val ref = db.collection("homework_submissions").document(id)
        val payload = mapOf(
            "homeworkId" to submission.homeworkId,
            "studentId" to submission.studentId,
            "studentAuthUid" to uid,
            "teacherUid" to submission.teacherUid,
            "studentName" to submission.studentName,
            "subject" to submission.subject,
            "submissionText" to submission.submissionText.trim(),
            "submittedAt" to submission.submittedAt,
            "status" to "Submitted",
            "teacherFeedback" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(submission.copy(id = id, studentAuthUid = uid, status = "Submitted"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun reviewHomeworkSubmission(submissionId: String, status: String, feedback: String): Result<Unit> {
        requireUserId()
        val ref = db.collection("homework_submissions").document(submissionId)
        return try {
            ref.update(
                mapOf(
                    "status" to status,
                    "teacherFeedback" to feedback.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }

    fun getStudentResults(studentId: String): List<ExamResult> {
        return _examResults.value.filter { it.studentId == studentId }
    }

    suspend fun addExamResult(result: ExamResult): Result<ExamResult> {
        val uid = requireUserId()
        val id = generateSafeDocId("RES")
        val ref = db.collection("exam_results").document(id)
        val payload = mapOf(
            "studentId" to result.studentId,
            "studentAuthUid" to result.studentAuthUid,
            "teacherUid" to uid,
            "examName" to result.examName.trim(),
            "examDate" to result.examDate.trim(),
            "standard" to result.standard.trim(),
            "scores" to result.scores.map { s ->
                mapOf(
                    "subject" to s.subject,
                    "marksObtained" to s.marksObtained,
                    "maxMarks" to s.maxMarks
                )
            },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(result.copy(id = id, teacherUid = uid))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    // ==========================================
    // 7. TOPPERS, TIMETABLE, ANNOUNCEMENTS, OFFERS, SETTINGS
    // ==========================================
    suspend fun addPublicTopper(topper: TopperResult): Result<TopperResult> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val id = generateSafeDocId("TOP")
        val ref = db.collection("public_toppers").document(id)
        val payload = mapOf(
            "studentName" to topper.studentName.trim(),
            "standard" to topper.standard.trim(),
            "percentage" to topper.percentage.trim(),
            "year" to topper.year.trim(),
            "school" to topper.school.trim(),
            "remark" to topper.remark.trim(),
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(topper.copy(id = id, isActive = true))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deletePublicTopper(id: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("public_toppers").document(id)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            Result.failure(e)
        }
    }

    fun getTimetableForStandard(standard: String): List<TimetableSlot> {
        val targetNum = extractStandardNumber(standard)
        return _timetable.value.filter {
            extractStandardNumber(it.standard) == targetNum ||
                it.standard.equals(standard, ignoreCase = true)
        }
    }

    suspend fun addTimetableSlot(slot: TimetableSlot): Result<TimetableSlot> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val id = generateSafeDocId("TT")
        val ref = db.collection("timetable").document(id)
        val payload = mapOf(
            "standard" to slot.standard.trim(),
            "dayOfWeek" to slot.dayOfWeek.trim(),
            "timeSlot" to slot.timeSlot.trim(),
            "subject" to slot.subject.trim(),
            "teacherName" to slot.teacherName.trim(),
            "room" to slot.room.trim().ifBlank { "Room 1" },
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(slot.copy(id = id, isActive = true))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteTimetableSlot(id: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("timetable").document(id)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun addAnnouncement(item: AnnouncementItem): Result<AnnouncementItem> {
        val uid = requireUserId()
        val id = generateSafeDocId("ANN")
        val ref = db.collection("announcements").document(id)
        val teacherUidValue = if (isCurrentUserOwner()) "" else uid
        val payload = mapOf(
            "title" to item.title.trim(),
            "content" to item.content.trim(),
            "date" to item.date.ifBlank { SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date()) },
            "isUrgent" to item.isUrgent,
            "targetStandard" to item.targetStandard.trim().ifBlank { "All" },
            "teacherUid" to teacherUidValue,
            "authorName" to item.authorName.trim().ifBlank { "Admin" },
            "isPublished" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            ref.set(payload).await()
            Result.success(item.copy(id = id, teacherUid = teacherUidValue, isPublished = true))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteAnnouncement(id: String): Result<Unit> {
        requireUserId()
        val ref = db.collection("announcements").document(id)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            Result.failure(e)
        }
    }

    private fun normalizeOfferPayload(offer: SpecialOffer, includeCreatedAt: Boolean): Map<String, Any> {
        val cleanStandards = offer.applicableStandards
            .map { normalizeToCanonicalStandard(it) }
            .distinct()
            .ifEmpty { listOf("All") }
        val resolvedType = if (offer.discountType == OfferDiscountType.PERCENTAGE) {
            OfferDiscountType.PERCENTAGE
        } else {
            OfferDiscountType.FIXED
        }
        val resolvedValue = when (resolvedType) {
            OfferDiscountType.PERCENTAGE -> offer.discountValue.coerceIn(0, 100)
            else -> offer.discountValue.coerceIn(0, 500000)
        }
        val resolvedAudience = when (offer.targetAudience) {
            OfferAudience.NEW, OfferAudience.EXISTING -> offer.targetAudience
            else -> OfferAudience.ALL
        }
        val resolvedBadge = offer.badge.trim().ifBlank {
            if (resolvedValue > 0) {
                if (resolvedType == OfferDiscountType.PERCENTAGE) "$resolvedValue% OFF" else "₹$resolvedValue OFF"
            } else {
                "SPECIAL"
            }
        }
        val resolvedValidTill = offer.validTill.trim().ifBlank {
            if (offer.endDate.isNotBlank()) offer.endDate.trim() else "મર્યાદિત સમય માટે"
        }

        val map = mutableMapOf<String, Any>(
            "title" to offer.title.trim(),
            "subtitle" to offer.subtitle.trim(),
            "badge" to resolvedBadge,
            "discountDescription" to offer.discountDescription.trim().ifBlank { offer.title.trim() },
            "discountType" to resolvedType,
            "discountValue" to resolvedValue,
            "applicableStandards" to cleanStandards,
            "targetAudience" to resolvedAudience,
            "startDate" to offer.startDate.trim(),
            "endDate" to offer.endDate.trim(),
            "startDateEpochMs" to offer.startDateEpochMs.coerceAtLeast(0L),
            "endDateEpochMs" to offer.endDateEpochMs.coerceAtLeast(0L),
            "validTill" to resolvedValidTill,
            "maxClaims" to offer.maxClaims.coerceIn(0, 10000),
            "claimedCount" to offer.claimedCount.coerceIn(0, 10000),
            "claimedStudentIds" to offer.claimedStudentIds,
            "bannerImageBase64" to offer.bannerImageBase64,
            "bannerImageUrl" to offer.bannerImageUrl.trim(),
            "bannerPresetKey" to offer.bannerPresetKey.trim().ifBlank { "PURPLE_GOLD" },
            "isActive" to offer.isActive,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (includeCreatedAt) {
            map["createdAt"] = FieldValue.serverTimestamp()
        }
        return map
    }

    private fun buildAdminHistoryMap(
        offerId: String,
        offerTitle: String,
        action: String,
        summary: String,
        studentId: String = "",
        studentName: String = "",
        studentAuthUid: String = "",
        discountApplied: Int = 0
    ): Map<String, Any> {
        val adminUid = auth.currentUser?.uid ?: "OWNER"
        return mapOf(
            "offerId" to offerId,
            "offerTitle" to offerTitle.trim().take(160),
            "action" to action,
            "summary" to summary.trim().take(500),
            "actorRole" to "ADMIN",
            "actorId" to adminUid,
            "studentId" to studentId,
            "studentName" to studentName,
            "studentAuthUid" to studentAuthUid,
            "discountApplied" to discountApplied.coerceAtLeast(0),
            "createdAt" to FieldValue.serverTimestamp()
        )
    }

    suspend fun addOffer(offer: SpecialOffer): Result<SpecialOffer> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        if (offer.title.trim().length < 2) {
            return Result.failure(IllegalArgumentException("Offer title must be at least 2 characters."))
        }
        val id = generateSafeDocId("OFF")
        val ref = db.collection("offers").document(id)
        val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
        val cleanOffer = offer.copy(id = id, claimedCount = 0, claimedStudentIds = emptyList())
        val payload = normalizeOfferPayload(cleanOffer, includeCreatedAt = true)
        val summary = buildString {
            append("${cleanOffer.discountBadgeLabel()} • ${cleanOffer.standardsSummaryLabel(isGu = false)} • ${cleanOffer.audienceLabel(isGu = false)}")
            if (cleanOffer.maxClaims > 0) append(" • Limit: First ${cleanOffer.maxClaims}")
        }
        return try {
            val batch = db.batch()
            batch.set(ref, payload)
            batch.set(
                histRef,
                buildAdminHistoryMap(
                    offerId = id,
                    offerTitle = cleanOffer.title,
                    action = OfferHistoryAction.CREATED,
                    summary = summary
                )
            )
            batch.commit().await()
            Result.success(cleanOffer)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateOffer(offer: SpecialOffer): Result<SpecialOffer> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        if (offer.id.isBlank()) return Result.failure(IllegalArgumentException("Offer ID required"))
        if (offer.title.trim().length < 2) {
            return Result.failure(IllegalArgumentException("Offer title must be at least 2 characters."))
        }
        val ref = db.collection("offers").document(offer.id)
        val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
        return try {
            val snap = ref.get().await()
            val existing = snap.toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Offer not found"))
            val existingCreatedAt = existing.createdAt ?: snap.getTimestamp("createdAt")
                ?: throw IllegalStateException("Offer createdAt missing")

            val preservedOffer = offer.copy(
                claimedCount = existing.claimedCount,
                claimedStudentIds = existing.claimedStudentIds,
                createdAt = existingCreatedAt
            )
            val payload = normalizeOfferPayload(preservedOffer, includeCreatedAt = false).toMutableMap()
            payload["createdAt"] = existingCreatedAt
            val summary = "Updated: ${preservedOffer.discountBadgeLabel()} • ${preservedOffer.standardsSummaryLabel(isGu = false)} • Valid: ${preservedOffer.validTill}"

            val batch = db.batch()
            batch.set(ref, payload)
            batch.set(
                histRef,
                buildAdminHistoryMap(
                    offerId = preservedOffer.id,
                    offerTitle = preservedOffer.title,
                    action = OfferHistoryAction.EDITED,
                    summary = summary
                )
            )
            batch.commit().await()
            Result.success(preservedOffer)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteOffer(id: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("offers").document(id)
        val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
        return try {
            val existing = _offers.value.firstOrNull { it.id == id }
                ?: ref.get().await().toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
            val title = existing?.title?.ifBlank { id } ?: id
            val batch = db.batch()
            batch.set(
                histRef,
                buildAdminHistoryMap(
                    offerId = id,
                    offerTitle = title,
                    action = OfferHistoryAction.DELETED,
                    summary = "Offer deleted by Admin (claimed ${existing?.claimedCount ?: 0} time(s))"
                )
            )
            batch.delete(ref)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun toggleOfferStatus(id: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("offers").document(id)
        val current = _offers.value.firstOrNull { it.id == id }
            ?: ref.get().await().toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
            ?: return Result.failure(IllegalStateException("Offer not found"))
        val nextActive = !current.isActive
        val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
        return try {
            val batch = db.batch()
            batch.update(ref, mapOf("isActive" to nextActive, "updatedAt" to FieldValue.serverTimestamp()))
            batch.set(
                histRef,
                buildAdminHistoryMap(
                    offerId = current.id,
                    offerTitle = current.title,
                    action = if (nextActive) OfferHistoryAction.ACTIVATED else OfferHistoryAction.DEACTIVATED,
                    summary = if (nextActive) "Offer activated by Admin" else "Offer deactivated by Admin"
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }

    suspend fun autoApplyEligibleOffersForStudent(studentId: String): Result<SpecialOffer?> {
        val uid = requireUserId()
        val studentRef = db.collection("students").document(studentId)
        return try {
            val studentSnap = studentRef.get().await()
            val student = studentSnap.toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.success(null)
            if (student.approvalStatus != ApprovalStatusValues.APPROVED || !student.isActive) {
                return Result.success(null)
            }

            val offersList = if (_offers.value.isNotEmpty()) {
                _offers.value
            } else {
                db.collection("offers").whereEqualTo("isActive", true).get().await()
                    .toObjects(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
            }
            val nowMs = System.currentTimeMillis()
            val bestCandidate = offersList
                .filter { offer ->
                    offer.isEligibleFor(student, nowMs) &&
                        student.id !in offer.claimedStudentIds &&
                        offer.calculateDiscountForFee(student.totalFees) > student.offerDiscount
                }
                .maxByOrNull { it.calculateDiscountForFee(student.totalFees) }
                ?: return Result.success(null)

            val offerRef = db.collection("offers").document(bestCandidate.id)
            val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
            val applied = db.runTransaction { txn ->
                val freshStudent = txn.get(studentRef)
                    .toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                    ?: return@runTransaction null
                val freshOffer = txn.get(offerRef)
                    .toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
                    ?: return@runTransaction null

                val txnNowMs = System.currentTimeMillis()
                if (!freshOffer.isEligibleFor(freshStudent, txnNowMs)) return@runTransaction null
                if (freshStudent.id in freshOffer.claimedStudentIds) return@runTransaction null

                val discount = freshOffer.calculateDiscountForFee(freshStudent.totalFees)
                if (discount <= 0 || (freshStudent.offerDiscount > 0 && discount <= freshStudent.offerDiscount)) {
                    return@runTransaction null
                }

                txn.update(
                    offerRef,
                    mapOf(
                        "claimedCount" to (freshOffer.claimedCount + 1),
                        "claimedStudentIds" to (freshOffer.claimedStudentIds + freshStudent.id),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                txn.update(
                    studentRef,
                    mapOf(
                        "appliedOfferId" to freshOffer.id,
                        "appliedOfferTitle" to freshOffer.title,
                        "offerDiscount" to discount,
                        "discountReason" to "Offer: ${freshOffer.title} (${freshOffer.discountBadgeLabel()})",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                txn.set(
                    histRef,
                    mapOf(
                        "offerId" to freshOffer.id,
                        "offerTitle" to freshOffer.title,
                        "action" to OfferHistoryAction.CLAIMED,
                        "summary" to "Auto-applied ₹$discount (${freshOffer.discountBadgeLabel()}) to ${freshStudent.name} (${freshStudent.standard})",
                        "actorRole" to (if (isCurrentUserOwner()) "ADMIN" else "STUDENT"),
                        "actorId" to freshStudent.id,
                        "studentId" to freshStudent.id,
                        "studentName" to freshStudent.name,
                        "studentAuthUid" to freshStudent.authUid.ifBlank { uid },
                        "discountApplied" to discount,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                freshOffer
            }.await()

            Result.success(applied)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "autoApplyEligibleOffersForStudent failed for $studentId: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun adminApplyOfferToEligibleStudents(offerId: String): Result<Int> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val offerRef = db.collection("offers").document(offerId)
        return try {
            val offer = offerRef.get().await().toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Offer not found"))
            val allStudents = if (_students.value.isNotEmpty()) {
                _students.value
            } else {
                db.collection("students").get().await().toObjects(Student::class.java, ServerTimestampBehavior.ESTIMATE)
            }
            val nowMs = System.currentTimeMillis()
            val candidates = allStudents.filter { std ->
                std.approvalStatus == ApprovalStatusValues.APPROVED &&
                    std.isActive &&
                    offer.isEligibleFor(std, nowMs) &&
                    std.id !in offer.claimedStudentIds &&
                    offer.calculateDiscountForFee(std.totalFees) > std.offerDiscount
            }
            var appliedCount = 0
            for (std in candidates) {
                val res = autoApplySpecificOfferInTransaction(offerId, std.id)
                if (res.isSuccess && res.getOrNull() == true) {
                    appliedCount++
                }
            }
            Result.success(appliedCount)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, offerRef.path, auth)
            Result.failure(e)
        }
    }

    private suspend fun autoApplySpecificOfferInTransaction(offerId: String, studentId: String): Result<Boolean> {
        val offerRef = db.collection("offers").document(offerId)
        val studentRef = db.collection("students").document(studentId)
        val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
        return try {
            val applied = db.runTransaction { txn ->
                val freshStudent = txn.get(studentRef).toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                    ?: return@runTransaction false
                val freshOffer = txn.get(offerRef).toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
                    ?: return@runTransaction false
                val nowMs = System.currentTimeMillis()
                if (!freshOffer.isEligibleFor(freshStudent, nowMs)) return@runTransaction false
                if (freshStudent.id in freshOffer.claimedStudentIds) return@runTransaction false
                val discount = freshOffer.calculateDiscountForFee(freshStudent.totalFees)
                if (discount <= 0 || discount <= freshStudent.offerDiscount) return@runTransaction false

                txn.update(
                    offerRef,
                    mapOf(
                        "claimedCount" to (freshOffer.claimedCount + 1),
                        "claimedStudentIds" to (freshOffer.claimedStudentIds + freshStudent.id),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                txn.update(
                    studentRef,
                    mapOf(
                        "appliedOfferId" to freshOffer.id,
                        "appliedOfferTitle" to freshOffer.title,
                        "offerDiscount" to discount,
                        "discountReason" to "Offer: ${freshOffer.title} (${freshOffer.discountBadgeLabel()})",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                txn.set(
                    histRef,
                    buildAdminHistoryMap(
                        offerId = freshOffer.id,
                        offerTitle = freshOffer.title,
                        action = OfferHistoryAction.CLAIMED,
                        summary = "Applied ₹$discount (${freshOffer.discountBadgeLabel()}) to ${freshStudent.name} (${freshStudent.standard})",
                        studentId = freshStudent.id,
                        studentName = freshStudent.name,
                        studentAuthUid = freshStudent.authUid,
                        discountApplied = discount
                    )
                )
                true
            }.await()
            Result.success(applied)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun adminRevokeStudentOffer(studentId: String): Result<Unit> {
        requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val studentRef = db.collection("students").document(studentId)
        val histRef = db.collection("offer_history").document(generateSafeDocId("OH"))
        return try {
            db.runTransaction { txn ->
                val student = txn.get(studentRef).toObject(Student::class.java, ServerTimestampBehavior.ESTIMATE)
                    ?: throw IllegalStateException("Student not found")
                val oldOfferId = student.appliedOfferId
                val oldTitle = student.appliedOfferTitle
                val oldDiscount = student.offerDiscount

                if (oldOfferId.isNotBlank()) {
                    val offerRef = db.collection("offers").document(oldOfferId)
                    val offerSnap = txn.get(offerRef)
                    if (offerSnap.exists()) {
                        val offer = offerSnap.toObject(SpecialOffer::class.java, ServerTimestampBehavior.ESTIMATE)
                        if (offer != null) {
                            val updatedIds = offer.claimedStudentIds.filter { it != studentId }
                            txn.update(
                                offerRef,
                                mapOf(
                                    "claimedCount" to (offer.claimedCount - 1).coerceAtLeast(0),
                                    "claimedStudentIds" to updatedIds,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            )
                        }
                    }
                }
                txn.update(
                    studentRef,
                    mapOf(
                        "appliedOfferId" to "",
                        "appliedOfferTitle" to "",
                        "offerDiscount" to 0,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                txn.set(
                    histRef,
                    buildAdminHistoryMap(
                        offerId = oldOfferId.ifBlank { "REVOKED" },
                        offerTitle = oldTitle.ifBlank { "Student Offer" },
                        action = OfferHistoryAction.REVOKED,
                        summary = "Revoked ₹$oldDiscount offer discount from ${student.name} (${student.id})",
                        studentId = student.id,
                        studentName = student.name,
                        studentAuthUid = student.authUid,
                        discountApplied = oldDiscount
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, studentRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateSettings(newSettings: TuitionSettings): Result<Unit> {
        val uid = requireUserId()
        if (!isCurrentUserOwner()) return Result.failure(SecurityException("Owner access required"))
        val ref = db.collection("institute_settings").document(SETTINGS_DOC_ID)
        return try {
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "businessName" to newSettings.businessName.trim(),
                        "founderName" to newSettings.founderName.trim(),
                        "contactPhone" to newSettings.contactPhone.trim(),
                        "whatsappNumber" to newSettings.whatsappNumber.trim(),
                        "upiId" to newSettings.upiId.trim(),
                        "upiPayeeName" to newSettings.upiPayeeName.trim(),
                        "advanceBookingAmount" to newSettings.advanceBookingAmount,
                        "address" to newSettings.address.trim(),
                        "admissionOpen" to newSettings.admissionOpen,
                        "tickerText" to newSettings.tickerText.trim(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "businessName" to newSettings.businessName.trim(),
                        "founderName" to newSettings.founderName.trim(),
                        "contactPhone" to newSettings.contactPhone.trim(),
                        "whatsappNumber" to newSettings.whatsappNumber.trim(),
                        "upiId" to newSettings.upiId.trim(),
                        "upiPayeeName" to newSettings.upiPayeeName.trim(),
                        "advanceBookingAmount" to newSettings.advanceBookingAmount,
                        "address" to newSettings.address.trim(),
                        "admissionOpen" to newSettings.admissionOpen,
                        "tickerText" to newSettings.tickerText.trim(),
                        "ownerUid" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            Result.failure(e)
        }
    }
}
