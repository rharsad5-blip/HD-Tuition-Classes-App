package com.example.data.model

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    GUJARATI("gu", "Gujarati", "ગુજરાતી"),
    ENGLISH("en", "English", "English")
}

object AppStrings {
    fun get(key: String, language: AppLanguage): String {
        val strings = if (language == AppLanguage.GUJARATI) guStrings else enStrings
        return strings[key] ?: enStrings[key] ?: key
    }

    private val guStrings = mapOf(
        "app_title" to "HD ટ્યુશન ક્લાસીસ",
        "tagline" to "શ્રેષ્ઠ શિક્ષણ, ઉજ્જવળ ભવિષ્ય",
        "founder_title" to "સંચાલક: હર્ષદસિંહ રાઠોડ",
        "founder_name" to "હર્ષદસિંહ રાઠોડ",
        "contact_phone" to "+91 85112 73911",
        "address" to "કવિથા, રાજપૂત સમાજ વાડી, કોટડિયા ફળી, કવિથા, ગુજરાત (બદરખા / અમદાવાદ)",
        "admission_open" to "નવા સત્ર માટે પ્રવેશ શરૂ છે!",
        "standards_offered" to "ધોરણ ૧ થી ૧૨ | તમામ વિષયો | ગુજરાતી માધ્યમ",
        "advance_booking_btn" to "એડવાન્સ સીટ બુકિંગ ₹99",
        "new_admission_btn" to "નવું એડમિશન ફોર્મ",
        "view_courses_btn" to "અમારા કોર્સ જુઓ",
        "whatsapp_btn" to "વોટ્સએપ સંપર્ક",
        "student_portal" to "વિદ્યાર્થી પોર્ટલ",
        "admin_portal" to "એડમિન લૉગિન",
        "nav_home" to "મુખ્ય પૃષ્ઠ",
        "nav_courses" to "કોર્સ",
        "nav_admission" to "એડમિશન",
        "nav_booking" to "સીટ બુકિંગ",
        "nav_fees" to "ફી સ્ટ્રક્ચર",
        "nav_results" to "પરિણામો",
        "nav_contact" to "સંપર્ક",
        "special_offers_title" to "ખાસ ઑફર્સ અને સ્કોલરશીપ",
        "why_choose_us_title" to "શા માટે HD ટ્યુશન ક્લાસીસ પસંદ કરશો?",
        "our_courses_title" to "અમારા ઉપલબ્ધ કોર્સ",
        "our_results_title" to "અમારા તેજસ્વી તારલાઓ - શ્રેષ્ઠ પરિણામો",
        "faculty_title" to "અમારા અનુભવી શિક્ષકો",
        "fee_structure_title" to "વાર્ષિક અને માસિક ફી વિગતો",
        "announcement_ticker" to "તાજા સમાચાર: નવા સત્ર માટે એડવાન્સ સીટ બુકિંગ ₹99 માં શરૂ થઈ ગયું છે. મર્યાદિત સીટો ઉપલબ્ધ!",
        "login" to "લૉગિન",
        "logout" to "લૉગ આઉટ",
        "student_id" to "વિદ્યાર્થી આઈડી (Student ID)",
        "password" to "પાસવર્ડ",
        "admin_id" to "એડમિન આઈડી (Admin ID)",
        "attendance" to "હાજરી",
        "homework" to "ગૃહકાર્ય (Homework)",
        "results" to "પરીક્ષા પરિણામ",
        "fees" to "ફી વિગતો",
        "receipts" to "ફી પાવતી",
        "timetable" to "સમયપત્રક",
        "notifications" to "સૂચનાઓ",
        "profile" to "પ્રોફાઇલ",
        "change_password" to "પાસવર્ડ બદલો"
    )

    private val enStrings = mapOf(
        "app_title" to "HD TUITION CLASSES",
        "tagline" to "Excellence in Education, Bright Future",
        "founder_title" to "Founder: Harshadsinh Rathod",
        "founder_name" to "Harshadsinh Rathod",
        "contact_phone" to "+91 85112 73911",
        "address" to "Kavitha, Rajput Samaj Vadi, Kotadiya Fali, Kavitha, Gujarat (Near Badarkha / Ahmedabad)",
        "admission_open" to "Admissions Open for New Academic Session!",
        "standards_offered" to "Standard 1 to 12 | All Subjects | Gujarati Medium",
        "advance_booking_btn" to "Advance Seat Booking ₹99",
        "new_admission_btn" to "New Admission Form",
        "view_courses_btn" to "View Courses",
        "whatsapp_btn" to "WhatsApp Contact",
        "student_portal" to "Student Portal",
        "admin_portal" to "Admin Login",
        "nav_home" to "Home",
        "nav_courses" to "Courses",
        "nav_admission" to "Admission",
        "nav_booking" to "Seat Booking",
        "nav_fees" to "Fee Structure",
        "nav_results" to "Results",
        "nav_contact" to "Contact",
        "special_offers_title" to "Special Offers & Discounts",
        "why_choose_us_title" to "Why Choose HD Tuition Classes?",
        "our_courses_title" to "Our Courses & Batches",
        "our_results_title" to "Our Shining Stars - Top Results",
        "faculty_title" to "Expert Faculty Members",
        "fee_structure_title" to "Fee Structure & Installments",
        "announcement_ticker" to "Latest News: Advance seat booking for upcoming academic session is open at ₹99. Limited seats available!",
        "login" to "Login",
        "logout" to "Logout",
        "student_id" to "Student ID",
        "password" to "Password",
        "admin_id" to "Admin ID",
        "attendance" to "Attendance",
        "homework" to "Homework",
        "results" to "Exam Results",
        "fees" to "Fee Details",
        "receipts" to "Fee Receipts",
        "timetable" to "Timetable",
        "notifications" to "Notifications",
        "profile" to "Profile",
        "change_password" to "Change Password"
    )
}
