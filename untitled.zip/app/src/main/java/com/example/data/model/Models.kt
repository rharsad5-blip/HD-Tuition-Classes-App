package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp
import java.util.UUID

object ApprovalStatusValues {
    const val PENDING = "PENDING"
    const val APPROVED = "APPROVED"
    const val REJECTED = "REJECTED"
}

object OfferDiscountType {
    const val FIXED = "FIXED"
    const val PERCENTAGE = "PERCENTAGE"
}

object OfferAudience {
    const val ALL = "ALL"
    const val NEW = "NEW"
    const val EXISTING = "EXISTING"
}

object OfferHistoryAction {
    const val CREATED = "CREATED"
    const val EDITED = "EDITED"
    const val ACTIVATED = "ACTIVATED"
    const val DEACTIVATED = "DEACTIVATED"
    const val DELETED = "DELETED"
    const val CLAIMED = "CLAIMED"
    const val REVOKED = "REVOKED"
}

@IgnoreExtraProperties
data class AdminAccount(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val ownerEmail: String = "",
    val adminId: String = "",
    val adminMobile: String = "",
    val founderName: String = "Harshadsinh Rathod",
    val passwordHash: String = "",
    @get:PropertyName("isSetupComplete")
    @field:PropertyName("isSetupComplete")
    val isSetupComplete: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StudentCredential(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val authUid: String = "",
    val passwordHash: String = "",
    val approvalStatus: String = ApprovalStatusValues.PENDING,
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Student(
    @DocumentId val id: String = "",
    val authUid: String = "",
    val teacherUids: List<String> = emptyList(),
    val name: String = "",
    val parentName: String = "",
    val mobileNumber: String = "",
    val standard: String = "Std 10",
    val rollNo: String = "01",
    val passwordHash: String = "",
    val address: String = "કવિથા / બદરખા",
    val joinDate: String = "",
    val totalFees: Int = 11999,
    val paidFees: Int = 0,
    val medium: String = "Gujarati Medium",
    val school: String = "GSEB School",
    val dob: String = "",
    val spinPlayed: Boolean = false,
    val spinDiscount: Int = 0,
    val specialDiscount: Int = 0,
    val discountReason: String = "",
    val appliedOfferId: String = "",
    val appliedOfferTitle: String = "",
    val offerDiscount: Int = 0,
    val approvalStatus: String = ApprovalStatusValues.PENDING,
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val effectiveTotalFees: Int
        get() = (totalFees - spinDiscount - specialDiscount - offerDiscount).coerceAtLeast(0)

    @get:Exclude
    val remainingFees: Int
        get() = (effectiveTotalFees - paidFees).coerceAtLeast(0)

    @get:Exclude
    val feeStatus: String
        get() = if (remainingFees == 0) "Paid" else "Pending"
}

enum class InquiryStatus {
    PENDING, APPROVED, REJECTED
}

@IgnoreExtraProperties
data class AdmissionInquiry(
    @DocumentId val id: String = "",
    val authUid: String = "",
    val studentName: String = "",
    val parentName: String = "",
    val mobileNumber: String = "",
    val whatsappNumber: String = "",
    val address: String = "",
    val dateOfBirth: String = "",
    val standard: String = "Std 10",
    val medium: String = "Gujarati Medium",
    val previousSchool: String = "",
    val submissionDate: String = "",
    val status: InquiryStatus = InquiryStatus.PENDING,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class BookingPaymentStatus {
    PENDING_VERIFICATION, CONFIRMED, REJECTED
}

@IgnoreExtraProperties
data class AdvanceBooking(
    @DocumentId val id: String = "",
    val authUid: String = "",
    val studentName: String = "",
    val standard: String = "Std 10",
    val parentName: String = "",
    val mobileNumber: String = "",
    val whatsappNumber: String = "",
    val amount: Int = 99,
    val upiTransactionId: String = "",
    val paymentStatus: BookingPaymentStatus = BookingPaymentStatus.PENDING_VERIFICATION,
    val bookingDate: String = "",
    val hasScreenshot: Boolean = true,
    val academicYear: String = "2027-28",
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class AttendanceStatus {
    PRESENT, ABSENT, LEAVE
}

@IgnoreExtraProperties
data class AttendanceRecord(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val studentAuthUid: String = "",
    val teacherUid: String = "",
    val standard: String = "",
    val date: String = "",
    val status: AttendanceStatus = AttendanceStatus.PRESENT,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class HomeworkItem(
    @DocumentId val id: String = "",
    val standard: String = "",
    val subject: String = "",
    val title: String = "",
    val description: String = "",
    val assignedDate: String = "",
    val dueDate: String = "",
    val teacherName: String = "",
    val teacherUid: String = "",
    @get:PropertyName("isPublished")
    @field:PropertyName("isPublished")
    val isPublished: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class HomeworkSubmission(
    @DocumentId val id: String = "",
    val homeworkId: String = "",
    val studentId: String = "",
    val studentAuthUid: String = "",
    val teacherUid: String = "",
    val studentName: String = "",
    val subject: String = "",
    val submissionText: String = "",
    val submittedAt: String = "",
    val status: String = "Submitted", // "Submitted", "Checked", "Needs Correction"
    val teacherFeedback: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SubjectScore(
    val subject: String = "",
    val marksObtained: Int = 0,
    val maxMarks: Int = 100
)

@IgnoreExtraProperties
data class ExamResult(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val studentAuthUid: String = "",
    val teacherUid: String = "",
    val examName: String = "",
    val examDate: String = "",
    val standard: String = "",
    val scores: List<SubjectScore> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val totalObtained: Int get() = scores.sumOf { it.marksObtained }

    @get:Exclude
    val totalMax: Int get() = scores.sumOf { it.maxMarks }

    @get:Exclude
    val percentage: Float get() = if (totalMax > 0) (totalObtained.toFloat() / totalMax.toFloat()) * 100f else 0f

    @get:Exclude
    val grade: String
        get() = when {
            percentage >= 90 -> "A1"
            percentage >= 80 -> "A2"
            percentage >= 70 -> "B1"
            percentage >= 60 -> "B2"
            percentage >= 50 -> "C1"
            percentage >= 35 -> "C2"
            else -> "D"
        }
}

@IgnoreExtraProperties
data class FeeReceipt(
    @DocumentId val id: String = "",
    val receiptNo: String = "",
    val studentId: String = "",
    val studentAuthUid: String = "",
    val studentName: String = "",
    val standard: String = "",
    val amountPaid: Int = 0,
    val paymentDate: String = "",
    val paymentMode: String = "Online UPI",
    val transactionRef: String = "",
    val totalFees: Int = 0,
    val remainingBalance: Int = 0,
    val paymentStatus: String = "SUCCESS", // "SUCCESS", "PENDING_VERIFICATION", "FAILED", "CANCELLED", "REJECTED"
    val issuedBy: String = "Harshadsinh Rathod",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TimetableSlot(
    @DocumentId val id: String = "",
    val standard: String = "",
    val dayOfWeek: String = "",
    val timeSlot: String = "",
    val subject: String = "",
    val teacherName: String = "",
    val room: String = "Room 1",
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AnnouncementItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val content: String = "",
    val date: String = "",
    @get:PropertyName("isUrgent")
    @field:PropertyName("isUrgent")
    val isUrgent: Boolean = false,
    val targetStandard: String = "All",
    val teacherUid: String = "",
    val authorName: String = "Admin",
    @get:PropertyName("isPublished")
    @field:PropertyName("isPublished")
    val isPublished: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SpecialOffer(
    @DocumentId val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val badge: String = "",
    val discountDescription: String = "",
    val discountType: String = OfferDiscountType.FIXED,
    val discountValue: Int = 0,
    val applicableStandards: List<String> = listOf("All"),
    val targetAudience: String = OfferAudience.ALL,
    val startDate: String = "",
    val endDate: String = "",
    val startDateEpochMs: Long = 0L,
    val endDateEpochMs: Long = 0L,
    val validTill: String = "",
    val maxClaims: Int = 0,
    val claimedCount: Int = 0,
    val claimedStudentIds: List<String> = emptyList(),
    val bannerImageBase64: String = "",
    val bannerImageUrl: String = "",
    val bannerPresetKey: String = "PURPLE_GOLD",
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun calculateDiscountForFee(baseFee: Int): Int {
        if (discountValue <= 0 || baseFee <= 0) return 0
        return when (discountType) {
            OfferDiscountType.PERCENTAGE -> {
                val pct = discountValue.coerceIn(0, 100)
                ((baseFee.toLong() * pct) / 100L).toInt().coerceIn(0, baseFee)
            }
            else -> discountValue.coerceIn(0, baseFee)
        }
    }

    fun isExpired(nowMs: Long = System.currentTimeMillis()): Boolean {
        return endDateEpochMs > 0L && nowMs > endDateEpochMs
    }

    fun isUpcoming(nowMs: Long = System.currentTimeMillis()): Boolean {
        return startDateEpochMs > 0L && nowMs < startDateEpochMs
    }

    fun isWithinDateWindow(nowMs: Long = System.currentTimeMillis()): Boolean {
        return isActive && !isExpired(nowMs) && !isUpcoming(nowMs)
    }

    fun hasRemainingClaims(): Boolean {
        return maxClaims <= 0 || claimedCount < maxClaims
    }

    fun remainingClaimsCount(): Int? {
        return if (maxClaims <= 0) null else (maxClaims - claimedCount).coerceAtLeast(0)
    }

    fun remainingValidityLabel(isGu: Boolean = true, nowMs: Long = System.currentTimeMillis()): String {
        if (endDateEpochMs <= 0L) {
            return validTill.ifBlank { if (isGu) "સતત માન્ય" else "Ongoing" }
        }
        if (nowMs > endDateEpochMs) {
            return if (isGu) "સમાપ્ત (Expired)" else "Expired"
        }
        if (startDateEpochMs > 0L && nowMs < startDateEpochMs) {
            val daysUntil = ((startDateEpochMs - nowMs) / 86_400_000L) + 1L
            return if (isGu) "$daysUntil દિવસમાં શરૂ થશે" else "Starts in $daysUntil day(s)"
        }
        val diffMs = endDateEpochMs - nowMs
        val days = diffMs / 86_400_000L
        val hours = (diffMs % 86_400_000L) / 3_600_000L
        return when {
            days >= 1L -> if (isGu) "બાકી સમય: $days દિવસ $hours કલાક" else "$days d $hours h remaining"
            hours >= 1L -> if (isGu) "બાકી સમય: $hours કલાક (આજે છેલ્લો દિવસ!)" else "$hours hrs left (Ends today!)"
            else -> if (isGu) "થોડી જ મિનિટો બાકી!" else "Ending soon!"
        }
    }

    fun matchesStandard(studentStandard: String): Boolean {
        if (applicableStandards.isEmpty()) return true
        if (applicableStandards.any { it.equals("All", ignoreCase = true) || it == "બધા ધોરણ" }) {
            return true
        }
        val studentNum = extractNormalizedStandardNumber(studentStandard)
        return applicableStandards.any { allowed ->
            allowed.equals(studentStandard, ignoreCase = true) ||
                (studentNum.isNotBlank() && extractNormalizedStandardNumber(allowed) == studentNum)
        }
    }

    fun matchesAudience(student: Student, nowMs: Long = System.currentTimeMillis()): Boolean {
        val studentCreatedMs = student.createdAt?.toDate()?.time ?: nowMs
        return when (targetAudience) {
            OfferAudience.NEW -> {
                student.paidFees == 0 && (startDateEpochMs <= 0L || studentCreatedMs >= startDateEpochMs)
            }
            OfferAudience.EXISTING -> {
                student.paidFees > 0 || (startDateEpochMs > 0L && studentCreatedMs < startDateEpochMs)
            }
            else -> true
        }
    }

    fun isEligibleFor(student: Student, nowMs: Long = System.currentTimeMillis()): Boolean {
        return isWithinDateWindow(nowMs) &&
            hasRemainingClaims() &&
            matchesStandard(student.standard) &&
            matchesAudience(student, nowMs) &&
            calculateDiscountForFee(student.totalFees) > 0
    }

    fun discountBadgeLabel(): String {
        if (discountValue <= 0) return badge.ifBlank { "OFFER" }
        return if (discountType == OfferDiscountType.PERCENTAGE) {
            "$discountValue% OFF"
        } else {
            "₹$discountValue OFF"
        }
    }

    fun standardsSummaryLabel(isGu: Boolean = true): String {
        if (applicableStandards.isEmpty() || applicableStandards.any { it.equals("All", ignoreCase = true) || it == "બધા ધોરણ" }) {
            return if (isGu) "તમામ ધોરણ (Std 1 થી 12)" else "All Standards (Std 1 to 12)"
        }
        return applicableStandards.joinToString(", ")
    }

    fun audienceLabel(isGu: Boolean = true): String {
        return when (targetAudience) {
            OfferAudience.NEW -> if (isGu) "માત્ર નવા વિદ્યાર્થીઓ (New)" else "New Students Only"
            OfferAudience.EXISTING -> if (isGu) "ચાલુ / જૂના વિદ્યાર્થીઓ (Existing)" else "Existing Students Only"
            else -> if (isGu) "બધા વિદ્યાર્થીઓ (All)" else "All Students"
        }
    }
}

@IgnoreExtraProperties
data class OfferHistoryEntry(
    @DocumentId val id: String = "",
    val offerId: String = "",
    val offerTitle: String = "",
    val action: String = OfferHistoryAction.CREATED,
    val summary: String = "",
    val actorRole: String = "ADMIN",
    val actorId: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val studentAuthUid: String = "",
    val discountApplied: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TeacherProfile(
    @DocumentId val id: String = "",
    val teacherId: String = "",
    val authUid: String = "",
    val name: String = "",
    val role: String = "Faculty",
    val qualification: String = "",
    val experience: String = "",
    val subjects: String = "",
    val assignedStandards: List<String> = emptyList(),
    val contact: String = "",
    val passwordHash: String = "",
    val approvalStatus: String = ApprovalStatusValues.PENDING,
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PublicFaculty(
    @DocumentId val id: String = "",
    val teacherId: String = "",
    val name: String = "",
    val role: String = "",
    val qualification: String = "",
    val experience: String = "",
    val subjects: String = "",
    val assignedStandards: List<String> = emptyList(),
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class CourseCardInfo(
    val standardRange: String,
    val titleGujarati: String,
    val titleEnglish: String,
    val subjects: List<String>,
    val feeMonthly: Int,
    val feeAnnual: Int,
    val descriptionGujarati: String,
    val descriptionEnglish: String,
    val features: List<String>
)

@IgnoreExtraProperties
data class TopperResult(
    @DocumentId val id: String = "",
    val studentName: String = "",
    val standard: String = "",
    val percentage: String = "",
    val year: String = "",
    val school: String = "",
    val remark: String = "",
    @get:PropertyName("isActive")
    @field:PropertyName("isActive")
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TuitionSettings(
    @DocumentId val id: String = "",
    val businessName: String = "HD TUITION CLASSES",
    val founderName: String = "Harshadsinh Rathod",
    val contactPhone: String = "+91 85112 73911",
    val whatsappNumber: String = "+91 85112 73911",
    val upiId: String = "8511273911@upi",
    val upiPayeeName: String = "Harshadsinh Rathod (HD Tuition Classes)",
    val advanceBookingAmount: Int = 99,
    val address: String = "કવિથા, રાજપૂત સમાજ વાડી, કોટડિયા ફળી, કવિથા, ગુજરાત",
    val admissionOpen: Boolean = true,
    val tickerText: String = "નવા સત્ર માટે એડવાન્સ સીટ બુકિંગ ₹99 માં શરૂ થઈ ગયું છે.",
    val ownerUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

fun generateSafeDocId(prefix: String = ""): String {
    val clean = UUID.randomUUID().toString().replace("-", "").take(10).uppercase()
    return if (prefix.isBlank()) clean else "${prefix}_$clean"
}

fun extractNormalizedStandardNumber(standard: String): String {
    val asciiConverted = standard.map { ch ->
        if (ch in '\u0AE6'..'\u0AEF') ('0' + (ch - '\u0AE6')) else ch
    }.joinToString("")
    return Regex("\\d+").find(asciiConverted)?.value ?: standard.trim()
}

fun normalizeToCanonicalStandard(standard: String): String {
    val trimmed = standard.trim()
    if (trimmed.equals("All", ignoreCase = true) || trimmed == "બધા ધોરણ") return "All"
    val digits = extractNormalizedStandardNumber(trimmed)
    val intVal = digits.toIntOrNull()
    return if (intVal != null && intVal in 1..12) "Std $intVal" else trimmed
}
