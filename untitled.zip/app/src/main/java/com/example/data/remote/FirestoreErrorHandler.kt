package com.example.data.remote

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write"),
}

fun handleFirestoreError(
    exception: Throwable,
    operationType: OperationType,
    path: String?,
    auth: FirebaseAuth = Firebase.auth
): String {
    val causes = generateSequence(exception) { it.cause }
    val rootError = causes.firstOrNull { it is FirebaseFirestoreException }
        ?: causes.firstOrNull { it !is CancellationException }
        ?: exception

    val currentUser = runCatching { auth.currentUser }.getOrNull()

    val providerInfoList = currentUser?.providerData?.map { provider ->
        JSONObject().apply {
            put("providerId", provider.providerId)
            put("email", provider.email)
        }
    } ?: emptyList()

    val authInfoJson = JSONObject().apply {
        put("userId", currentUser?.uid)
        put("email", currentUser?.email)
        put("emailVerified", currentUser?.isEmailVerified)
        put("tenantId", currentUser?.tenantId)
        put("providerInfo", JSONArray(providerInfoList))
    }

    val errorInfoJson = JSONObject().apply {
        put("error", rootError.message ?: rootError.toString())
        put("operationType", operationType.value)
        put("path", path)
        put("authInfo", authInfoJson)
    }

    val jsonString = errorInfoJson.toString()
    Log.e("FirestoreError", "Firestore Error: $jsonString")
    return jsonString
}

object PasswordHasher {
    private const val APP_PEPPER = "HD_TUITION_CLASSES_2025_SECURE"

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun hashPassword(rawPassword: String, salt: String = "DEFAULT"): String {
        val normalized = rawPassword.trim()
        return sha256Hex("$APP_PEPPER:$salt:$normalized")
    }

    fun verifyPassword(rawPassword: String, storedHash: String, salt: String = "DEFAULT"): Boolean {
        if (storedHash.isBlank()) return false
        val candidate = hashPassword(rawPassword, salt).toByteArray(Charsets.UTF_8)
        val stored = storedHash.toByteArray(Charsets.UTF_8)
        return MessageDigest.isEqual(candidate, stored)
    }

    fun hashPhone(mobileNumber: String): String {
        val digits = mobileNumber.filter { it.isDigit() }
        val normalized = if (digits.length >= 10) digits.takeLast(10) else digits
        return "ph_" + sha256Hex("PHONE:$normalized").take(32)
    }

    fun normalizePhone10(mobileNumber: String): String {
        val digits = mobileNumber.filter { it.isDigit() }
        return if (digits.length >= 10) digits.takeLast(10) else digits
    }
}
