package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.auth.GoogleAuthGateScreen
import com.example.auth.attemptAutoSignIn
import com.example.auth.authStateFlow
import com.example.auth.signOutGoogle
import com.example.data.model.Student
import com.example.data.model.TeacherProfile
import com.example.data.repository.HDTuitionRepository
import com.example.ui.screens.*
import com.example.ui.theme.HDTuitionTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

enum class AppScreen {
    AUTH,
    HOME,
    ADMISSION,
    BOOKING,
    STUDENT_PORTAL,
    TEACHER_PORTAL,
    ADMIN_PORTAL
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HDTuitionTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HDTuitionAppRoot()
                }
            }
        }
    }
}

@Composable
fun HDTuitionAppRoot(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentUser by Firebase.auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = coroutineScope
            )
        }
    }

    if (currentUser == null) {
        GoogleAuthGateScreen(
            onAuthSuccess = {},
            modifier = modifier
        )
    } else {
        val uid = currentUser!!.uid
        key(uid) {
            val db = remember(uid) {
                FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
            }
            val repository = remember(uid, db) {
                HDTuitionRepository(db, Firebase.auth)
            }

            LaunchedEffect(uid) {
                repository.startBaseListeners()
            }

            DisposableEffect(uid) {
                onDispose {
                    repository.stopListeners()
                }
            }

            HDTuitionApp(
                repository = repository,
                onGoogleSignOut = {
                    repository.clearPortalSession()
                    signOutGoogle(
                        credentialManager = credentialManager,
                        scope = coroutineScope
                    )
                },
                modifier = modifier
            )
        }
    }
}

@Composable
fun HDTuitionApp(
    repository: HDTuitionRepository,
    onGoogleSignOut: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var currentScreen by remember { mutableStateOf(AppScreen.AUTH) }
    var authenticatedStudent by remember { mutableStateOf<Student?>(null) }
    var authenticatedTeacher by remember { mutableStateOf<TeacherProfile?>(null) }
    var adminAuthenticated by remember { mutableStateOf(false) }

    Crossfade(
        targetState = currentScreen,
        label = "ScreenTransition",
        modifier = modifier
    ) { screen ->
        when (screen) {
            AppScreen.AUTH -> AuthScreen(
                repository = repository,
                onLoginSuccessStudent = { student ->
                    authenticatedStudent = student
                    currentScreen = AppScreen.STUDENT_PORTAL
                },
                onLoginSuccessTeacher = { teacher ->
                    authenticatedTeacher = teacher
                    currentScreen = AppScreen.TEACHER_PORTAL
                },
                onLoginSuccessAdmin = {
                    adminAuthenticated = true
                    currentScreen = AppScreen.ADMIN_PORTAL
                },
                onExploreWebsite = {
                    currentScreen = AppScreen.HOME
                },
                onGoogleSignOut = {
                    authenticatedStudent = null
                    authenticatedTeacher = null
                    adminAuthenticated = false
                    onGoogleSignOut()
                }
            )

            AppScreen.HOME -> {
                BackHandler { currentScreen = AppScreen.AUTH }
                HomeScreen(
                    repository = repository,
                    onNavigateToAdmission = { currentScreen = AppScreen.ADMISSION },
                    onNavigateToBooking = { currentScreen = AppScreen.BOOKING },
                    onNavigateToStudentLogin = { currentScreen = AppScreen.STUDENT_PORTAL },
                    onNavigateToTeacherLogin = { currentScreen = AppScreen.TEACHER_PORTAL },
                    onNavigateToAdminLogin = { currentScreen = AppScreen.ADMIN_PORTAL }
                )
            }

            AppScreen.ADMISSION -> {
                BackHandler { currentScreen = AppScreen.HOME }
                AdmissionScreen(
                    repository = repository,
                    onBack = { currentScreen = AppScreen.HOME }
                )
            }

            AppScreen.BOOKING -> {
                BackHandler { currentScreen = AppScreen.HOME }
                AdvanceBookingScreen(
                    repository = repository,
                    onBack = { currentScreen = AppScreen.HOME }
                )
            }

            AppScreen.STUDENT_PORTAL -> {
                BackHandler {
                    authenticatedStudent = null
                    repository.clearPortalSession()
                    currentScreen = AppScreen.AUTH
                }
                StudentPortalScreen(
                    repository = repository,
                    initialStudent = authenticatedStudent,
                    onBack = {
                        authenticatedStudent = null
                        repository.clearPortalSession()
                        currentScreen = AppScreen.AUTH
                    }
                )
            }

            AppScreen.TEACHER_PORTAL -> {
                BackHandler {
                    authenticatedTeacher = null
                    repository.clearPortalSession()
                    currentScreen = AppScreen.AUTH
                }
                TeacherPortalScreen(
                    repository = repository,
                    initialTeacher = authenticatedTeacher,
                    onBack = {
                        authenticatedTeacher = null
                        repository.clearPortalSession()
                        currentScreen = AppScreen.AUTH
                    }
                )
            }

            AppScreen.ADMIN_PORTAL -> {
                BackHandler {
                    adminAuthenticated = false
                    repository.clearPortalSession()
                    currentScreen = AppScreen.AUTH
                }
                AdminPortalScreen(
                    repository = repository,
                    initialAuthenticated = adminAuthenticated,
                    onBack = {
                        adminAuthenticated = false
                        repository.clearPortalSession()
                        currentScreen = AppScreen.AUTH
                    },
                    onGoogleSignOut = {
                        adminAuthenticated = false
                        onGoogleSignOut()
                    }
                )
            }
        }
    }
}
